#!/usr/bin/env python3
"""Run the app's generated HTML in Chromium against a controlled IFrame API.

This checks DOM layout and playback commands, not YouTube streaming/permissions.
Run YouTubeEmbedTest first to produce the exact current wrapper fixtures.
"""
from __future__ import annotations

import html
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "app/build/test-home/youtube-fixtures"
FAKE_API = """
window.fixtureEvents=null;window.fixtureCues=[];window.fixturePlays=0;
window.YT={Player:function(id,options){var self=this;fixtureEvents=options.events;
this.cuePlaylist=function(cue){fixtureCues.push(cue);};
this.cueVideoById=function(cue){fixtureCues.push(cue);};
this.playVideo=function(){fixturePlays++;fixtureEvents.onStateChange({data:1,target:self});};
this.pauseVideo=function(){fixtureEvents.onStateChange({data:2,target:self});};
setTimeout(function(){fixtureEvents.onReady({target:self});},10);}};
onYouTubeIframeAPIReady();
"""
HARNESS = """
<pre id="nuraya-test-result" style="display:none"></pre><script>
setTimeout(function(){var result={passed:false};function check(v,message){if(!v)throw new Error(message);}
try{
 var frame=document.getElementById('player'),rect=frame.getBoundingClientRect();
 check(rect.width>=200&&rect.height>=200,'iframe too small');
 check(Math.abs(rect.width-innerWidth)<=2&&Math.abs(rect.height-innerHeight)<=2,'iframe does not fill viewport');
 check(Math.abs(rect.top)<=2&&Math.abs(rect.left)<=2,'iframe outside viewport');
 check(nurayaStatus.apiReady===true,'API not connected');
 check(nurayaStatus.ready===false,'onReady falsely claims media readiness');
 check(fixtureCues.length===1,'target must be explicitly cued once');
 check(fixturePlays===0,'must not play before cue');
 var requested=nurayaRequested;
 fixtureEvents.onStateChange({data:5});
 check(nurayaStatus.ready===true,'cued target must be ready');
 check(fixturePlays===(requested?1:0),'autoplay intent not respected');
 playNurayaVideo();check(nurayaStatus.state===1,'in-app play failed');
 setNurayaActive(false);check(nurayaStatus.state===2,'inactive page did not pause');
 var before=fixturePlays;playNurayaVideo();check(fixturePlays===before,'inactive page started playback');
 fixtureEvents.onStateChange({data:1});check(nurayaStatus.state===2,'late inactive playback was not stopped');
 setNurayaActive(true);playNurayaVideo();check(nurayaStatus.state===1,'explicit retry play failed');
 fixtureEvents.onAutoplayBlocked();check(nurayaStatus.blocked===true,'autoplay block not surfaced');
 fixtureEvents.onError({data:150});check(nurayaStatus.error===150,'publisher rejection not surfaced');
 result={passed:true,viewport:[innerWidth,innerHeight],iframe:[rect.width,rect.height],
   initialCue:fixtureCues[0],automaticPlaybackRequested:requested,checks:14};
}catch(error){result.error=String(error);}
document.getElementById('nuraya-test-result').textContent=JSON.stringify(result);
},100);
</script>
"""


def main() -> None:
    chromium = shutil.which("chromium")
    if not chromium:
        raise SystemExit("Chromium is required for this browser regression check")
    from playwright.sync_api import sync_playwright
    results = []
    with tempfile.TemporaryDirectory(prefix="nuraya-wrapper-") as folder:
        work = Path(folder)
        for name in ("video", "playlist", "shorts"):
            fixture = FIXTURES / f"{name}.html"
            if not fixture.exists():
                raise SystemExit("Run YouTubeEmbedTest before the browser regression")
            source = fixture.read_text()
            # Only the two external service resources are replaced. The app's
            # real CSS, functions, events and player configuration remain intact.
            source, replaced = re.subn(r'src="https://www.youtube-nocookie.com/embed/[^"]+"',
                'srcdoc="Controlled offline iframe fixture"', source)
            assert replaced == 1
            source, replaced = re.subn(r'<script src="https://www.youtube.com/iframe_api"[^>]*></script>',
                "<script>" + FAKE_API + "</script>", source)
            assert replaced == 1
            source = source.replace("</body>", HARNESS + "</body>")
            page = work / f"{name}.html"
            page.write_text(source)
            environment = os.environ.copy()
            environment.update(XDG_CONFIG_HOME=str(work / "config"), XDG_CACHE_HOME=str(work / "cache"))
            (work / "config").mkdir(exist_ok=True)
            (work / "cache").mkdir(exist_ok=True)
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(executable_path=chromium, headless=True,
                    args=["--no-sandbox", "--disable-dev-shm-usage"], env=environment, timeout=15_000)
                try:
                    context = browser.new_context(viewport={"width": 480, "height": 900})
                    context.route("https://**/*", lambda route: route.abort())
                    page = context.new_page()
                    page.set_content(source, wait_until="domcontentloaded", timeout=10_000)
                    page.wait_for_function("document.getElementById('nuraya-test-result').textContent.length > 0", timeout=10_000)
                    result = json.loads(page.locator("#nuraya-test-result").text_content())
                    result["browserVersion"] = browser.version
                finally:
                    browser.close()
            assert result.get("passed"), (name, result)
            if name == "playlist":
                assert result["initialCue"]["list"] == "PLSzUb0TgsIYsxT5mMj1KSFDXUEJ3psMCU"
            else:
                assert result["initialCue"]["videoId"] == ("uwuqUvJ0cAc" if name == "shorts" else "BKdYbwxKndU")
            results.append({"fixture": name, **result})
    report = {"checkedAt": datetime.now(timezone.utc).isoformat(),
        "scope": "Actual app HTML/CSS in Chromium with controlled local IFrame API; no YouTube streaming or Android WebView claim",
        "results": results}
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
