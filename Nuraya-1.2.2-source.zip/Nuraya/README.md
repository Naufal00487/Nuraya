# Nuraya

Aplikasi Android untuk membaca, mendengarkan, dan mempelajari Al-Qur’an. Gratis, tanpa iklan dari Nuraya atau akun wajib. Penyusun tidak mengambil keuntungan finansial. Video YouTube dapat menampilkan iklan dari platformnya.

## Pembaruan 1.2.2

- **Seluruh tautan video lama diganti** dengan 7 rujukan berbahasa Indonesia dari pengguna: 4 video dan 3 playlist Ngaji Bareng, Uda Ridwan, materi maqam/tilawah, dan MQ Tilawatil Anshar. Nama kanal yang tidak diberikan tidak ditebak.
- **Urutan belajar**: tajwid benar → pengucapan jelas → kelancaran → keindahan suara dan maqam. Dua playlist menengah juga tersedia pada filter lanjutan untuk latihan berikutnya, tanpa menggandakan tautan.
- **Pencarian** mengenali sifat huruf, kelancaran, nama maqam seperti Bayati/Hijaz/Nahawand, variasi ejaan, dan permintaan bahasa audio. Semua hasil berasal dari katalog lokal.
- **Shorts lama dihapus**. Daftar pengganti tidak berisi Shorts, sehingga fitur menampilkan keadaan kosong; video panjang tidak dipaksakan menjadi Shorts. Tujuh tautan baru tetap menggunakan embed resmi YouTube sesuai izin penerbit.

Judul, kanal, bahasa dan perkiraan durasi mengikuti rekomendasi pengguna. Pemutaran serta metadata YouTube terkini belum diverifikasi secara independen karena akses YouTube dari cloud dibatasi. Rincian tersedia di [sumber katalog](docs/VIDEO_SOURCES.md).

## Perbaikan 1.2.1 yang dipertahankan

- **Implementasi feed Shorts di aplikasi**: mendukung geser vertikal atau tombol berikutnya dan menghentikan pemutar halaman yang ditinggalkan. Katalog 1.2.2 tidak memiliki Shorts sehingga pintu masuk utama disembunyikan dan filter Shorts kosong.
- **Pemutar video**: iframe diberi ukuran eksplisit, playlist diinisialisasi ke item pertama, dan status API siap dibedakan dari video siap. Tombol Putar dan Muat ulang tersedia di aplikasi, termasuk saat pemutaran otomatis ditolak.
- **Mikrofon dan AI**: mesin native di APK pengembangan kini dioptimalkan. Indikator suara masuk, hitungan durasi proses, penanganan mikrofon dibisukan/tanpa data, serta tombol **Cek mikrofon · 5 detik** membantu membedakan masalah perekaman dan pengenalan. Tidak ada rekaman yang disimpan.

## Fitur 1.2.0 yang dipertahankan

- **AI bacaan Al-Qur’an** di bagian atas Beranda. Model Tarteel Whisper Quran diunduh sekali (sekitar **59,7 MB**), kemudian memproses suara pada HP tanpa akun atau biaya layanan. Hasil diperbarui bertahap; perbandingan kata membantu menemukan bagian yang perlu diperiksa. Model telah dikonversi, dijalankan pada rekaman uji, dan unduhan publiknya telah diperiksa ulang dengan SHA-256.
- **Pencarian video berdasarkan kebutuhan belajar**, termasuk kalimat sehari-hari, sinonim, variasi ejaan, urutan relevansi, saran topik, dan filter. Pencarian kini mencakup **7 rujukan berbahasa Indonesia dari pengguna**; belum mencari seluruh YouTube secara langsung.
- **Pemutar YouTube di aplikasi** melalui embed resmi untuk video, Shorts, dan playlist yang mendukungnya. Tekan **Tonton di aplikasi** untuk memuat pemutar. Katalog saat ini berisi URL video/playlist; video yang menolak embed tetap menyediakan tautan sumber asli. Internet tetap diperlukan.
- **Teman Belajar lokal yang langsung aktif** untuk mencari kutipan ayat, tafsir Kemenag, dan pelajaran tajwid. Hasil adalah rujukan sumber, bukan jawaban generatif. Pertanyaan tidak dikirim ke server.

## Memakai AI bacaan

1. Buka **Beranda → AI bacaan Al-Qur’an → Unduh & aktifkan AI**. Siapkan internet untuk unduhan model satu kali.
2. Setelah model siap, pilih surah dan ayat, lalu tekan **Mulai membaca**. Izinkan mikrofon ketika diminta.
3. Baca ayat, kemudian tekan **Selesai membaca** untuk melihat perkiraan perbedaan kata. Model dapat digunakan tanpa internet setelah unduhan selesai.

AI pengenalan kata **tidak menilai tajwid, makhraj, harakat, atau panjang mad secara tervalidasi**. Model dapat salah mengenali kata, melewatkan kata yang dibaca, atau melengkapi bacaan yang tidak terdengar. Hasil sementara tidak dinilai sebagai kesalahan final. Kecepatan pembaruan bergantung pada CPU dan memori HP; koreksi seketika tidak dijamin. Pengenal suara Android tersedia sebagai pilihan terpisah, dengan persetujuan jika penyedia memproses online. Nuraya tidak menyimpan rekaman atau transkrip.

Pengujian model dengan rekaman nyata sudah dilakukan pada host. Penggunaan mikrofon, performa AI, dan pemutaran YouTube **belum diuji pada HP fisik oleh pengembang**; laporan pengguna 1.2.0 tentang video kosong dan bacaan tanpa hasil menjadi dasar perbaikan ini. Hasil pengujian dan batasnya dicatat di [BUILD_VALIDATION.md](docs/BUILD_VALIDATION.md).

## Fitur yang dipertahankan

Tulisan Utsmani/Amiri Quran offline, tajwid berwarna aktif secara default, arti per kata Indonesia/Inggris, tafsir Kemenag semua 6.236 ayat, 138 pilihan rekaman lengkap dan 17 qari per ayat, sinkronisasi kata Alafasy pada timing yang lolos pemeriksaan, hafalan/pengulangan, pelajaran tajwid, kuis, dan progres lokal.

Pembetulan basmalah tetap dipertahankan: pembuka 112 surah terpisah tanpa nomor; Al-Fatihah 1:1 tetap basmalah; At-Taubah tidak mempunyai pembuka. Teks kanonis, nomor dan terjemahan tidak diubah.

## Build dan verifikasi

```bash
cd /workspace/Nuraya
bash scripts/setup-android.sh
bash scripts/gradle.sh assembleDebug testDebugUnitTest lintDebug assembleDebugAndroidTest
python3 scripts/verify-native-optimization.py
python3 scripts/import_quran.py --verify
python3 scripts/import_study.py --verify
python3 scripts/import_audio_timing.py --verify
python3 scripts/import_learning_index.py --verify
python3 -m unittest discover -s scripts/tests -v
python3 -m unittest discover -s scripts -p 'test_import_study.py' -v
python3 -m unittest discover -s backend/tests -v
```

Toolchain di `/workspace/.tools`: JDK 17, Gradle 8.11.1, Android SDK 35, NDK 27.2.12479018, CMake 3.22.1. Runtime Whisper MIT dipin di source; tidak memerlukan unduhan kode native saat build. Library native tersedia untuk `arm64-v8a`, `armeabi-v7a`, dan `x86_64`.

Model publik dipin ke commit, ukuran, dan checksum di `QuranAiModel.spec`. APK tidak berisi bobot model; aplikasi mengunduhnya secara terpisah dan memverifikasi seluruh isinya sebelum digunakan. Asal model, lisensi, konversi yang dapat diulang, serta hasil inferensi dan pembatalan JNI dijelaskan di [QURAN_AI_MODEL.md](docs/QURAN_AI_MODEL.md). Tes `QuranModelStoreTest.publishedBuildHasAConfiguredImmutableModel` menolak konfigurasi sementara.

Setelah pemeriksaan lulus, jalankan `python3 scripts/package-artifacts.py` untuk membuat APK, ZIP sumber, metadata, dan SHA-256 di `artifacts/`. Script memeriksa bahwa APK lebih baru dari input build dan seluruh asset APK identik dengan sumber. Cache build, keystore pribadi, dan bobot model tidak disertakan dalam ZIP sumber. Pengujian tambahan `python3 scripts/test-youtube-wrapper.py` memerlukan Chromium dan Python Playwright; jalankan setelah tes JVM menghasilkan fixture HTML. Pengujian ini memakai layanan IFrame terkontrol, bukan streaming YouTube.

APK memerlukan **Android 8.0 atau lebih baru**, memakai applicationId `com.nuraya.app`, versionCode **6**, dan sertifikat distribusi yang sama dengan versi sebelumnya agar dapat dipasang sebagai pembaruan. Windows dapat dipakai untuk mengunduh dan memindahkan APK; pemasangan dilakukan pada perangkat Android.

## Rujukan

- [AI bacaan dan privasi](docs/RECITATION_ASSISTANT.md)
- [Model dan proses konversi](docs/QURAN_AI_MODEL.md)
- [Teman Belajar lokal](docs/LOCAL_LEARNING_ASSISTANT.md)
- [Pencarian video](docs/SMART_VIDEO_SEARCH.md)
- [Pemutar YouTube](docs/VIDEO_EMBED.md) dan [sumber katalog](docs/VIDEO_SOURCES.md)
- [Data Quran](docs/DATA_SOURCES.md), [data belajar](docs/STUDY_DATA.md), [audio](docs/AUDIO_CATALOG.md), [hafalan/kuis](docs/PRACTICE.md)
- [Validasi terakhir](docs/BUILD_VALIDATION.md), [riwayat 1.1.0](docs/BUILD_VALIDATION_1.1.0.md)
