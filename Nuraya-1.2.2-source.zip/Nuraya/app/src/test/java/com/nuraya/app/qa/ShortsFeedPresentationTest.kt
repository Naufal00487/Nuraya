package com.nuraya.app.qa

import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextEquals
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeUp
import androidx.test.core.app.ApplicationProvider
import com.nuraya.app.NurayaApplication
import com.nuraya.app.learning.ShortsFeedScreen
import com.nuraya.app.learning.VideoCatalog
import com.nuraya.app.ui.NurayaTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode

/** Real feed navigation with a controlled player; no YouTube playback is claimed by this test. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = NurayaApplication::class, qualifiers = "w411dp-h891dp")
@LooperMode(LooperMode.Mode.PAUSED)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ShortsFeedPresentationTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()

    @Test fun swipeReplacesTheOnlyPlayerAndBackRestoresTheCurrentShort() {
        val activePlayers = mutableSetOf<String>()
        var maximumPlayers = 0
        // The production catalogue now contains only the user's long videos and
        // playlists. These copies are strictly test fixtures for the retained
        // feed component; they do not classify real long videos as Shorts.
        val base = VideoCatalog(ApplicationProvider.getApplicationContext<NurayaApplication>()).items.first()
        val fixtures = (1..3).map { number -> base.copy(
            id = "fixture-short-$number", titleId = "Video uji $number", format = "short",
        ) }
        compose.setContent { NurayaTheme { Surface {
            var open by remember { mutableStateOf(false) }
            var currentId by remember { mutableStateOf<String?>(null) }
            if (open) ShortsFeedScreen(
                items = fixtures, language = "id", initialId = currentId,
                query = "", onQueryChange = {}, hasFilters = false, guidance = null,
                onClearFilters = {}, onBack = { open = false }, savedIds = emptySet(),
                operationError = false, onToggleSaved = {}, onWatched = {},
                onCurrentItem = { currentId = it },
                playerContent = { item, modifier ->
                    DisposableEffect(item.id) {
                        activePlayers.add(item.id)
                        maximumPlayers = maxOf(maximumPlayers, activePlayers.size)
                        onDispose { activePlayers.remove(item.id) }
                    }
                    Box(modifier) { Text("Pemutar uji: ${item.id}") }
                },
            ) else Box(Modifier.testTag("fixture_catalog")) {
                Button(onClick = { open = true }, modifier = Modifier.testTag("open_fixture_shorts")) {
                    Text("Buka feed uji")
                }
            }
        } } }
        compose.onNodeWithTag("open_fixture_shorts").performClick()
        compose.onNodeWithTag("shorts_position").assertTextEquals("1 / 3")
        compose.onNodeWithText("Buka sumber asli").assertDoesNotExist()
        compose.runOnIdle { assertEquals(setOf("fixture-short-1"), activePlayers) }

        compose.onNodeWithTag("shorts_pager").performTouchInput { swipeUp() }
        compose.waitForIdle()
        compose.onNodeWithTag("shorts_position").assertTextEquals("2 / 3")
        compose.runOnIdle {
            assertEquals(setOf("fixture-short-2"), activePlayers)
            assertEquals(1, maximumPlayers)
        }

        compose.onNodeWithTag("shorts_back").performClick()
        compose.onNodeWithTag("fixture_catalog").assertIsDisplayed()
        compose.runOnIdle { assertTrue(activePlayers.isEmpty()) }
        compose.onNodeWithTag("open_fixture_shorts").performClick()
        compose.onNodeWithTag("shorts_position").assertTextEquals("2 / 3")
        compose.runOnIdle { assertEquals(setOf("fixture-short-2"), activePlayers) }
    }
}
