package com.nuraya.app.learning

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.json.JSONArray
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class VideoCatalogueTest {
    private val context: Context get() = ApplicationProvider.getApplicationContext()

    @Test fun packagedReferencesUseOnlyTheSevenRequestedIndonesianVideosAndPlaylists() {
        val catalog = VideoCatalog(context)
        assertFalse(catalog.error)
        val requestedUrls = setOf(
            "https://www.youtube.com/watch?v=qj0qQ157jlg",
            "https://www.youtube.com/watch?v=QgCZizuFhoQ",
            "https://www.youtube.com/playlist?list=PLjDKbvDswLYpBkZBJX3pQjDNIne-YdwEc",
            "https://www.youtube.com/playlist?list=PLkzw0NkHAvYxHKdkvjb6RqzhWU7GEWCwB",
            "https://www.youtube.com/watch?v=9SI4HgYA_pk",
            "https://www.youtube.com/watch?v=42VQXkAxCQY",
            "https://www.youtube.com/playlist?list=PLo2rrrmYLhcxVDlDJDzzyU79zlkVe66gL",
        )
        assertEquals(7, catalog.items.size)
        assertEquals(requestedUrls, catalog.items.map { it.originalUrl }.toSet())
        assertEquals(4, catalog.items.count { it.format == "lesson" })
        assertEquals(3, catalog.items.count { it.format == "course" })
        assertFalse(catalog.items.any { it.format == "short" })
        assertEquals(VideoItem.levels, catalog.items.flatMap { listOf(it.level) + it.additionalLevels }.toSet())
        for (item in catalog.items) {
            assertEquals("id", item.audioLanguage)
            assertEquals("link-only", item.license)
            assertNull(item.streamUrl)
            assertEquals("user-provided", item.metadataSource)
            assertEquals("2026-10-27", item.addedAt)
            assertTrue(item.verifiedAt.isBlank())
            assertEquals(item.originalUrl, item.verificationUrl)
            assertFalse(item.originalUrl.contains("/results?"))
            assertTrue(item.topicTags.all { it in VideoItem.learningTopics })
            val embed = YouTubeEmbed.parse(item.originalUrl)
            assertNotNull(item.id, embed)
            if (item.format == "course") assertNotNull(item.id, embed?.playlistId)
            else assertNotNull(item.id, embed?.videoId)
        }
    }

    @Test fun searchCombinesLearningWordsAndRespectsLevelAndFormat() {
        val catalog = VideoCatalog(context)
        assertEquals(listOf("ngaji-bareng-dari-nol"), catalog.search("huruf harakat").map { it.id })
        assertEquals(setOf("tilawah-tingkatan-maqam", "mq-tilawatil-qiroah"),
            catalog.search("", level = "advanced").map { it.id }.toSet())
        assertTrue(catalog.search("", level = "advanced").all { it.supportsLevel("advanced") })
        assertTrue(catalog.search("", format = "short").isEmpty())
        assertTrue(catalog.search("football casino").isEmpty())
        assertTrue(catalog.search("tajwid", format = "short").isEmpty())
    }

    @Test fun unrelatedCatalogueEntryIsRejectedInsteadOfEnteringLearningSearch() {
        val data = context.assets.open("videos.json").bufferedReader().use { JSONArray(it.readText()) }
        data.getJSONObject(0).put("topicTags", JSONArray(listOf("unrelated-entertainment")))
        try {
            VideoCatalog.parse(data.toString())
            fail("Unrelated content entered the learning catalogue")
        } catch (_: IllegalArgumentException) { }
    }
}
