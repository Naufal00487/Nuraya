package com.nuraya.app.learning

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class VideoSmartSearchTest {
    private val catalog get() = VideoCatalog(ApplicationProvider.getApplicationContext<Application>())

    @Test fun beginnerNeedsInNaturalIndonesianAndEnglishStartWithLetters() {
        listOf("saya belum bisa baca quran", "cara ngaji dari nol", "aku pengen belajar ngaji dari 0", "saya gak bisa baca Quran", "belajar Quran dari awal", "how do I learn Quran from scratch", "I can't read Quran").forEach { query ->
            val result = catalog.searchWithGuidance(query)
            assertEquals(query, "ngaji-bareng-dari-nol", result.items.firstOrNull()?.id)
            assertTrue(query, result.items.all { it.level == "beginner" && it.audioLanguage == "id" })
            assertNotNull(result.guidance)
        }
    }

    @Test fun everydayTermsFindActualLearningTopicsAndIndonesianSources() {
        listOf("belajar panjang pendek" to "madd", "cara baca dengung" to "ghunnah",
            "cara berhenti saat baca quran" to "waqf", "huruf harakat" to "harakat").forEach { (query, tag) ->
            val result = catalog.search(query)
            assertTrue(query, result.isNotEmpty())
            assertTrue(query, result.all { tag in it.topicTags && it.audioLanguage == "id" })
        }
        val traits = catalog.search("makhraj dan sifat huruf")
        assertTrue(traits.any { it.id == "uda-ridwan-tajwid-1-30" })
        assertTrue(traits.all { "sifat-huruf" in it.topicTags && "makhraj" in it.topicTags })
        val fluent = catalog.search("saya ingin lancar membaca")
        assertTrue(fluent.isNotEmpty())
        assertTrue(fluent.all { "fluency" in it.topicTags })
        assertTrue(catalog.search("asi").isEmpty())
    }

    @Test fun specificRuleQueriesExplainWhenOnlyBroaderTajwidCoursesExist() {
        val result = catalog.searchWithGuidance("hukum nun mati ketemu ba")
        assertTrue(result.items.isNotEmpty())
        assertTrue(result.items.all { "tajwid" in it.topicTags })
        assertTrue(result.relatedOnly)
        assertTrue(result.guidance.orEmpty().contains("iqlab"))
        assertTrue(result.guidance.orEmpty().contains("Belum ada video khusus"))
        assertEquals(result.items.map { it.id }.toSet(), catalog.search("hukum nun mati ketemu huruf ba").map { it.id }.toSet())
    }

    @Test fun removedShortsAndUnprovidedMemorizationLessonsAreNotInvented() {
        listOf("hafalan surat pendek", "Shorts Al Ikhlas", "video pendek", "hafallan").forEach { query ->
            val result = catalog.searchWithGuidance(query)
            assertTrue(query, result.items.isEmpty())
            assertNotNull(query, result.guidance)
        }
    }

    @Test fun commonTyposAreCorrectedButUnknownSubjectsAreNotDiscarded() {
        val typo = catalog.searchWithGuidance("tajwdi pemula")
        assertTrue(typo.items.isNotEmpty())
        assertTrue(typo.items.all { "tajwid" in it.topicTags && it.level == "beginner" })
        assertTrue(typo.guidance.orEmpty().contains("Ejaan"))
        assertTrue(catalog.search("tajwid quantumcomputing").isEmpty())
    }

    @Test fun channelsAndNamedMaqamKeepSpecificRequirements() {
        assertEquals(listOf("uda-ridwan-tajwid-1-30"), catalog.search("Uda Ridwan").map { it.id })
        assertEquals(setOf("ngaji-bareng-dari-nol", "ngaji-bareng-tajwid-lengkap"), catalog.search("Ngaji Bareng").map { it.id }.toSet())
        val bayati = catalog.search("belajar Bayati Hijaz Nahawand").map { it.id }.toSet()
        assertTrue(bayati.contains("maqam-bayati-hijaz-nahawand"))
        assertEquals(bayati, catalog.search("belajar Bayyati Hijaz Nahawand").map { it.id }.toSet())
        val rast = catalog.search("maqam Rast").map { it.id }.toSet()
        assertTrue(rast.contains("seni-tilawatil-lima-maqam"))
        assertFalse(rast.contains("maqam-bayati-hijaz-nahawand"))
        assertEquals(rast, catalog.search("maqam Rost").map { it.id }.toSet())
        assertEquals(listOf("mq-tilawatil-qiroah"), catalog.search("Shoba").map { it.id })
        assertTrue(catalog.search("maqam quantumcomputing").isEmpty())
    }

    @Test fun filtersAndRequestedAudioLanguageStayInForce() {
        val result = catalog.searchWithGuidance("tajwid", format = "short")
        assertTrue(result.items.isEmpty())
        assertTrue(result.guidance.orEmpty().contains("filter"))
        assertTrue(result.suggestions.isNotEmpty())
        val advanced = catalog.search("maqam", level = "advanced")
        assertTrue(advanced.isNotEmpty())
        assertTrue(advanced.all { it.supportsLevel("advanced") && "maqam" in it.topicTags })
        val indonesian = catalog.search("video tajwid bahasa Indonesia")
        assertTrue(indonesian.isNotEmpty())
        assertTrue(indonesian.all { it.audioLanguage == "id" })
        assertTrue(catalog.search("tajwid bahasa Inggris").isEmpty())
        assertTrue(catalog.search("maqam", level = "beginner").isEmpty())
    }

    @Test fun offTopicAndMixedOffTopicQueriesDoNotEnterTheLearningCatalogue() {
        listOf("football casino", "video tajwid judi slot", "resep masak", "gaming Quran", "software deployment").forEach { query ->
            assertTrue(query, catalog.search(query).isEmpty())
        }
        val english = catalog.searchWithGuidance("football", language = "en")
        assertTrue(english.guidance.orEmpty().contains("Qur’an learning"))
        assertEquals("Quran from scratch", english.suggestions.first())
    }
}
