package com.nuraya.app.learning

import java.text.Normalizer
import java.util.Locale

/** A ranked, local learning search. This is not a generative answer or a web-wide search. */
data class VideoSearchResults(
    val items: List<VideoItem>,
    val guidance: String? = null,
    val suggestions: List<String> = emptyList(),
    val relatedOnly: Boolean = false,
)

internal object LearningVideoSearch {
    private data class Topic(
        val id: String, val titleId: String, val titleEn: String,
        val tags: Set<String>, val aliases: Set<String>,
    ) {
        fun title(language: String) = if (language == "en") titleEn else titleId
    }

    private val topics = listOf(
        Topic("letters", "Huruf hijaiyah", "Arabic letters", setOf("letters"),
            setOf("huruf", "hijaiyah", "hijaiyyah", "abjad", "alphabet", "letters", "iqra", "iqro")),
        Topic("harakat", "Harakat", "Vowel marks", setOf("harakat"),
            setOf("harakat", "fathah", "kasrah", "dammah", "dhommah", "fatha", "kasra", "vowels")),
        Topic("tajwid", "Tajwid", "Tajwid", setOf("tajwid"),
            setOf("tajwid", "tajweed", "tajuid", "tajwīd")),
        Topic("makhraj", "Makhraj", "Articulation", setOf("makhraj"),
            setOf("makhraj", "makharij", "makhroj", "artikulasi", "pelafalan", "pengucapan", "pronunciation", "articulation")),
        Topic("sifat-huruf", "Sifat huruf", "Letter characteristics", setOf("sifat-huruf"),
            setOf("sifat", "sifatul", "characteristics")),
        Topic("fluency", "Kelancaran membaca", "Reading fluency", setOf("fluency"),
            setOf("lancar", "kelancaran", "melancarkan", "fasih", "tartil", "fluency", "fluent")),
        Topic("maqam", "Maqam dan keindahan suara", "Maqam and vocal expression", setOf("maqam"),
            setOf("maqam", "maqamat", "makam", "nada", "irama", "lagu", "keindahan", "indah", "melody", "melodies")),
        Topic("madd", "Panjang pendek (mad)", "Vowel length (madd)", setOf("madd"),
            setOf("mad", "madd", "panjang", "lengthening")),
        Topic("ghunnah", "Dengung", "Ghunnah", setOf("ghunnah"),
            setOf("dengung", "ghunnah", "ghunah", "ghunna", "nasal")),
        Topic("waqf", "Berhenti dan menyambung bacaan", "Pausing and resuming", setOf("waqf"),
            setOf("waqaf", "waqf", "waqof", "ibtida", "jeda", "berhenti", "pausing", "stopping")),
        Topic("memorization", "Hafalan", "Memorization", setOf("memorization"),
            setOf("hafal", "hafalan", "menghafal", "tahfidz", "tahfiz", "hifz", "murajaah", "murojaah", "memorization", "memorisation", "memorize", "memorise")),
        Topic("recitation", "Contoh bacaan", "Recitation examples", setOf("recitation"),
            setOf("murottal", "murattal", "murotal", "qari", "qori", "recitation", "lantunan", "menyimak", "tilawah", "tilawatil", "qiroah", "qiraah")),
    )
    // Named maqam remain literal constraints, not broad synonyms for any melody.
    private val namedMaqam = setOf("bayati", "hijaz", "nahawand", "rost", "sikah", "shoba")
    private val tokenAliases = mapOf("bayyati" to "bayati", "bayyatii" to "bayati", "rast" to "rost",
        "sika" to "sikah", "soba" to "shoba", "saba" to "shoba", "shobah" to "shoba", "nahawan" to "nahawand",
        "5" to "lima", "7" to "tujuh")
    private val topicAliases = topics.flatMap { topic -> topic.aliases.map { normalize(it) to topic } }.toMap()
    private val beginnerWords = setOf("pemula", "beginner", "beginners", "awam", "dasar", "basic", "basics")
    private val intermediateWords = setOf("menengah", "intermediate")
    private val advancedWords = setOf("lanjutan", "advance", "advanced", "expert")
    private val readingWords = setOf("ngaji", "mengaji", "baca", "bacaan", "membaca", "reading", "read", "quran", "qurani", "alquran", "koran")
    private val fillerWords = setOf(
        "saya", "aku", "gw", "gue", "gua", "kamu", "anda", "kami", "kita", "dong", "nih", "ya", "tolong", "please",
        "mau", "ingin", "pengen", "butuh", "ingin", "cari", "carikan", "mencari", "find", "search", "need", "want",
        "cara", "gimana", "bagaimana", "gmn", "bagaimanakah", "how", "what", "can", "i", "to", "do", "my", "me",
        "belajar", "pelajari", "mempelajari", "pembelajaran", "pelajaran", "learn", "learning", "study", "lesson", "lessons", "tutorial", "tutorials",
        "bisa", "bikin", "supaya", "agar", "untuk", "biar", "dengan", "yang", "dan", "atau", "tentang", "itu", "ini", "nya", "the", "a", "an", "of", "about", "and", "for", "in", "with",
        "video", "videos", "materi", "saat", "ketika", "hukum", "aturan", "rule", "rules", "surat", "surah", "surahs", "al", "as", "an", "ustadz", "ustaz", "syekh", "sheikh", "shaykh",
    )
    private val unrelatedWords = setOf("casino", "kasino", "judi", "slot", "football", "sepakbola", "porn", "porno", "pornografi", "trading", "forex", "resep", "masak", "film", "drama", "gaming")
    private val zeroWords = setOf("nol", "zero", "scratch", "0", "awal")
    private val unableWords = setOf("belum", "tidak", "gak", "ga", "gk", "cannot", "cant")
    private val specialWords = setOf("nun", "mati", "sukun", "tanwin", "ketemu", "bertemu", "ketemunya", "ba", "iqlab", "ikhfa", "ikhfaa", "idgham", "idghom", "izhar", "idzhar", "qalqalah", "pendek", "short", "shorts", "reels", "dari", "from") + zeroWords + unableWords
    private val knownWords = topicAliases.keys + beginnerWords + intermediateWords + advancedWords + readingWords + fillerWords + specialWords + namedMaqam

    fun search(items: List<VideoItem>, query: String, level: String?, format: String?, language: String): VideoSearchResults {
        val originalWords = tokens(query.take(240)).take(40)
        val defaults = suggestions(language)
        if (originalWords.isEmpty()) return VideoSearchResults(
            items.filter { acceptsFilters(it, level, format) }, suggestions = defaults,
        )
        // A query cannot use a Quran keyword to route unrelated requests into the library.
        if (originalWords.any { it in unrelatedWords }) return VideoSearchResults(emptyList(),
            text(language, "Pencarian ini khusus pelajaran Al-Qur’an. Coba pilih kebutuhan belajar di bawah.",
                "This search covers Qur’an learning only. Choose a learning need below."), defaults)

        val documents = items.associateWith(::document)
        val vocabulary = knownWords + documents.values.flatMap { it.keys }
        val correctedWords = originalWords.map { correctTypo(it, vocabulary) }
        val words = correctedWords.toSet()
        val used = mutableSetOf<String>()
        val selectedTopics = linkedSetOf<Topic>()
        words.forEach { word -> topicAliases[word]?.let { selectedTopics += it; used += word } }
        if (words.any { it in namedMaqam }) selectedTopics += topics.first { it.id == "maqam" }
        if (selectedTopics.any { it.id == "sifat-huruf" } && "huruf" in words) {
            // "Sifat huruf" asks for articulation characteristics, not an alphabet lesson.
            selectedTopics.removeAll { it.id == "letters" }
        }
        if (selectedTopics.any { it.id == "maqam" } && words.any { it in setOf("indah", "keindahan") }) used += "suara"
        val requestedAudioLanguage = when {
            words.any { it in setOf("indonesia", "indonesian") } -> "id"
            words.any { it in setOf("inggris", "english") } -> "en"
            "bahasa" in words && "arab" in words -> "ar"
            else -> null
        }
        if (requestedAudioLanguage != null) used += setOf("bahasa", "audio", "indonesia", "indonesian", "inggris", "english", "arab")
        val requestedLevel = when {
            words.any { it in beginnerWords } -> "beginner"
            words.any { it in intermediateWords } -> "intermediate"
            words.any { it in advancedWords } -> "advanced"
            else -> null
        }
        used += words.intersect(beginnerWords + intermediateWords + advancedWords)
        val fromZero = (words.any { it in zeroWords } && words.any { it in setOf("dari", "from", "ngaji", "belajar", "learn", "reading") }) ||
            (words.any { it in unableWords } && words.any { it in readingWords })
        if (fromZero) {
            used += words.intersect(zeroWords + unableWords + setOf("dari", "from"))
            if (selectedTopics.isEmpty()) selectedTopics += topics.first { it.id == "letters" }
        }
        // "Surat pendek" is not the same request as a short-form video.
        val shortSurahs = "pendek" in words && words.any { it in setOf("surat", "surah", "surahs") }
        val shortVideo = words.any { it in setOf("shorts", "reels") } ||
            ("video" in words && "pendek" in words) || ("short" in words && "video" in words)
        if (shortSurahs || ("panjang" in words && "pendek" in words) || shortVideo) used += "pendek"
        if (shortVideo) used += setOf("shorts", "reels", "short")
        val effectiveLevel = level ?: requestedLevel ?: if (fromZero) "beginner" else null
        val effectiveFormat = format ?: if (shortVideo) "short" else null

        var narrowTopicId: String? = null
        var narrowTopicEn: String? = null
        val nunToBa = ("nun" in words || "tanwin" in words) && "ba" in words && words.any { it in setOf("ketemu", "bertemu", "ketemunya") }
        val narrowRules = linkedMapOf("iqlab" to "iqlab", "ikhfa" to "ikhfa", "ikhfaa" to "ikhfa", "idgham" to "idgham", "idghom" to "idgham", "izhar" to "izhar", "idzhar" to "izhar", "qalqalah" to "qalqalah")
        val namedRule = words.firstNotNullOfOrNull { narrowRules[it] }
        val nunRule = "nun" in words && words.any { it in setOf("mati", "sukun") } || "tanwin" in words
        if (nunToBa || namedRule != null || nunRule) {
            narrowTopicId = if (nunToBa) "iqlab (nun mati/tanwin bertemu ba)" else namedRule ?: "nun mati dan tanwin"
            narrowTopicEn = if (nunToBa) "iqlab (noon/tanween before baa)" else namedRule ?: "noon saakin and tanween"
            selectedTopics += topics.first { it.id == "tajwid" }
            // In "nun mati bertemu huruf ba", huruf describes the rule, not an alphabet lesson.
            selectedTopics.removeAll { it.id == "letters" }
            used += words.intersect(narrowRules.keys + setOf("nun", "mati", "sukun", "tanwin", "ketemu", "bertemu", "ketemunya", "ba"))
        }
        if (shortSurahs && selectedTopics.any { it.id == "memorization" }) {
            narrowTopicId = "hafalan surat pendek"
            narrowTopicEn = "memorizing short surahs"
        }
        val readingIntent = words.any { it in readingWords }
        used += words.intersect(readingWords + fillerWords)
        val literalWords = words - used
        val meaningful = selectedTopics.isNotEmpty() || readingIntent || requestedLevel != null || fromZero || shortVideo || literalWords.isNotEmpty()
        val ranked = if (!meaningful) emptyList() else items.mapNotNull { item ->
            if (!acceptsFilters(item, effectiveLevel, effectiveFormat)) return@mapNotNull null
            if (requestedAudioLanguage != null && item.audioLanguage != requestedAudioLanguage) return@mapNotNull null
            val doc = documents.getValue(item)
            // Every unrecognised, meaningful word must actually occur in this entry.
            if (literalWords.any { it !in doc }) return@mapNotNull null
            if (selectedTopics.any { topic -> topic.tags.none { it in item.topicTags } }) return@mapNotNull null
            val lexicalScore = words.sumOf { doc[it] ?: 0 }
            val topicScore = selectedTopics.sumOf { topic -> topic.tags.count { it in item.topicTags } * 12 }
            item to (lexicalScore + topicScore)
        }.sortedWith(compareByDescending<Pair<VideoItem, Int>> { it.second }.thenBy { it.first.lessonOrder }.thenBy { it.first.id })
            .map { it.first }
        val relatedOnly = narrowTopicId != null && ranked.isNotEmpty()
        val topicQueries = selectedTopics.map { it.title(language) }.distinct()
        val searchSuggestions = (topicQueries + defaults).distinct().filter { normalize(it) != normalize(query) }.take(5)
        val guidance = when {
            ranked.isEmpty() && !meaningful -> text(language, "Ceritakan yang ingin dipelajari, misalnya “belum bisa baca Quran” atau “panjang pendek”.", "Tell us what you want to learn, such as “Quran from scratch” or “madd”.")
            ranked.isEmpty() -> text(language, "Belum ada pelajaran yang cocok dalam katalog dan filter ini. Coba topik terkait atau ubah filter.", "No lesson matches this catalogue and its filters yet. Try a related topic or change the filters.")
            relatedOnly -> text(language, "Belum ada video khusus $narrowTopicId yang terverifikasi di katalog. Berikut materi terkait; periksa daftar pelajaran di dalam serinya.", "There is no verified dedicated video for $narrowTopicEn in this catalogue yet. These are related lessons; check each course’s lesson list.")
            fromZero -> text(language, "Mulai dari huruf dan harakat, lalu lanjutkan tajwid dasar. Hasil diurutkan sesuai kebutuhan belajar awal.", "Start with letters and vowel marks, then basic tajwid. Results are ranked for a beginner’s learning needs.")
            correctedWords != originalWords -> text(language, "Ejaan dicocokkan ke kata belajar terdekat: ${correctedWords.joinToString(" ")}", "Spelling matched to the nearest learning words: ${correctedWords.joinToString(" ")}")
            selectedTopics.isNotEmpty() -> text(language, "Materi diurutkan untuk: ${topicQueries.joinToString(", ")}.", "Lessons ranked for: ${topicQueries.joinToString(", ")}.")
            else -> null
        }
        return VideoSearchResults(ranked, guidance, searchSuggestions, relatedOnly)
    }

    private fun acceptsFilters(item: VideoItem, level: String?, format: String?) =
        (level == null || item.supportsLevel(level)) && (format == null || item.format == format)

    private fun document(item: VideoItem): Map<String, Int> {
        val result = mutableMapOf<String, Int>()
        listOf(
            10 to item.speaker, 8 to "${item.titleId} ${item.titleEn} ${item.originalTitle}",
            5 to "${item.categoryId} ${item.categoryEn}", 4 to item.topicTags.joinToString(" "),
            1 to "${item.descriptionId} ${item.descriptionEn}",
        ).forEach { (weight, value) -> tokens(value).distinct().forEach { word -> result[word] = maxOf(result[word] ?: 0, weight) } }
        return result
    }

    private fun suggestions(language: String) = if (language == "en")
        listOf("Quran from scratch", "Tajwid beginner", "Articulation", "Reading fluency", "Maqam Bayati")
    else listOf("Ngaji dari nol", "Tajwid pemula", "Makhraj", "Kelancaran membaca", "Maqam Bayati")

    private fun text(language: String, id: String, en: String) = if (language == "en") en else id
    private fun tokens(value: String) = normalize(value).split(' ').filter(String::isNotBlank).map { tokenAliases[it] ?: it }
    private fun normalize(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "").lowercase(Locale.ROOT)
        .replace(Regex("\\bcan[’']t\\b"), "cannot")
        .replace(Regex("qur[’']?an"), "quran")
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

    /** One edit/transposition only; short fragments never expand into arbitrary words. */
    private fun correctTypo(word: String, vocabulary: Set<String>): String {
        if (word in vocabulary || word.length < 5 || word.any(Char::isDigit)) return word
        val candidates = vocabulary.filter { it.length >= 5 && oneEditApart(word, it) }
        return candidates.singleOrNull() ?: word
    }

    private fun oneEditApart(a: String, b: String): Boolean {
        if (kotlin.math.abs(a.length - b.length) > 1) return false
        if (a.length == b.length) {
            val different = a.indices.filter { a[it] != b[it] }
            return different.size == 1 || different.size == 2 && different[1] == different[0] + 1 &&
                a[different[0]] == b[different[1]] && a[different[1]] == b[different[0]]
        }
        val shorter = if (a.length < b.length) a else b
        val longer = if (a.length < b.length) b else a
        val first = shorter.indices.firstOrNull { shorter[it] != longer[it] } ?: shorter.length
        return shorter.substring(first) == longer.substring(first + 1)
    }
}
