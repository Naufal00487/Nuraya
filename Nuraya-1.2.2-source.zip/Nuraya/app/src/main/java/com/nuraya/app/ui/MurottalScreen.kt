package com.nuraya.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nuraya.app.NurayaApplication
import com.nuraya.app.data.Qari
import com.nuraya.app.data.Surah
import com.nuraya.app.media.PlaybackState
import com.nuraya.app.storage.DownloadEntity
import com.nuraya.app.storage.UserEntry
import java.util.Locale

@Composable
fun MurottalScreen(app: NurayaApplication, language: String, qariId: String, onQari: (String) -> Unit,
    entries: List<UserEntry>, downloads: List<DownloadEntity>, playback: PlaybackState, perform: (suspend () -> Unit) -> Unit) {
    var query by rememberSaveable(qariId) { mutableStateOf("") }
    val qari = app.quran.qaris.firstOrNull { it.id == qariId }
    val matches = remember(query, qariId) { app.quran.surahs.filter { query.isBlank() || it.name.contains(query,true) || it.arabicName.contains(query) || it.id.toString() == query.trim() } }
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text(if (qari == null) label(language,"Temukan lantunan\npilihan Anda.","Find your\nfavourite recitation.") else qari.name, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text(if (qari == null) label(language,"${app.quran.qaris.size} pilihan rekaman · 114 surah per pilihan","${app.quran.qaris.size} recitation editions · 114 surahs each") else label(language,"114 surah · pilih untuk mendengarkan","114 surahs · choose one to listen"), color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (qari != null) Text(qari.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(value = query, onValueChange = { query = it.take(150) }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                shape = RoundedCornerShape(16.dp), leadingIcon = { Icon(Icons.Outlined.Search,null) },
                label = { Text(if (qari == null) label(language,"Cari qari","Search reciters") else label(language,"Cari surah","Search surahs")) })
        }
        if (qari != null) item {
            Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Outlined.Headphones, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                    Text(label(language,
                        "Ketuk surah untuk memutar melalui internet. Gunakan tombol unduh agar rekaman qari ini dapat didengarkan offline setelah unduhan selesai.",
                        "Tap a surah to stream over the internet. Use the download button to listen to this reciter offline once the download finishes."),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                }
            }
        }
        if (qari == null) {
            val qaris = app.quran.qaris.filter { it.name.contains(query,true) }
            items(qaris, key = { it.id }) { item ->
                OutlinedCard(onClick = { onQari(item.id) }, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().testTag("qari_${item.id}")) {
                    Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(58.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.GraphicEq, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                            Text(item.name, style = MaterialTheme.typography.titleMedium)
                            Text("${item.description} · ${label(language,"114 surah","114 surahs")}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Outlined.ChevronRight, null)
                    }
                }
            }
            if (qaris.isEmpty()) item { EmptyState(Icons.Outlined.SearchOff, label(language,"Qari tidak ditemukan","No reciters found"),label(language,"Coba kata pencarian lain.","Try a different search.")) }
            item { Text(label(language,"Sumber rekaman: Islamic Network. Internet diperlukan untuk streaming. Audio yang selesai diunduh dapat diputar offline.","Recordings from Islamic Network. Streaming requires internet. Completed downloads can be played offline."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            items(matches, key = { it.id }) { surah ->
                val key = "${qari.id}:${surah.id}"
                val favorite = entries.any { it.type == "audio_favorite" && it.key == key }
                val download = downloads.firstOrNull { it.id == key }
                val active = !playback.verseMode && playback.qariId == qari.id && playback.surahId == surah.id
                Surface(shape = RoundedCornerShape(18.dp), color = if (active) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerLow) {
                    Column {
                        Row(Modifier.fillMaxWidth().clickable { app.playback.play(surah,qari) }.padding(start=16.dp,top=12.dp,bottom=12.dp,end=4.dp),verticalAlignment=Alignment.CenterVertically) {
                            Box(Modifier.size(36.dp),contentAlignment=Alignment.Center) {
                                if (active && playback.isPlaying) Icon(Icons.Outlined.GraphicEq,null) else Text("${surah.id}",style=MaterialTheme.typography.labelLarge)
                            }
                            Column(Modifier.weight(1f).padding(horizontal=12.dp)) {
                                Text(surah.name,style=MaterialTheme.typography.titleMedium)
                                Text(if(download?.status=="complete") label(language,"Tersedia offline","Available offline") else "${surah.ayahCount} ${label(language,"ayat","verses")}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick={perform { app.library.toggle("audio_favorite",key,surah.name,qari.name,qari.id) }}) {
                                Icon(if(favorite) Icons.Outlined.Favorite else Icons.Outlined.FavoriteBorder,label(language,if(favorite)"Hapus favorit" else "Favoritkan",if(favorite)"Remove favourite" else "Favourite"),tint=MaterialTheme.colorScheme.primary)
                            }
                            IconButton(onClick={perform{app.downloads.enqueue(surah,qari)}},enabled=download?.status !in listOf("queued","downloading","complete")) {
                                Icon(if(download?.status=="complete")Icons.Outlined.DownloadDone else Icons.Outlined.Download,label(language,"Unduh audio","Download audio"))
                            }
                        }
                        if(download?.status in listOf("queued","downloading")) LinearProgressIndicator(progress={ (download?.progress ?: 0)/100f },modifier=Modifier.fillMaxWidth())
                    }
                }
            }
            if(matches.isEmpty()) item { EmptyState(Icons.Outlined.SearchOff,label(language,"Surah tidak ditemukan","No surahs found"),label(language,"Coba nama atau nomor surah.","Try a surah name or number.")) }
        }
    }
}

@Composable
fun MiniPlayer(state: PlaybackState, language: String, onOpen: () -> Unit, onToggle: () -> Unit) {
    Surface(tonalElevation=3.dp,color=MaterialTheme.colorScheme.primaryContainer) {
        Column {
            Row(Modifier.fillMaxWidth().clickable(onClick=onOpen).padding(start=18.dp,end=8.dp,top=6.dp,bottom=6.dp),verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Outlined.GraphicEq,null,tint=MaterialTheme.colorScheme.primary)
                Column(Modifier.weight(1f).padding(horizontal=14.dp)) {
                    Text(state.title,style=MaterialTheme.typography.titleSmall,maxLines=1,overflow=TextOverflow.Ellipsis)
                    Text(if(state.error!=null)label(language,"Audio belum dapat diputar","Audio playback unavailable") else state.qari,style=MaterialTheme.typography.bodySmall,maxLines=1,overflow=TextOverflow.Ellipsis)
                }
                if(state.loading) CircularProgressIndicator(Modifier.size(22.dp),strokeWidth=2.dp)
                IconButton(onClick=onToggle,modifier=Modifier.testTag("mini_player_toggle")) {
                    Icon(if(state.isPlaying)Icons.Outlined.Pause else Icons.Outlined.PlayArrow,label(language,if(state.isPlaying)"Jeda" else "Putar",if(state.isPlaying)"Pause" else "Play"))
                }
                IconButton(onClick=onOpen) { Icon(Icons.Outlined.KeyboardArrowUp,label(language,"Buka pemutar","Open player")) }
            }
            if(state.durationMs>0) LinearProgressIndicator(progress={ (state.positionMs.toFloat()/state.durationMs).coerceIn(0f,1f) },modifier=Modifier.fillMaxWidth().height(2.dp))
        }
    }
}

@Composable
fun FullPlayer(app: NurayaApplication, language: String, state: PlaybackState, entries: List<UserEntry>, downloads: List<DownloadEntity>, perform: (suspend () -> Unit) -> Unit, onClose: () -> Unit, onRead: (Int, Int) -> Unit = { _, _ -> }) {
    val surah = app.quran.surahs.firstOrNull { it.id==state.surahId }
    val qari = app.quran.qaris.firstOrNull { it.id==state.qariId }
    val key = "${state.qariId}:${state.surahId}"
    val favorite = entries.any { it.type=="audio_favorite" && it.key==key }
    val inCollection = entries.any { it.type=="playlist" && it.key==key }
    val download = downloads.firstOrNull { it.id==key }
    var seeking by remember { mutableStateOf<Float?>(null) }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal=28.dp,vertical=12.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(16.dp)) {
        Text(label(language,"SEDANG DIDENGARKAN","NOW LISTENING"),style=MaterialTheme.typography.labelMedium,letterSpacing=2.sp,color=MaterialTheme.colorScheme.secondary)
        Box(Modifier.fillMaxWidth().height(130.dp).background(MaterialTheme.colorScheme.primaryContainer,RoundedCornerShape(24.dp)),contentAlignment=Alignment.Center) {
            Text(surah?.arabicName ?: "Nuraya",fontFamily=QuranArabicFont,fontSize=38.sp,color=MaterialTheme.colorScheme.primary,textAlign=TextAlign.Center)
        }
        Column(horizontalAlignment=Alignment.CenterHorizontally) {
            Text(state.title,style=MaterialTheme.typography.headlineMedium,textAlign=TextAlign.Center)
            Text(state.qari,color=MaterialTheme.colorScheme.onSurfaceVariant,textAlign=TextAlign.Center)
            if (!state.verseMode && download?.status=="complete") Text(label(language,"Audio tersimpan di perangkat","Audio saved on this device"),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.primary)
            if (state.verseMode) {
                Text(label(language, "Ayat ${state.ayahId} · rentang ${state.rangeStart}–${state.rangeEnd}", "Verse ${state.ayahId} · range ${state.rangeStart}–${state.rangeEnd}"), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { onRead(state.surahId, state.ayahId.coerceAtLeast(1)) }) {
                    Icon(Icons.Outlined.MenuBook, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(label(language, "Ikuti teks bacaan", "Follow the recitation text"))
                }
            }
        }
        if(state.error!=null) Surface(color=MaterialTheme.colorScheme.errorContainer,shape=RoundedCornerShape(12.dp)) {
            Column(Modifier.padding(12.dp)) {
                Text(localizedError(state.error,language),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onErrorContainer)
                if (state.verseMode) TextButton(onClick = {
                    app.playback.playVerseRange(state.surahId, state.ayahId.coerceAtLeast(1), state.rangeEnd.coerceAtLeast(state.ayahId), state.qariId)
                }) { Text(label(language, "Coba lagi", "Try again")) }
                else if(surah!=null && qari!=null) TextButton(onClick={app.playback.play(surah,qari)}) { Text(label(language,"Coba lagi","Try again")) }
            }
        }
        Column {
            Slider(value=seeking ?: state.positionMs.toFloat().coerceIn(0f,state.durationMs.coerceAtLeast(1).toFloat()),
                onValueChange={seeking=it},onValueChangeFinished={seeking?.let{app.playback.seekTo(it.toLong())};seeking=null},
                valueRange=0f..state.durationMs.coerceAtLeast(1).toFloat(),enabled=state.durationMs>0)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text(formatDuration(state.positionMs),style=MaterialTheme.typography.labelMedium);Text(formatDuration(state.durationMs),style=MaterialTheme.typography.labelMedium) }
        }
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(22.dp)) {
            IconButton(onClick={app.playback.previous()},modifier=Modifier.size(48.dp)) { Icon(Icons.Outlined.SkipPrevious,if (state.verseMode) label(language,"Ayat sebelumnya","Previous verse") else label(language,"Surah sebelumnya","Previous surah"),modifier=Modifier.size(32.dp)) }
            FilledIconButton(onClick={app.playback.toggle()},modifier=Modifier.size(72.dp)) {
                if(state.loading)CircularProgressIndicator(Modifier.size(26.dp),color=MaterialTheme.colorScheme.onPrimary,strokeWidth=2.dp)
                else Icon(if(state.isPlaying)Icons.Outlined.Pause else Icons.Outlined.PlayArrow,label(language,if(state.isPlaying)"Jeda" else "Putar",if(state.isPlaying)"Pause" else "Play"),modifier=Modifier.size(38.dp))
            }
            IconButton(onClick={app.playback.next()},modifier=Modifier.size(48.dp)) { Icon(Icons.Outlined.SkipNext,if (state.verseMode) label(language,"Ayat berikutnya","Next verse") else label(language,"Surah berikutnya","Next surah"),modifier=Modifier.size(32.dp)) }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp),verticalAlignment=Alignment.CenterVertically) {
            FilterChip(selected=state.repeat,onClick={app.playback.setRepeat(!state.repeat)},label={Text(label(language,"Ulangi","Repeat"))},leadingIcon={Icon(Icons.Outlined.RepeatOne,null,Modifier.size(18.dp))})
            AssistChip(onClick={ val speeds=listOf(.75f,1f,1.25f,1.5f,2f);app.playback.setSpeed(speeds[(speeds.indexOf(state.speed)+1).mod(speeds.size)]) },label={Text("${state.speed}×")},leadingIcon={Icon(Icons.Outlined.Speed,null,Modifier.size(18.dp))})
            if (!state.verseMode) IconButton(onClick={if(surah!=null && qari!=null)perform { app.library.toggle("audio_favorite",key,surah.name,qari.name,qari.id) }}) {
                Icon(if(favorite)Icons.Outlined.Favorite else Icons.Outlined.FavoriteBorder,label(language,"Favorit","Favourite"))
            }
        }
        if(!state.verseMode && surah!=null && qari!=null) {
            Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick={perform{app.downloads.enqueue(surah,qari)}},enabled=download?.status !in listOf("complete","queued","downloading"),modifier=Modifier.weight(1f)) {
                    Icon(Icons.Outlined.Download,null,Modifier.size(18.dp));Spacer(Modifier.width(6.dp))
                    Text(if(download?.status=="complete")label(language,"Tersimpan","Saved") else label(language,"Unduh","Download"))
                }
                OutlinedButton(onClick={perform{app.library.toggle("playlist",key,surah.name,qari.name,qari.id)}},modifier=Modifier.weight(1f)) {
                    Icon(if(inCollection)Icons.Outlined.PlaylistAddCheck else Icons.Outlined.PlaylistAdd,null,Modifier.size(18.dp));Spacer(Modifier.width(6.dp));Text(label(language,"Koleksi","Collection"))
                }
            }
            if(download?.status in listOf("queued","downloading")) Text("${label(language,"Mengunduh","Downloading")} ${download?.progress ?: 0}%",style=MaterialTheme.typography.bodySmall)
        }
        Text(if (state.verseMode) "${state.source}\n${label(language, "Mode sinkron · membutuhkan internet", "Synchronized mode · requires internet")}" else "Islamic Network · alquran.cloud",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        TextButton(onClick={app.playback.stop();onClose()}) { Text(label(language,"Tutup pemutar","Close player")) }
        Spacer(Modifier.height(12.dp))
    }
}

fun formatDuration(ms:Long):String = String.format(Locale.ROOT,"%d:%02d",(ms/1000)/60,(ms/1000)%60)
fun localizedError(message:String,language:String):String = message.split(" / ",limit=2).let { if(language=="en")it.last() else it.first() }

@Composable fun EmptyState(icon: androidx.compose.ui.graphics.vector.ImageVector,title:String,description:String) {
    Column(Modifier.fillMaxWidth().padding(vertical=32.dp,horizontal=20.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Icon(icon,null,modifier=Modifier.size(44.dp),tint=MaterialTheme.colorScheme.primary)
        Text(title,style=MaterialTheme.typography.titleLarge,textAlign=TextAlign.Center)
        Text(description,style=MaterialTheme.typography.bodyMedium,textAlign=TextAlign.Center,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
