package com.nuraya.app.learning

import java.net.URI
import java.net.URLDecoder

/** Only known YouTube video/playlist URL shapes may supply IDs to the official player. */
data class YouTubeEmbed(val videoId: String? = null, val playlistId: String? = null) {
    init {
        require(videoId != null || playlistId != null)
        require(videoId == null || videoId.matches(Regex("[A-Za-z0-9_-]{11}")))
        require(playlistId == null || playlistId.matches(Regex("[A-Za-z0-9_-]{10,100}")))
    }

    companion object {
        const val ORIGIN = "https://com.nuraya.app"
        const val BASE_URL = "$ORIGIN/embedded-video/"

        fun parse(value: String): YouTubeEmbed? = runCatching {
            val uri = URI(value)
            require(uri.scheme == "https" && uri.userInfo == null && (uri.port == -1 || uri.port == 443))
            val host = uri.host?.lowercase() ?: return null
            require(host in setOf("youtube.com", "www.youtube.com", "m.youtube.com", "youtube-nocookie.com", "www.youtube-nocookie.com", "youtu.be"))
            val path = uri.path.orEmpty().trim('/').split('/')
            val query = uri.rawQuery.orEmpty().split('&').filter(String::isNotEmpty).map { part ->
                val pair = part.split('=', limit = 2)
                URLDecoder.decode(pair[0], "UTF-8") to URLDecoder.decode(pair.getOrElse(1) { "" }, "UTF-8")
            }
            require(query.map { it.first }.distinct().size == query.size)
            val params = query.toMap()
            val video = when {
                host == "youtu.be" && path.size == 1 -> path[0]
                path == listOf("watch") -> params["v"]
                path.size == 2 && path[0] in setOf("shorts", "embed", "live") && path[1] != "videoseries" -> path[1]
                path == listOf("playlist") || path == listOf("embed", "videoseries") -> null
                else -> return null // Channels and /courses cannot be embedded as a video.
            }
            YouTubeEmbed(video, params["list"])
        }.getOrNull()
    }

    /** All interpolated values are validated IDs or fixed app constants; no title/source HTML. */
    fun html(autoPlay: Boolean = false): String {
        val target = videoId ?: "videoseries"
        val listQuery = playlistId?.let { "&amp;list=$it" }.orEmpty()
        val cue = if (videoId != null) "player.cueVideoById({videoId:'$videoId'});"
            else "player.cuePlaylist({listType:'playlist',list:'$playlistId',index:0});"
        // A real iframe has explicit viewport bounds before the API connects. onReady
        // means the API is usable, not that a playlist/video has actually been cued.
        return """<!doctype html><html><head>
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta name="referrer" content="strict-origin-when-cross-origin">
        <style>html,body{position:fixed;inset:0;width:100%;height:100%;margin:0;padding:0;background:#000;overflow:hidden}#player{position:absolute;inset:0;display:block;width:100%;height:100%;border:0}</style>
        </head><body>
        <iframe id="player" title="YouTube video player" src="https://www.youtube-nocookie.com/embed/$target?enablejsapi=1&amp;autoplay=0&amp;controls=1&amp;playsinline=1&amp;fs=1&amp;rel=0&amp;origin=$ORIGIN$listQuery" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        <script>
        var player,nurayaActive=true,nurayaRequested=$autoPlay;
        var nurayaStatus={apiReady:false,ready:false,state:-1,error:0,blocked:false,playRequested:$autoPlay};
        function cueNurayaVideo(){if(player&&nurayaStatus.apiReady){$cue}}
        function playNurayaVideo(){nurayaRequested=true;nurayaStatus.playRequested=true;nurayaStatus.blocked=false;if(player&&nurayaStatus.apiReady&&nurayaActive){if(nurayaStatus.ready){player.playVideo();}else{cueNurayaVideo();}}}
        function pauseNurayaVideo(){nurayaRequested=false;nurayaStatus.playRequested=false;if(player&&player.pauseVideo&&nurayaStatus.apiReady){player.pauseVideo();}}
        function setNurayaActive(active){nurayaActive=!!active;if(!nurayaActive){pauseNurayaVideo();}}
        function onYouTubeIframeAPIReady(){player=new YT.Player('player',{events:{
          onReady:function(){nurayaStatus.apiReady=true;cueNurayaVideo();},
          onStateChange:function(e){nurayaStatus.state=e.data;if(e.data>=0){nurayaStatus.ready=true;}if(e.data===1){nurayaStatus.blocked=false;if(!nurayaActive){pauseNurayaVideo();}}if(e.data===5&&nurayaRequested&&nurayaActive){player.playVideo();}},
          onAutoplayBlocked:function(){nurayaStatus.blocked=true;nurayaRequested=false;},
          onError:function(e){nurayaStatus.error=e.data;nurayaRequested=false;}
        }});}
        document.addEventListener('visibilitychange',function(){if(document.hidden){pauseNurayaVideo();}});
        </script><script src="https://www.youtube.com/iframe_api" onerror="nurayaStatus.error=-1"></script>
        </body></html>""".trimIndent()
    }
}
