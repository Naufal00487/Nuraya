package com.nuraya.app.learning

import android.annotation.SuppressLint
import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nuraya.app.NurayaApplication
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.currentCoroutineContext
import org.json.JSONObject
import org.json.JSONTokener
import java.util.concurrent.atomic.AtomicBoolean

private data class YouTubeFullScreen(val view: View, val callback: WebChromeClient.CustomViewCallback)
private fun ytText(language: String, id: String, en: String) = if (language == "en") en else id

/** Official IFrame player only. Playback starts after entering a feed or tapping a play button. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeEmbeddedPlayer(
    embed: YouTubeEmbed,
    language: String,
    onWatched: () -> Unit,
    modifier: Modifier = Modifier,
    isActive: Boolean = true,
    autoPlay: Boolean = false,
    portrait: Boolean = false,
) {
    val context = LocalContext.current
    val app = context.applicationContext as NurayaApplication
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val audio by app.playback.state.collectAsStateWithLifecycle()
    val latestWatched by rememberUpdatedState(onWatched)
    val latestActive by rememberUpdatedState(isActive)
    var retry by remember(embed) { mutableIntStateOf(0) }
    var apiReady by remember(embed, retry) { mutableStateOf(false) }
    var ready by remember(embed, retry) { mutableStateOf(false) }
    var playerState by remember(embed, retry) { mutableIntStateOf(-1) }
    var error by remember(embed, retry) { mutableIntStateOf(0) }
    var slow by remember(embed, retry) { mutableStateOf(false) }
    var blocked by remember(embed, retry) { mutableStateOf(false) }
    var fullScreen by remember { mutableStateOf<YouTubeFullScreen?>(null) }
    fun closeFullScreen() {
        val current = fullScreen
        fullScreen = null
        current?.callback?.onCustomViewHidden()
    }
    val alive = remember(embed, retry) { AtomicBoolean(true) }
    val view = remember(embed, retry) {
        runCatching { WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundColor(android.graphics.Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            // Entering Shorts is an explicit request to watch. A regular lesson still
            // requires the in-app play button (or YouTube's own gesture).
            settings.mediaPlaybackRequiresUserGesture = !autoPlay
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.setSupportMultipleWindows(false)
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.safeBrowsingEnabled = true
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, false)
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(webView: WebView, request: WebResourceRequest): Boolean {
                    if (!request.isForMainFrame) return request.url.scheme !in setOf("https", "about")
                    if (request.hasGesture() && HttpsUrlPolicy.accepts(request.url.toString())) {
                        webView.evaluateJavascript("pauseNurayaVideo()", null)
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, request.url)) }
                    }
                    return true
                }
                override fun onReceivedError(webView: WebView, request: WebResourceRequest, failure: WebResourceError) {
                    if (alive.get() && request.isForMainFrame) error = -1
                }
                override fun onRenderProcessGone(webView: WebView, detail: RenderProcessGoneDetail): Boolean {
                    alive.set(false)
                    error = -2
                    return true
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(customView: View, callback: CustomViewCallback) {
                    if (!alive.get() || !latestActive || fullScreen != null) callback.onCustomViewHidden()
                    else fullScreen = YouTubeFullScreen(customView, callback)
                }
                override fun onHideCustomView() { closeFullScreen() }
            }
            loadDataWithBaseURL(YouTubeEmbed.BASE_URL, embed.html(autoPlay && isActive), "text/html", "UTF-8", null)
        } }.getOrNull()
    }
    if (view == null) {
        Text(ytText(language,
            "Pemutar belum tersedia. Aktifkan atau perbarui Android System WebView, lalu coba lagi.",
            "The player is unavailable. Enable or update Android System WebView, then retry."),
            modifier = modifier.padding(12.dp), color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodySmall)
        return
    }
    LaunchedEffect(view, isActive) {
        if (alive.get()) view.evaluateJavascript("setNurayaActive($isActive)", null)
        if (!isActive) closeFullScreen()
    }
    var audioObserved by remember(view) { mutableStateOf(false) }
    LaunchedEffect(view, audio.isPlaying) {
        val firstObservation = !audioObserved
        audioObserved = true
        if (alive.get() && audio.isPlaying) {
            // The state flow may still report the old murottal playback on feed entry.
            if (firstObservation && autoPlay && latestActive) app.playback.pause()
            else view.evaluateJavascript("pauseNurayaVideo()", null)
        }
    }
    LaunchedEffect(view) {
        var recorded = false
        var previousState = -1
        var stalledChecks = 0
        var wantsPlayback = autoPlay
        while (currentCoroutineContext().isActive) {
            if (alive.get() && latestActive && lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
                view.evaluateJavascript("JSON.stringify(window.nurayaStatus||{})") { encoded ->
                    if (!alive.get() || !latestActive || !lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) return@evaluateJavascript
                    runCatching {
                        val decoded = JSONTokener(encoded).nextValue() as? String ?: return@runCatching
                        val status = JSONObject(decoded)
                        apiReady = status.optBoolean("apiReady", false)
                        ready = status.optBoolean("ready", false)
                        blocked = status.optBoolean("blocked", false)
                        val code = status.optInt("error", 0)
                        if (code != 0) error = code
                        playerState = status.optInt("state", -1)
                        wantsPlayback = status.optBoolean("playRequested", false)
                        if (playerState == 1 && previousState != 1) {
                            app.playback.pause()
                            if (!recorded) { recorded = true; latestWatched() }
                        }
                        previousState = playerState
                    }
                }
                // API-ready alone must not hide a black/uninitialized video. This
                // also catches a wrapper/API script which never initialized.
                val stalled = !ready || playerState == 3 ||
                    (wantsPlayback && playerState !in setOf(0, 1, 2))
                stalledChecks = if (stalled) stalledChecks + 1 else 0
                slow = stalledChecks >= 40
            }
            delay(500)
        }
    }
    DisposableEffect(view, lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (alive.get()) when (event) {
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> {
                    view.evaluateJavascript("setNurayaActive(false)", null)
                    view.onPause()
                    closeFullScreen()
                }
                Lifecycle.Event.ON_RESUME -> {
                    view.onResume()
                    view.evaluateJavascript("setNurayaActive($latestActive)", null)
                }
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            alive.set(false)
            lifecycle.removeObserver(observer)
            closeFullScreen()
            runCatching {
                view.stopLoading()
                view.loadUrl("about:blank")
                (view.parent as? ViewGroup)?.removeView(view)
                view.destroy()
            }
        }
    }
    Column(modifier.background(MaterialTheme.colorScheme.surface), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (portrait) {
            // A bounded feed page reserves space for status/buttons outside the official player.
            Box(Modifier.weight(1f).fillMaxWidth()) {
                key(view) {
                    AndroidView(factory = { view }, modifier = Modifier.fillMaxSize().testTag("youtube_embedded_player"))
                }
            }
        } else BoxWithConstraints(Modifier.fillMaxWidth()) {
            val playerHeight = maxOf(220.dp, maxWidth * 9f / 16f)
            key(view) {
                AndroidView(factory = { view }, modifier = Modifier.fillMaxWidth().height(playerHeight)
                    .testTag("youtube_embedded_player"))
            }
        }
        val failed = error != 0 || slow
        val statusText = when {
            error == 100 -> ytText(language, "Video ini tidak tersedia.", "This video is unavailable.")
            error == 101 || error == 150 -> ytText(language,
                "Penerbit membatasi pemutaran video ini di aplikasi.", "The publisher restricts playback in apps.")
            error == 153 -> ytText(language,
                "YouTube belum menerima identitas pemutar. Coba muat ulang.", "YouTube did not accept this player's identity. Retry loading.")
            failed -> ytText(language,
                "Video belum berhasil dimuat. Periksa koneksi atau muat ulang.", "The video has not loaded. Check your connection or retry.")
            blocked -> ytText(language, "Tekan Putar untuk mulai menonton di sini.", "Tap Play to start watching here.")
            playerState == 1 -> null
            playerState == 3 -> ytText(language, "Memuat video…", "Buffering video…")
            ready -> ytText(language, "Putar video di sini.", "Play the video here.")
            else -> ytText(language, "Menyiapkan video YouTube…", "Loading YouTube video…")
        }
        if (statusText != null) Text(statusText, modifier = Modifier.padding(horizontal = if (portrait) 12.dp else 0.dp)
            .testTag("youtube_player_status"), style = MaterialTheme.typography.bodySmall,
            color = if (failed) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
        if (failed && portrait) Text(ytText(language,
            "Geser ke video berikutnya atau coba lagi di sini.", "Swipe to the next video or retry here."),
            modifier = Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.bodySmall)
        if (playerState != 1 || failed) Row(
            Modifier.fillMaxWidth().padding(horizontal = if (portrait) 12.dp else 0.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (error == 0) FilledTonalButton(
                enabled = apiReady && isActive && alive.get(),
                onClick = {
                    app.playback.pause()
                    // This explicit tap is the user gesture authorizing playback.
                    view.settings.mediaPlaybackRequiresUserGesture = false
                    view.evaluateJavascript("setNurayaActive(true);playNurayaVideo()", null)
                    slow = false
                }, modifier = Modifier.testTag("youtube_play"),
            ) { Text(ytText(language, if (playerState == 0) "Putar lagi" else "Putar", if (playerState == 0) "Replay" else "Play")) }
            TextButton(onClick = { retry++ }, modifier = Modifier.testTag("youtube_retry")) {
                Text(ytText(language, "Muat ulang", "Retry"))
            }
        }
    }
    fullScreen?.let { custom ->
        Dialog(onDismissRequest = ::closeFullScreen,
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
            key(custom.view) {
                AndroidView(factory = { FrameLayout(it).apply {
                    (custom.view.parent as? ViewGroup)?.removeView(custom.view)
                    addView(custom.view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                } }, modifier = Modifier.fillMaxSize())
            }
        }
    }
}
