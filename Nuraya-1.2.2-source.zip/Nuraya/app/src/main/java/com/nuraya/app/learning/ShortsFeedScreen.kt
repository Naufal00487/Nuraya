package com.nuraya.app.learning

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private fun shortsText(language: String, id: String, en: String) = if (language == "en") en else id

/** A foreground-only feed: exactly the settled visible page owns a YouTube player. */
@Composable
internal fun ShortsFeedScreen(
    items: List<VideoItem>,
    language: String,
    initialId: String?,
    query: String,
    onQueryChange: (String) -> Unit,
    hasFilters: Boolean,
    guidance: String?,
    onClearFilters: () -> Unit,
    onBack: () -> Unit,
    savedIds: Set<String>,
    operationError: Boolean,
    onToggleSaved: (VideoItem) -> Unit,
    onWatched: (VideoItem) -> Unit,
    onCurrentItem: (String) -> Unit = {},
    playerContent: @Composable (VideoItem, Modifier) -> Unit = { item, modifier ->
        YouTubeEmbeddedPlayer(
            embed = requireNotNull(YouTubeEmbed.parse(item.originalUrl)), language = language,
            onWatched = { onWatched(item) }, modifier = modifier, portrait = true, autoPlay = true,
        )
    },
) {
    var searching by rememberSaveable { mutableStateOf(query.isNotBlank()) }
    Column(Modifier.fillMaxSize().testTag("shorts_feed")) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("shorts_back")) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, shortsText(language, "Kembali ke video", "Back to videos"))
            }
            Column(Modifier.weight(1f)) {
                Text("Shorts", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text(shortsText(language, "Geser ke atas untuk video berikutnya", "Swipe up for the next video"),
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { searching = !searching }, modifier = Modifier.testTag("shorts_search_toggle")) {
                Icon(Icons.Outlined.Search, shortsText(language, "Cari Shorts", "Search Shorts"))
            }
        }
        if (searching) {
            OutlinedTextField(
                value = query, onValueChange = onQueryChange, singleLine = true,
                label = { Text(shortsText(language, "Cari pelajaran singkat", "Find a short lesson")) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).testTag("shorts_search"),
            )
        }
        if (hasFilters) Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(shortsText(language, "Mengikuti pencarian & filter video", "Using your video search & filters"),
                modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
            TextButton(onClick = onClearFilters, modifier = Modifier.testTag("shorts_clear_filters")) {
                Text(shortsText(language, "Hapus filter", "Clear filters"))
            }
        }
        if (operationError) Text(shortsText(language, "Perubahan belum dapat disimpan. Coba lagi.", "Could not save the change. Please retry."),
            modifier = Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.error)

        if (items.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(28.dp).testTag("shorts_empty"),
                verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.PlayCircle, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                Text(shortsText(language, "Belum ada Shorts yang cocok", "No matching Shorts yet"),
                    Modifier.padding(top = 16.dp), style = MaterialTheme.typography.titleLarge)
                Text(guidance ?: shortsText(language,
                    "Coba topik lain atau hapus filter. Hanya video pendek dalam katalog belajar Al-Qur’an yang ditampilkan.",
                    "Try another topic or clear filters. Only short videos from the Quran learning catalogue are shown."),
                    Modifier.padding(top = 12.dp), style = MaterialTheme.typography.bodyMedium)
            }
            return@Column
        }

        // Re-key after search/removal so page indices never point outside the new result set.
        key(items.map { it.id }) {
            val pager = rememberPagerState(initialPage = items.indexOfFirst { it.id == initialId }.coerceAtLeast(0)) {
                items.size
            }
            val scope = rememberCoroutineScope()
            LaunchedEffect(pager.settledPage) { onCurrentItem(items[pager.settledPage].id) }
            VerticalPager(
                state = pager, key = { items[it].id }, beyondViewportPageCount = 0,
                modifier = Modifier.weight(1f).fillMaxWidth().testTag("shorts_pager"),
            ) { page ->
                val item = items[page]
                val active = pager.settledPage == page && !pager.isScrollInProgress
                Column(Modifier.fillMaxSize().testTag("shorts_page_${item.id}")) {
                    Box(Modifier.weight(1f).fillMaxWidth().background(Color.Black)) {
                        if (active) key(item.id) {
                            // User opened the Shorts feed; play is attempted inside the app.
                            // Leaving this page disposes its WebView before another page starts.
                            playerContent(item, Modifier.fillMaxSize().testTag("shorts_active_${item.id}"))
                        } else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.PlayCircle, null, Modifier.size(56.dp), tint = Color.White)
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(item.title(language), style = MaterialTheme.typography.titleMedium,
                                maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(item.speaker, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(item.audioLanguageLabel(language), style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { onToggleSaved(item) }) {
                            Icon(if (item.id in savedIds) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                                shortsText(language, if (item.id in savedIds) "Hapus dari Tonton nanti" else "Simpan untuk Tonton nanti",
                                    if (item.id in savedIds) "Remove from Watch later" else "Save to Watch later"))
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(enabled = pager.settledPage > 0 && !pager.isScrollInProgress,
                    onClick = { scope.launch { pager.animateScrollToPage(pager.settledPage - 1) } },
                    modifier = Modifier.testTag("shorts_previous")) {
                    Icon(Icons.Filled.KeyboardArrowUp, shortsText(language, "Shorts sebelumnya", "Previous Short"))
                }
                Text("${pager.settledPage + 1} / ${items.size}", modifier = Modifier.testTag("shorts_position"),
                    style = MaterialTheme.typography.labelMedium)
                IconButton(enabled = pager.settledPage < items.lastIndex && !pager.isScrollInProgress,
                    onClick = { scope.launch { pager.animateScrollToPage(pager.settledPage + 1) } },
                    modifier = Modifier.testTag("shorts_next")) {
                    Icon(Icons.Filled.KeyboardArrowDown, shortsText(language, "Shorts berikutnya", "Next Short"))
                }
                Spacer(Modifier.width(8.dp))
                Text(shortsText(language, "YouTube · perlu internet", "YouTube · internet required"),
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
