package com.nuraya.app.qa

import android.annotation.SuppressLint
import android.os.SystemClock
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.nuraya.app.learning.YouTubeEmbed
import com.nuraya.app.recitation.QuranAiModel
import com.nuraya.app.recitation.ai.QuranWhisperEngine
import java.io.ByteArrayInputStream
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import org.json.JSONTokener
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Real Android WebView/JNI checks. The iframe service is deliberately LOCAL and
 * controlled: this proves wrapper rendering and state transitions, not YouTube
 * availability, publisher permission, streaming, or physical microphone input.
 */
@RunWith(AndroidJUnit4::class)
class QaMediaRuntimeTest {
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()

    @SuppressLint("SetJavaScriptEnabled")
    @Test(timeout = 120_000)
    fun realWebViewKeepsIframeVisibleAndRequiresCueBeforeReady() {
        // ui-test-manifest declares this small activity in the debug APK. Avoid
        // the main screen's Quran rendering so this check isolates the WebView.
        val scenario = ActivityScenario.launch(ComponentActivity::class.java)
        var view: WebView? = null
        try {
            scenario.onActivity { activity ->
                val density = activity.resources.displayMetrics.density
                val web = WebView(activity).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(webView: WebView, request: WebResourceRequest): WebResourceResponse {
                            val script = request.url.toString() == "https://www.youtube.com/iframe_api"
                            val content = if (script) FAKE_IFRAME_API else
                                "<!doctype html><html><body style='margin:0;background:#165b35'>Controlled iframe fixture</body></html>"
                            // Every subresource is fulfilled here; no external service is contacted.
                            return WebResourceResponse(if (script) "application/javascript" else "text/html", "UTF-8",
                                ByteArrayInputStream(content.toByteArray(Charsets.UTF_8)))
                        }
                    }
                }
                view = web
                activity.setContentView(FrameLayout(activity).apply {
                    addView(web, FrameLayout.LayoutParams((320 * density).toInt(), (220 * density).toInt()))
                })
                web.loadDataWithBaseURL(YouTubeEmbed.BASE_URL,
                    YouTubeEmbed(playlistId = "PLSzUb0TgsIYsxT5mMj1KSFDXUEJ3psMCU").html(),
                    "text/html", "UTF-8", null)
            }
            val web = requireNotNull(view)
            val initial = awaitJson(web, "API did not connect to the controlled fixture") {
                it.optJSONObject("status")?.optBoolean("apiReady") == true && it.optInt("cueCount") == 1
            }
            assertFalse("An API connection alone must not claim video readiness", initial.getJSONObject("status").getBoolean("ready"))
            assertEquals("playlist", initial.getJSONObject("lastCue").getString("listType"))
            assertEquals("PLSzUb0TgsIYsxT5mMj1KSFDXUEJ3psMCU", initial.getJSONObject("lastCue").getString("list"))
            assertViewportFilled(initial)

            evaluate(web, "window.__qaEmit(5); true")
            awaitJson(web, "Cued state did not become ready") { it.optJSONObject("status")?.optBoolean("ready") == true }
            evaluate(web, "playNurayaVideo(); true")
            awaitJson(web, "In-app play command did not reach the iframe API") { it.optJSONObject("status")?.optInt("state") == 1 }
            evaluate(web, "setNurayaActive(false); true")
            awaitJson(web, "Leaving the active page did not pause the player") { it.optJSONObject("status")?.optInt("state") == 2 }

            scenario.onActivity { activity ->
                val density = activity.resources.displayMetrics.density
                web.layoutParams = FrameLayout.LayoutParams((220 * density).toInt(), (400 * density).toInt())
            }
            val portrait = awaitJson(web, "Portrait player did not receive its new viewport") {
                it.optDouble("viewportHeight") > it.optDouble("viewportWidth")
            }
            assertViewportFilled(portrait)
        } finally {
            scenario.onActivity { activity ->
                activity.setContentView(FrameLayout(activity))
                view?.stopLoading()
                view?.destroy()
            }
            scenario.close()
        }
    }

    /** Requires a real, separately copied fixture; missing/incorrect files fail instead of skipping. */
    @Test(timeout = 120_000)
    fun packagedNativeEngineLoadsVerifiedModelAndHandlesSilence() = runBlocking {
        val context = instrumentation.targetContext
        val configuredPath = InstrumentationRegistry.getArguments().getString("nurayaModelPath")
        val model = configuredPath?.let(::File)
            ?: File(context.filesDir, "qa/${QuranAiModel.spec.fileName}")
        assertTrue("Copy the verified model to ${model.absolutePath} or pass -e nurayaModelPath <path>", model.isFile)
        assertEquals("Model fixture length", QuranAiModel.spec.bytes, model.length())
        val digest = MessageDigest.getInstance("SHA-256")
        model.inputStream().buffered().use { input ->
            val buffer = ByteArray(128 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        assertEquals("Model fixture checksum", QuranAiModel.spec.sha256,
            digest.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) })
        assertTrue("The packaged library must load on this Android ABI", QuranWhisperEngine.isSupported())
        QuranWhisperEngine(model.absolutePath).use { engine ->
            assertEquals("", withTimeout(30_000) { engine.transcribe(FloatArray(16_000)) })
            engine.cancel()
            assertEquals("Cancellation must not poison the next request", "",
                withTimeout(30_000) { engine.transcribe(FloatArray(16_000)) })
        }
        // No spoken fixture is decoded here: software-emulator timing is not a phone benchmark.
    }

    private fun assertViewportFilled(result: JSONObject) {
        val width = result.getDouble("viewportWidth")
        val height = result.getDouble("viewportHeight")
        assertTrue("Player viewport is too small: $result", width >= 200 && height >= 200)
        assertTrue("Iframe width must fill the visible WebView: $result", result.getDouble("width") >= width - 2)
        assertTrue("Iframe height must fill the visible WebView: $result", result.getDouble("height") >= height - 2)
        assertEquals(0.0, result.getDouble("left"), 2.0)
        assertEquals(0.0, result.getDouble("top"), 2.0)
    }

    private fun awaitJson(view: WebView, message: String, predicate: (JSONObject) -> Boolean): JSONObject {
        val until = SystemClock.elapsedRealtime() + 30_000
        var latest = JSONObject()
        while (SystemClock.elapsedRealtime() < until) {
            latest = runCatching { JSONObject(evaluate(view, SNAPSHOT) as? String ?: "{}") }.getOrDefault(JSONObject())
            if (predicate(latest)) return latest
            SystemClock.sleep(100)
        }
        throw AssertionError("$message; last snapshot: $latest")
    }

    private fun evaluate(view: WebView, script: String): Any? {
        val latch = CountDownLatch(1)
        val value = AtomicReference<String>()
        instrumentation.runOnMainSync {
            view.evaluateJavascript(script) { result -> value.set(result); latch.countDown() }
        }
        assertTrue("WebView JavaScript did not return", latch.await(10, TimeUnit.SECONDS))
        return JSONTokener(value.get()).nextValue()
    }

    companion object {
        private val SNAPSHOT = """
            JSON.stringify((function(){var f=document.getElementById('player'),r=f?f.getBoundingClientRect():{};
            return {status:window.nurayaStatus,cueCount:window.__qaCueCount||0,lastCue:window.__qaLastCue||{},
            viewportWidth:window.innerWidth,viewportHeight:window.innerHeight,width:r.width||0,height:r.height||0,left:r.left||0,top:r.top||0};})())
        """.trimIndent()
        private val FAKE_IFRAME_API = """
            window.__qaCueCount=0;
            window.YT={Player:function(id,options){
              var events=options.events,self=this;
              window.__qaEmit=function(state){events.onStateChange({data:state,target:self});};
              this.cuePlaylist=function(value){window.__qaCueCount++;window.__qaLastCue=value;};
              this.cueVideoById=function(value){window.__qaCueCount++;window.__qaLastCue=value;};
              this.playVideo=function(){window.__qaEmit(1);};
              this.pauseVideo=function(){window.__qaEmit(2);};
              setTimeout(function(){events.onReady({target:self});},10);
            }};
            onYouTubeIframeAPIReady();
        """.trimIndent()
    }
}
