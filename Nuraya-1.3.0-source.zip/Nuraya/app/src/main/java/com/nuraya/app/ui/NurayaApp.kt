package com.nuraya.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nuraya.app.NurayaApplication
import com.nuraya.app.learning.LearningScreen
import com.nuraya.app.prayer.PrayerScreen
import com.nuraya.app.quranreading.QuranModesScreen
import com.nuraya.app.quranreading.QuranReadingModes
import com.nuraya.app.quranreading.BahriyahPdfScreen
import com.nuraya.app.study.PracticeScreen
import com.nuraya.app.recitation.RecitationPracticeScreen
import com.nuraya.app.storage.UserSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NurayaApp(app: NurayaApplication, settings: UserSettings) {
    val language = settings.language
    var screen by rememberSaveable { mutableStateOf("home") }
    var readerFrom by rememberSaveable { mutableStateOf("quran") }
    var surahId by rememberSaveable { mutableIntStateOf(1) }
    var ayahId by rememberSaveable { mutableIntStateOf(1) }
    var juzId by rememberSaveable { mutableIntStateOf(0) }
    var qariId by rememberSaveable { mutableStateOf("") }
    var readingModeId by rememberSaveable { mutableStateOf("standard") }
    var settingsFrom by rememberSaveable { mutableStateOf("home") }
    var playerVisible by rememberSaveable { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    val screenState = rememberSaveableStateHolder()
    val entries by app.library.entries.collectAsStateWithLifecycle(emptyList())
    val downloads by app.downloads.downloads.collectAsStateWithLifecycle(emptyList())
    val playback by app.playback.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val perform: (suspend () -> Unit) -> Unit = { block -> scope.launch {
        try { block() } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            snackbar.showSnackbar(label(language, "Tindakan belum berhasil. Coba kembali.", "That action could not be completed. Please try again."))
        }
    } }
    LaunchedEffect(retry) {
        loading = true
        loadError = false
        try { withContext(Dispatchers.IO) { app.quran.surahs; app.quran.verses(1) } }
        catch (e: Exception) { if (e is kotlinx.coroutines.CancellationException) throw e; loadError = true }
        loading = false
    }
    val openVerse: (Int, Int) -> Unit = { surah, ayah ->
        if (screen != "reader") readerFrom = screen
        if (screen !in listOf("reader", "surahs", "quran")) readingModeId = "standard"
        surahId = surah; ayahId = ayah; juzId = 0
        screen = if (screen == "surahs" && readingModeId in setOf("madinah", "madinah_tajwid")) "mushaf" else "reader"
    }
    val back: () -> Unit = {
        when {
            screen == "reader" -> screen = readerFrom
            screen == "mushaf" -> screen = "surahs"
            screen == "bahriyah" -> screen = "quran"
            screen == "surahs" -> screen = "quran"
            screen == "settings" -> screen = settingsFrom
            screen == "murottal" && qariId.isNotEmpty() -> qariId = ""
            else -> screen = "home"
        }
    }
    BackHandler(screen != "home" && !playerVisible) { back() }
    val titles = mapOf("home" to "NURAYA", "quran" to "Al-Qur’an", "murottal" to "Murottal",
        "prayer" to label(language, "Salat & kiblat", "Prayer & qibla"),
        "surahs" to QuranReadingModes.find(readingModeId).title(language),
        "mushaf" to QuranReadingModes.find(readingModeId).title(language),
        "bahriyah" to QuranReadingModes.find("bahriyah").title(language),
        "library" to label(language, "Koleksi saya", "My collection"),
        "settings" to label(language, "Pengaturan", "Settings"),
        "learn" to label(language, "Teman belajar", "Learning companion"),
        "practice" to label(language, "Latihan & hafalan", "Practice & memorization"),
        "recitation" to label(language, "AI bacaan", "Recitation AI"),
        "reader" to if (juzId > 0) "Juz $juzId" else if (!loading && !loadError) app.quran.surahs.firstOrNull { it.id == surahId }?.name.orEmpty() else "Al-Qur’an")
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(title = { Text(titles[screen].orEmpty(), style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis) },
                navigationIcon = {
                    if (screen !in listOf("home", "quran", "murottal", "prayer") || screen == "murottal" && qariId.isNotEmpty()) {
                        TextButton(onClick = back, modifier = Modifier.testTag("back_button")) {
                            Icon(Icons.AutoMirrored.Outlined.ArrowBack, null)
                            Text(label(language,"Kembali","Back"))
                        }
                    }
                }, actions = {
                    if (screen != "settings") TextButton(onClick = { settingsFrom = screen; screen = "settings" }, modifier = Modifier.testTag("settings_button")) {
                        Text(label(language, "Atur", "Settings"))
                    }
                }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background))
        },
        bottomBar = {
            Column {
                if (playback.surahId > 0) MiniPlayer(playback, language, onOpen = { playerVisible = true }, onToggle = { app.playback.toggle() })
                if (screen !in listOf("reader", "mushaf", "bahriyah", "learn", "practice", "recitation")) NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp) {
                    val items = listOf(
                        Triple("home", label(language, "Beranda", "Home"), Icons.Outlined.Home),
                        Triple("quran", "Al-Qur’an", Icons.Outlined.MenuBook),
                        Triple("murottal", "Murottal", Icons.Outlined.Headphones),
                        Triple("prayer", label(language, "Ibadah", "Prayer"), Icons.Outlined.Explore)
                    )
                    items.forEach { (key, title, icon) ->
                        NavigationBarItem(selected = screen == key || (key == "quran" && screen == "surahs"), onClick = { screen = key },
                            icon = { Icon(icon, null) }, label = { Text(title, style = MaterialTheme.typography.labelSmall, maxLines = 2) },
                            modifier = Modifier.testTag("nav_$key"))
                    }
                }
            }
        }
    ) { insets ->
        Box(Modifier.fillMaxSize().padding(insets), contentAlignment = Alignment.TopCenter) {
            Box(Modifier.widthIn(max = 840.dp).fillMaxSize()) {
                when {
                    loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    loadError -> Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(label(language, "Data bacaan belum dapat dibuka.", "The reading data could not be opened."))
                        Button(onClick = { retry++ }) { Text(label(language, "Coba lagi", "Try again")) }
                    }
                    else -> screenState.SaveableStateProvider(
                        if (screen in setOf("reader", "mushaf")) "$screen:$readingModeId:$surahId:$ayahId:$juzId" else screen
                    ) { when(screen) {
                        "home" -> HomeScreen(app, language, entries, onRead = openVerse, onNavigate = { if (it == "settings") settingsFrom = "home"; screen = it })
                        "quran" -> QuranModesScreen(app, language,
                            onMode = { readingModeId = it; screen = if (it == "bahriyah") "bahriyah" else "surahs" },
                            onRead = { surah, ayah -> readingModeId = "indonesia"; openVerse(surah, ayah) })
                        "surahs" -> QuranScreen(app.quran, language, onRead = openVerse, onJuz = {
                            readerFrom = "surahs"
                            if (readingModeId in setOf("madinah", "madinah_tajwid")) {
                                val first = app.quran.juz(it).first()
                                surahId = first.surah; ayahId = first.ayah; juzId = 0; screen = "mushaf"
                            } else { juzId = it; ayahId = 1; screen = "reader" }
                        }, readingModeId = readingModeId, onChooseMode = { screen = "quran" })
                        "mushaf" -> MadinahScreen(language, surahId, ayahId,
                            showTajwidCompanion = readingModeId == "madinah_tajwid",
                            onReadVerses = { surah, ayah ->
                                readerFrom = "mushaf"; surahId = surah; ayahId = ayah; juzId = 0; screen = "reader"
                            })
                        "bahriyah" -> BahriyahPdfScreen(language)
                        "reader" -> ReaderScreen(app, settings, surahId, ayahId, juzId, entries, perform, onRead = openVerse,
                            playback = playback, readingModeId = readingModeId,
                            onPracticeRange = { surah, start, end, repeats ->
                                app.playback.playVerseRange(surah, start, end, settings.readerQariId, repeats)
                            },
                            onPlayVerse = { surah, ayah ->
                                app.playback.playVerseRange(surah, ayah, app.quran.surahs[surah - 1].ayahCount, settings.readerQariId)
                            }, onToggleAudio = { app.playback.toggle() },
                            reciterChoices = app.playback.verseReciters.map { it.id to it.name },
                            wordSyncReciterIds = app.playback.verseReciters.filter { it.supportsWordSync }.map { it.id }.toSet())
                        "murottal" -> MurottalScreen(app, language, qariId, onQari = { qariId = it }, entries, downloads, playback, perform)
                        "prayer" -> PrayerScreen(language)
                        "library" -> LibraryScreen(app, language, entries, downloads, perform, onRead = openVerse)
                        "settings" -> SettingsScreen(app, settings, perform, onLearn = { screen = "learn" })
                        "learn" -> LearningScreen(language, onBack = back, onRead = openVerse)
                        "practice" -> PracticeScreen(app, language, onRead = openVerse,
                            onPracticeRange = { surah, start, end, repeats ->
                                app.playback.playVerseRange(surah, start, end, settings.readerQariId, repeats)
                                openVerse(surah, start)
                            })
                        "recitation" -> RecitationPracticeScreen(app, language, onRead = openVerse)
                    } }
                }
            }
        }
    }
    if (playerVisible && !loading && !loadError) {
        ModalBottomSheet(onDismissRequest = { playerVisible = false }) {
            FullPlayer(app, language, playback, entries, downloads, perform, onClose = { playerVisible = false },
                onRead = { surah, ayah -> playerVisible = false; openVerse(surah, ayah) })
        }
    }
}
