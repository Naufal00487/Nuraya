package com.nuraya.app.qa

import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextEquals
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeUp
import com.nuraya.app.NurayaApplication
import com.nuraya.app.learning.VideoLibraryScreen
import com.nuraya.app.ui.NurayaTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode

/** Real feed navigation with a controlled player; no YouTube playback is claimed by this test. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = NurayaApplication::class, qualifiers = "w411dp-h891dp")
@LooperMode(LooperMode.Mode.PAUSED)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ShortsFeedPresentationTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()

    @Test fun swipeReplacesTheOnlyPlayerAndBackRestoresTheCurrentShort() {
        val activePlayers = mutableSetOf<String>()
        var maximumPlayers = 0
        compose.setContent { NurayaTheme { Surface {
            VideoLibraryScreen("id", shortsPlayerContent = { item, modifier, _ ->
                DisposableEffect(item.id) {
                    activePlayers.add(item.id)
                    maximumPlayers = maxOf(maximumPlayers, activePlayers.size)
                    onDispose { activePlayers.remove(item.id) }
                }
                Box(modifier) { Text("Pemutar uji: ${item.id}") }
            })
        } } }
        compose.onNodeWithTag("video_open_shorts").performScrollTo().performClick()
        compose.onNodeWithTag("shorts_position").assertTextEquals("1 / 3")
        compose.onNodeWithText("Buka sumber asli").assertDoesNotExist()
        compose.runOnIdle { assertEquals(setOf("short-surah-112"), activePlayers) }

        compose.onNodeWithTag("shorts_pager").performTouchInput { swipeUp() }
        compose.waitForIdle()
        compose.onNodeWithTag("shorts_position").assertTextEquals("2 / 3")
        compose.runOnIdle {
            assertEquals(setOf("short-surah-108"), activePlayers)
            assertEquals(1, maximumPlayers)
        }

        compose.onNodeWithTag("shorts_back").performClick()
        compose.onNodeWithTag("video_catalog").assertIsDisplayed()
        compose.runOnIdle { assertTrue(activePlayers.isEmpty()) }
        compose.onNodeWithTag("video_open_shorts").performScrollTo().performClick()
        compose.onNodeWithTag("shorts_position").assertTextEquals("2 / 3")
        compose.runOnIdle { assertEquals(setOf("short-surah-108"), activePlayers) }
    }
}
