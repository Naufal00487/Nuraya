#!/usr/bin/env python3
"""Package the actual Gradle APK and reviewable sources; never manufacture an APK."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
APK = ROOT / "app/build/outputs/apk/debug/app-debug.apk"
OUTPUT = ROOT / "artifacts"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    if not APK.is_file() or APK.stat().st_size < 100_000:
        raise SystemExit("Build the APK first: bash scripts/gradle.sh assembleDebug")
    source_names = subprocess.check_output(
        ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"], cwd=ROOT,
    ).decode().split("\0")
    files = sorted({name for name in source_names if name and (ROOT / name).is_file()})
    build_inputs = [ROOT / name for name in files if name.startswith("app/src/main/") or name.endswith(".gradle.kts") or name == "gradle.properties"]
    newer = [str(path.relative_to(ROOT)) for path in build_inputs if path.stat().st_mtime > APK.stat().st_mtime]
    if newer:
        raise SystemExit("APK predates source changes. Rebuild before packaging: " + ", ".join(newer))
    with zipfile.ZipFile(APK) as archive:
        names = set(archive.namelist())
        if not {"AndroidManifest.xml", "classes.dex", "assets/quran.json"}.issubset(names):
            raise SystemExit("Unexpected or incomplete Android APK")
        if archive.read("assets/quran.json") != (ROOT / "app/src/main/assets/quran.json").read_bytes():
            raise SystemExit("APK contains a different Quran corpus than the source tree")
        if "assets/alafasy1.mp3" in names:
            raise SystemExit("Instrumentation fixture must not be packaged in the app")
    OUTPUT.mkdir(exist_ok=True)
    result_apk = OUTPUT / "nuraya-1.0.0-debug.apk"
    source_zip = OUTPUT / "nuraya-source.zip"
    shutil.copy2(APK, result_apk)
    source_hashes = {}
    with zipfile.ZipFile(source_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in files:
            path = ROOT / name
            if not path.resolve().is_relative_to(ROOT):
                raise SystemExit(f"Source path leaves checkout: {name}")
            if any(part in {".git", ".gradle", ".kotlin", "build", "__pycache__", "artifacts"} for part in path.relative_to(ROOT).parts):
                continue
            archive.write(path, "Nuraya/" + name)
            source_hashes[name] = sha256(path)
    with zipfile.ZipFile(source_zip) as archive:
        if archive.testzip() is not None:
            raise SystemExit("Source ZIP integrity check failed")
    info = {
        "applicationId": "com.nuraya.app", "versionName": "1.0.0", "versionCode": 1,
        "buildType": "debug", "minimumAndroidApi": 26, "targetAndroidApi": 35,
        "apk": {"file": result_apk.name, "bytes": result_apk.stat().st_size, "sha256": sha256(result_apk)},
        "sources": {"file": source_zip.name, "bytes": source_zip.stat().st_size, "sha256": sha256(source_zip)},
        "sourceFiles": source_hashes,
        "validationReport": "docs/BUILD_VALIDATION.md",
    }
    (OUTPUT / "build-info.json").write_text(json.dumps(info, indent=2) + "\n")
    (OUTPUT / "SHA256SUMS").write_text("".join(f"{sha256(p)}  {p.name}\n" for p in [result_apk, source_zip, OUTPUT / "build-info.json"]))
    for path in [result_apk, source_zip]:
        print(f"{path}: {path.stat().st_size:,} bytes; SHA-256 {sha256(path)}")


if __name__ == "__main__":
    main()
