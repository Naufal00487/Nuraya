package com.nuraya.app.learning

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nuraya.app.NurayaApplication
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private fun learningText(language: String, id: String, en: String) = if (language == "en") en else id

@Composable
fun LearningScreen(language: String, onBack: () -> Unit) {
    val application = LocalContext.current.applicationContext as NurayaApplication
    val repository = remember(application) { LearningRepository(application, application.quran) }
    val scope = rememberCoroutineScope()
    var question by rememberSaveable { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var answer by remember { mutableStateOf<LearningAnswer?>(null) }
    var failure by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp)) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, learningText(language, "Kembali", "Back"))
            }
            Column(Modifier.padding(start = 8.dp)) {
                Text(learningText(language, "RUANG BELAJAR", "LEARNING SPACE"),
                    style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Text(learningText(language, "Temukan pemahaman", "Explore understanding"),
                    style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            }
        }
        Card(
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        ) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Icon(Icons.Outlined.AutoAwesome, contentDescription = null,
                    Modifier.size(32.dp), tint = MaterialTheme.colorScheme.primary)
                Text(
                    learningText(language, "Belajar dengan rujukan", "Learn with source references"),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(learningText(language,
                    "Ruang untuk bertanya dan memahami. Teks Al-Qur'an ditampilkan terpisah dari penjelasan AI, langsung dari sumber yang tersimpan di Nuraya.",
                    "A space for questions and understanding. Quran text is shown separately from AI explanations, using the attributed text stored in Nuraya."),
                    style = MaterialTheme.typography.bodyLarge)
            }
        }

        if (!repository.configured) {
            Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(learningText(language, "Asisten AI belum tersambung", "AI assistant is not connected"),
                        style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(learningText(language,
                        "Layanan AI belum disediakan untuk versi ini. Nuraya tidak menampilkan jawaban buatan atau mengirim pertanyaan Anda selama layanan belum aktif.",
                        "An AI service has not been connected for this version. Nuraya does not invent answers or send your questions while the service is unavailable."))
                    HorizontalDivider()
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.AutoMirrored.Filled.MenuBook, null, tint = MaterialTheme.colorScheme.primary)
                        Text(learningText(language,
                            "Anda tetap dapat membaca dan mencari ayat di menu Al-Qur'an tanpa akun.",
                            "You can still read and search verses in the Quran section without an account."))
                    }
                }
            }
        } else {
            OutlinedTextField(
                value = question,
                onValueChange = { question = it.take(2000) },
                label = { Text(learningText(language, "Apa yang ingin Anda pelajari?", "What would you like to learn?")) },
                placeholder = { Text(learningText(language, "Tuliskan pertanyaan Anda…", "Write your question…")) },
                minLines = 3,
                maxLines = 6,
                enabled = !loading,
                modifier = Modifier.fillMaxWidth(),
                supportingText = { Text("${question.length}/2000") },
                shape = RoundedCornerShape(18.dp),
            )
            Text(learningText(language,
                "Pertanyaan dikirim ke layanan AI pengelola Nuraya. Jangan sertakan data pribadi. Jawaban AI dapat keliru dan tidak menggantikan bimbingan ahli.",
                "Questions are sent to the Nuraya operator's AI service. Do not include personal data. AI answers can be incorrect and do not replace qualified guidance."),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(
                modifier = Modifier.fillMaxWidth(), enabled = !loading && question.trim().length >= 5,
                onClick = {
                    loading = true
                    failure = null
                    answer = null
                    scope.launch {
                        try {
                            answer = repository.ask(question, language)
                        } catch (exception: CancellationException) {
                            throw exception
                        } catch (exception: Exception) {
                            failure = when (exception.message) {
                                "unconfigured" -> learningText(language, "Layanan AI belum dikonfigurasi oleh pengelola.", "The operator has not configured the AI service.")
                                "access_denied" -> learningText(language, "Layanan belum dapat diakses. Coba lagi nanti.", "The service is not accessible yet. Try again later.")
                                "rate_limited" -> learningText(language, "Layanan sedang sibuk. Tunggu sebentar lalu coba lagi.", "The service is busy. Please wait and try again.")
                                "invalid_citation", "invalid_response" -> learningText(language, "Jawaban tidak ditampilkan karena rujukannya tidak dapat diperiksa. Silakan coba pertanyaan lain.", "This answer was withheld because its references could not be checked. Please try another question.")
                                else -> learningText(language, "Belum dapat terhubung. Periksa koneksi dan coba kembali.", "Unable to connect. Check your connection and try again.")
                            }
                        } finally { loading = false }
                    }
                },
            ) {
                if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onPrimary)
                else Icon(Icons.AutoMirrored.Filled.Send, null)
                Spacer(Modifier.width(10.dp))
                Text(learningText(language, if (loading) "Sedang menyiapkan…" else "Kirim pertanyaan",
                    if (loading) "Preparing…" else "Send question"))
            }
        }

        failure?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }
        answer?.let { response ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(learningText(language, "PENJELASAN AI · BELUM DITINJAU", "AI EXPLANATION · NOT REVIEWED"),
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    SelectionContainer { Text(response.explanation, style = MaterialTheme.typography.bodyLarge) }
                    Text(learningText(language,
                        "Kecocokan nomor ayat tidak membuktikan bahwa penjelasan AI benar. Periksa sumber dan tanyakan kepada ahli untuk persoalan yang kompleks atau diperdebatkan.",
                        "Valid verse numbers do not prove the AI explanation is correct. Check sources and consult a qualified scholar for complex or disputed questions."),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (response.citations.isEmpty()) {
                Text(learningText(language, "Jawaban ini tidak memiliki rujukan ayat yang dapat diperiksa.",
                    "This answer has no verse references that can be checked."),
                    color = MaterialTheme.colorScheme.error)
            }
            response.citations.forEach { citation ->
                val verse = application.quran.verse(citation.surah, citation.ayah)
                if (verse != null) {
                    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainer,
                        RoundedCornerShape(20.dp)).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(learningText(language, "TEKS SUMBER · AL-QUR'AN", "SOURCE TEXT · QURAN"),
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text("${application.quran.surahs.firstOrNull { it.id == citation.surah }?.name.orEmpty()} ${citation.surah}:${citation.ayah}",
                            fontWeight = FontWeight.SemiBold)
                        SelectionContainer {
                            Text(verse.arabic, Modifier.fillMaxWidth(), fontSize = 28.sp,
                                lineHeight = 48.sp, textAlign = TextAlign.Right,
                                style = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Rtl))
                        }
                        SelectionContainer { Text(if (language == "en") verse.english else verse.indonesian) }
                        Text(if (language == "en") "Arabic: Tanzil Project · English: Marmaduke Pickthall (1930)"
                            else "Arab: Tanzil Project · Terjemahan: Kementerian Agama RI, QuranEnc v1.0.1",
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(citation.sourceUrl, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 28.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Outlined.Info, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(learningText(language,
                "Nuraya tidak menerbitkan jawaban AI sebagai materi resmi. Pelajari sumber dengan hati-hati dan hormati perbedaan pendapat.",
                "Nuraya does not publish AI answers as official learning material. Read sources carefully and respect differences of interpretation."),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(16.dp))
    }
}
