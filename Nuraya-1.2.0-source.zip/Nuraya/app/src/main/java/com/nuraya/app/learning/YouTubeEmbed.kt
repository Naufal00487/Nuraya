package com.nuraya.app.learning

import java.net.URI
import java.net.URLDecoder

/** Only known YouTube video/playlist URL shapes may supply IDs to the official player. */
data class YouTubeEmbed(val videoId: String? = null, val playlistId: String? = null) {
    init {
        require(videoId != null || playlistId != null)
        require(videoId == null || videoId.matches(Regex("[A-Za-z0-9_-]{11}")))
        require(playlistId == null || playlistId.matches(Regex("[A-Za-z0-9_-]{10,100}")))
    }

    companion object {
        const val ORIGIN = "https://com.nuraya.app"
        const val BASE_URL = "$ORIGIN/embedded-video/"

        fun parse(value: String): YouTubeEmbed? = runCatching {
            val uri = URI(value)
            require(uri.scheme == "https" && uri.userInfo == null && (uri.port == -1 || uri.port == 443))
            val host = uri.host?.lowercase() ?: return null
            require(host in setOf("youtube.com", "www.youtube.com", "m.youtube.com", "youtube-nocookie.com", "www.youtube-nocookie.com", "youtu.be"))
            val path = uri.path.orEmpty().trim('/').split('/')
            val query = uri.rawQuery.orEmpty().split('&').filter(String::isNotEmpty).map { part ->
                val pair = part.split('=', limit = 2)
                URLDecoder.decode(pair[0], "UTF-8") to URLDecoder.decode(pair.getOrElse(1) { "" }, "UTF-8")
            }
            require(query.map { it.first }.distinct().size == query.size)
            val params = query.toMap()
            val video = when {
                host == "youtu.be" && path.size == 1 -> path[0]
                path == listOf("watch") -> params["v"]
                path.size == 2 && path[0] in setOf("shorts", "embed", "live") && path[1] != "videoseries" -> path[1]
                path == listOf("playlist") || path == listOf("embed", "videoseries") -> null
                else -> return null // Channels and /courses cannot be embedded as a video.
            }
            YouTubeEmbed(video, params["list"])
        }.getOrNull()
    }

    /** All interpolated values are validated IDs or fixed app constants; no title/source HTML. */
    fun html(): String {
        val video = videoId?.let { "videoId:'$it'," }.orEmpty()
        val playlist = playlistId?.let { "listType:'playlist',list:'$it'," }.orEmpty()
        return """<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="strict-origin-when-cross-origin"><style>html,body,#player{width:100%;height:100%;margin:0;background:#000;overflow:hidden}</style></head><body><div id="player"></div><script>
        var player;var nurayaStatus={ready:false,state:-1,error:0};
        function pauseNurayaVideo(){if(player&&player.pauseVideo){player.pauseVideo();}}
        function onYouTubeIframeAPIReady(){player=new YT.Player('player',{width:'100%',height:'100%',host:'https://www.youtube-nocookie.com',$video playerVars:{$playlist autoplay:0,controls:1,playsinline:1,fs:1,rel:0,origin:'$ORIGIN'},events:{onReady:function(){nurayaStatus.ready=true;},onStateChange:function(e){nurayaStatus.state=e.data;},onError:function(e){nurayaStatus.error=e.data;}}});}
        </script><script src="https://www.youtube.com/iframe_api"></script></body></html>""".trimIndent()
    }
}
