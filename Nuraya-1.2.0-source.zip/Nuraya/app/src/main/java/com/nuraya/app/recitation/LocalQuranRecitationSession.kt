package com.nuraya.app.recitation

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.content.ContextCompat
import com.nuraya.app.recitation.ai.QuranWhisperEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import kotlin.math.abs

/** Memory-only recording, with a hard cap independent of any UI timer. */
internal class RecitationPcmBuffer(maxSeconds: Int = 90) {
    private val samples = FloatArray(maxSeconds.coerceIn(1, 90) * SAMPLE_RATE)
    private var count = 0
    private var audibleSamples = 0
    val size: Int @Synchronized get() = count
    val full: Boolean @Synchronized get() = count == samples.size

    @Synchronized fun append(input: ShortArray, length: Int): Int {
        require(length in 0..input.size)
        val accepted = minOf(length, samples.size - count)
        for (i in 0 until accepted) {
            val sample = input[i] / 32768f
            samples[count++] = sample
            if (abs(sample) > 0.003f) audibleSamples++
        }
        return accepted
    }
    @Synchronized fun snapshot(): FloatArray = samples.copyOf(count)
    @Synchronized fun hasAudibleSignal(): Boolean = audibleSamples >= SAMPLE_RATE / 5
    @Synchronized fun clear() { samples.fill(0f); count = 0; audibleSamples = 0 }

    companion object { const val SAMPLE_RATE = 16_000 }
}

data class LocalQuranRecitationState(
    val speech: SpeechSessionState = SpeechSessionState(onDevice = true),
    val elapsedSeconds: Int = 0,
)

/** One user-started session. Capture and native inference stay off the main thread, with no audio files or uploads. */
class LocalQuranRecitationSession(
    context: Context,
    private val onState: (LocalQuranRecitationState) -> Unit,
    private val onFinal: (String) -> Unit,
) {
    private val context = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    @Volatile private var activeBuffer: RecitationPcmBuffer? = null
    private var state = LocalQuranRecitationState()
    @Volatile private var generation = 0
    @Volatile private var recording = false
    @Volatile private var destroyed = false
    @Volatile private var engine: QuranWhisperEngine? = null
    private val engineLock = Any()
    @Volatile private var recorder: AudioRecord? = null
    private val recorderLock = Any()
    private var captureJob: Job? = null
    private var inferenceJob: Job? = null
    private var limitJob: Job? = null

    private fun publish(value: LocalQuranRecitationState) { state = value; onState(value) }
    private fun active(current: Int) = !destroyed && generation == current

    fun start(model: File) {
        if (destroyed || state.speech.listening || state.speech.waiting) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            publish(LocalQuranRecitationState(SpeechSessionState(status = "permission", onDevice = true)))
            return
        }
        val current = ++generation
        val pcm = RecitationPcmBuffer()
        activeBuffer = pcm
        publish(LocalQuranRecitationState(SpeechSessionState(waiting = true, status = "model_loading", onDevice = true)))
        inferenceJob = scope.launch {
            try {
                if (engine == null) withContext(Dispatchers.IO) {
                    val loaded = QuranWhisperEngine(model.absolutePath)
                    // A leave/cancel may happen while native model loading is still running.
                    // Register under the same lock used by destroy so a late model cannot leak.
                    synchronized(engineLock) {
                        if (!active(current)) loaded.close() else engine = loaded
                    }
                }
                if (!active(current)) return@launch
                recording = true
                publish(LocalQuranRecitationState(SpeechSessionState(listening = true, status = "listening", onDevice = true)))
                captureJob = scope.launch(Dispatchers.IO) { capture(current, pcm) }
                limitJob = scope.launch { delay(90_000); if (active(current)) stopListening() }
                var lastAnalyzed = 0
                while (isActive && active(current)) {
                    val size = pcm.size
                    val newAudio = size - lastAnalyzed
                    if (recording && (size < MIN_PARTIAL_SAMPLES || newAudio < PARTIAL_STEP_SAMPLES)) {
                        delay(200)
                        continue
                    }
                    if (!recording) captureJob?.join()
                    val final = !recording
                    if (!pcm.hasAudibleSignal()) {
                        if (final) { finish(current, "", "no_match"); break }
                        lastAnalyzed = size
                        delay(200)
                        continue
                    }
                    val audio = pcm.snapshot()
                    lastAnalyzed = audio.size
                    publish(state.copy(speech = state.speech.copy(listening = !final, waiting = final,
                        status = if (final) "local_processing" else "local_listening_processing")))
                    // No verse text, prompt or expected answer is provided to the ASR model.
                    val text = try { engine?.transcribe(audio).orEmpty().take(10_000) }
                        finally { audio.fill(0f) }
                    if (!active(current)) break
                    if (final) {
                        finish(current, text, if (text.isBlank()) "no_match" else "complete")
                        break
                    }
                    if (text.isNotBlank()) publish(state.copy(speech = state.speech.copy(transcript = text,
                        finalResult = false, status = if (recording) "listening" else "local_processing",
                        listening = recording, waiting = !recording)))
                    // At most one inference runs. Faster capture never creates a backlog of jobs.
                }
            } catch (_: CancellationException) {
                // cancel() already cleared UI state and invalidated callbacks.
            } catch (_: OutOfMemoryError) {
                fail(current, "model_memory")
            } catch (_: Exception) {
                fail(current, "model_failed")
            }
        }
    }

    @SuppressLint("MissingPermission") // start() checks permission; revocation is caught as SecurityException below.
    private suspend fun capture(current: Int, pcm: RecitationPcmBuffer) {
        var input: AudioRecord? = null
        try {
            val minimum = AudioRecord.getMinBufferSize(RecitationPcmBuffer.SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minimum <= 0) throw IOException("Unsupported microphone format")
            input = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RecitationPcmBuffer.SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minimum, 16_000))
            if (input.state != AudioRecord.STATE_INITIALIZED) throw IOException("Microphone initialization failed")
            val accepted = synchronized(recorderLock) {
                if (!active(current) || !recording) false else {
                    // Starting and stopping share the lock: cancellation cannot stop an
                    // unstarted recorder and then have this worker start it afterwards.
                    recorder = input
                    input.startRecording()
                    true
                }
            }
            if (!accepted) return
            if (input.recordingState != AudioRecord.RECORDSTATE_RECORDING) throw IOException("Microphone is not recording")
            val buffer = ShortArray(3_200)
            var lastSecond = -1
            while (active(current) && recording && !pcm.full) {
                val count = input.read(buffer, 0, buffer.size, AudioRecord.READ_BLOCKING)
                if (!active(current) || !recording) break
                if (count < 0) throw IOException("Microphone read failed")
                if (count == 0) { delay(20); continue }
                pcm.append(buffer, count)
                buffer.fill(0)
                val second = pcm.size / RecitationPcmBuffer.SAMPLE_RATE
                if (second != lastSecond) {
                    lastSecond = second
                    withContext(Dispatchers.Main.immediate) {
                        if (active(current)) publish(state.copy(elapsedSeconds = second))
                    }
                }
            }
            buffer.fill(0)
        } catch (_: SecurityException) {
            withContext(Dispatchers.Main.immediate) { fail(current, "permission") }
        } catch (_: CancellationException) {
            // Foreground/lifecycle cancellation: the microphone is released below.
        } catch (_: Exception) {
            withContext(Dispatchers.Main.immediate) { fail(current, "audio") }
        } finally {
            synchronized(recorderLock) { if (recorder === input) recorder = null }
            runCatching { input?.stop() }
            runCatching { input?.release() }
            if (active(current)) {
                withContext(Dispatchers.Main.immediate) {
                    if (active(current)) {
                        recording = false
                        publish(state.copy(speech = state.speech.copy(listening = false,
                            waiting = true, status = "local_processing")))
                    }
                }
            }
        }
    }

    /** Finish capture promptly, then request one final recognition of the complete attempt. */
    fun stopListening() {
        if (!recording) return
        recording = false
        synchronized(recorderLock) { runCatching { recorder?.stop() } }
        publish(state.copy(speech = state.speech.copy(listening = false, waiting = true, status = "local_processing")))
    }

    private fun finish(current: Int, text: String, status: String) {
        if (!active(current)) return
        recording = false
        activeBuffer?.clear(); activeBuffer = null
        limitJob?.cancel(); limitJob = null
        publish(state.copy(speech = SpeechSessionState(transcript = text, finalResult = text.isNotBlank(),
            status = status, onDevice = true)))
        if (text.isNotBlank()) onFinal(text)
    }

    private fun fail(current: Int, status: String) { if (active(current)) cancel(status) }

    fun cancel(status: String = "ready") {
        generation++
        recording = false
        synchronized(recorderLock) { runCatching { recorder?.stop() } }
        synchronized(engineLock) { engine?.cancel() }
        captureJob?.cancel(); captureJob = null
        inferenceJob?.cancel(); inferenceJob = null
        activeBuffer?.clear(); activeBuffer = null
        limitJob?.cancel(); limitJob = null
        publish(LocalQuranRecitationState(SpeechSessionState(status = status, onDevice = true)))
    }

    fun destroy() {
        destroyed = true
        cancel()
        synchronized(engineLock) { engine?.close(); engine = null }
        scope.cancel()
    }

    companion object {
        private const val MIN_PARTIAL_SAMPLES = 6 * RecitationPcmBuffer.SAMPLE_RATE
        private const val PARTIAL_STEP_SAMPLES = 6 * RecitationPcmBuffer.SAMPLE_RATE
    }
}
