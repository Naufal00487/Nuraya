package com.nuraya.app.learning

import android.annotation.SuppressLint
import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nuraya.app.NurayaApplication
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import org.json.JSONObject
import org.json.JSONTokener
import java.util.concurrent.atomic.AtomicBoolean

private data class YouTubeFullScreen(val view: View, val callback: WebChromeClient.CustomViewCallback)
private fun ytText(language: String, id: String, en: String) = if (language == "en") en else id

/** Official IFrame player only. No media URL extraction, download, injected credentials, or JS bridge. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeEmbeddedPlayer(embed: YouTubeEmbed, language: String, onWatched: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as NurayaApplication
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val audio by app.playback.state.collectAsStateWithLifecycle()
    val latestWatched by rememberUpdatedState(onWatched)
    var retry by remember { mutableIntStateOf(0) }
    var ready by remember(embed, retry) { mutableStateOf(false) }
    var error by remember(embed, retry) { mutableIntStateOf(0) }
    var slow by remember(embed, retry) { mutableStateOf(false) }
    var fullScreen by remember { mutableStateOf<YouTubeFullScreen?>(null) }
    fun closeFullScreen() {
        val current = fullScreen
        fullScreen = null
        current?.callback?.onCustomViewHidden()
    }
    val alive = remember(embed, retry) { AtomicBoolean(true) }
    val view = remember(embed, retry) {
        runCatching { WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.setSupportMultipleWindows(false)
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.safeBrowsingEnabled = true
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, false)
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(webView: WebView, request: WebResourceRequest): Boolean {
                    if (!request.isForMainFrame) return request.url.scheme !in setOf("https", "about")
                    // Keep the trusted wrapper in this view. User-clicked source/player links use the browser.
                    if (request.hasGesture() && HttpsUrlPolicy.accepts(request.url.toString())) {
                        webView.evaluateJavascript("pauseNurayaVideo()", null)
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, request.url)) }
                    }
                    return true
                }
                override fun onReceivedError(webView: WebView, request: WebResourceRequest, failure: WebResourceError) {
                    if (alive.get() && request.isForMainFrame) error = -1
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(customView: View, callback: CustomViewCallback) {
                    if (!alive.get() || fullScreen != null) callback.onCustomViewHidden()
                    else fullScreen = YouTubeFullScreen(customView, callback)
                }
                override fun onHideCustomView() { closeFullScreen() }
            }
            // HTTPS app identity supplies the document origin and Referer to the official iframe.
            loadDataWithBaseURL(YouTubeEmbed.BASE_URL, embed.html(), "text/html", "UTF-8", null)
        } }.getOrNull()
    }
    if (view == null) {
        Text(ytText(language,
            "Pemutar Android WebView belum tersedia. Aktifkan atau perbarui Android System WebView, atau pilih Buka sumber asli.",
            "Android WebView is unavailable. Enable or update Android System WebView, or open the original source."),
            color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        return
    }
    LaunchedEffect(view, audio.isPlaying) { if (audio.isPlaying) view.evaluateJavascript("pauseNurayaVideo()", null) }
    LaunchedEffect(view) {
        var recorded = false
        var previousState = -1
        var checks = 0
        while (isActive) {
            if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
                view.evaluateJavascript("JSON.stringify(window.nurayaStatus||{})") { encoded ->
                    if (!alive.get() || !lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) return@evaluateJavascript
                    runCatching {
                        val decoded = JSONTokener(encoded).nextValue() as? String ?: return@runCatching
                        val status = JSONObject(decoded)
                        ready = status.optBoolean("ready", false)
                        val code = status.optInt("error", 0)
                        if (code != 0) error = code
                        val playerState = status.optInt("state", -1)
                        if (playerState == 1 && previousState != 1) {
                            app.playback.pause()
                            if (!recorded) { recorded = true; latestWatched() }
                        }
                        previousState = playerState
                    }
                }
                checks++
                if (checks >= 40 && !ready) slow = true
            }
            delay(500)
        }
    }
    DisposableEffect(view, lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> {
                    view.evaluateJavascript("pauseNurayaVideo()", null)
                    view.onPause()
                    closeFullScreen()
                }
                Lifecycle.Event.ON_RESUME -> view.onResume()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            alive.set(false)
            lifecycle.removeObserver(observer)
            closeFullScreen()
            view.stopLoading()
            view.loadUrl("about:blank")
            (view.parent as? ViewGroup)?.removeView(view)
            view.destroy()
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // YouTube requires at least 200×200 px; controls remain visible at narrow widths.
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val playerHeight = maxOf(220.dp, maxWidth * 9f / 16f)
            // A retry creates a new WebView; recreate its AndroidView host as well.
            key(view) {
                AndroidView(factory = { view }, modifier = Modifier.fillMaxWidth().height(playerHeight)
                    .testTag("youtube_embedded_player"))
            }
        }
        if (!ready && error == 0 && !slow) Text(ytText(language, "Menyiapkan pemutar YouTube…", "Loading YouTube player…"), style = MaterialTheme.typography.bodySmall)
        if (ready && error == 0) Text(ytText(language, "Tekan ▶ di pemutar untuk menonton.", "Press ▶ in the player to watch."), style = MaterialTheme.typography.bodySmall)
        if (error != 0 || slow) {
            Text(when (error) {
                100 -> ytText(language, "Video tidak tersedia atau telah dihapus oleh penerbit.", "The publisher's video is unavailable or has been removed.")
                101, 150 -> ytText(language, "Penerbit tidak mengizinkan video ini diputar di aplikasi lain. Gunakan Buka sumber asli.", "The publisher does not allow embedding. Use Open original source.")
                153 -> ytText(language, "YouTube belum menerima identitas pemutar ini. Coba lagi atau buka sumber asli.", "YouTube did not accept this player's identity. Retry or open the original source.")
                else -> ytText(language, "Pemutar belum dapat dimuat. Periksa koneksi atau buka sumber asli.", "The player could not load. Check your connection or open the original source.")
            }, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = { retry++ }) { Text(ytText(language, "Muat ulang pemutar", "Reload player")) }
        }
    }
    fullScreen?.let { custom ->
        Dialog(onDismissRequest = ::closeFullScreen,
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
            AndroidView(factory = { FrameLayout(it).apply {
                (custom.view.parent as? ViewGroup)?.removeView(custom.view)
                addView(custom.view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            } }, modifier = Modifier.fillMaxSize())
        }
    }
}
