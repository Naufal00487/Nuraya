package com.nuraya.app.learning

import org.junit.Assert.*
import org.junit.Test

class YouTubeEmbedTest {
    @Test fun sourceShapesKeepExactVideoAndPlaylistIds() {
        val id = "BKdYbwxKndU"
        listOf("https://www.youtube.com/watch?v=$id", "https://youtu.be/$id?t=20",
            "https://www.youtube.com/shorts/$id", "https://www.youtube-nocookie.com/embed/$id").forEach {
            assertEquals(id, YouTubeEmbed.parse(it)?.videoId)
        }
        val playlist = "PLSzUb0TgsIYsxT5mMj1KSFDXUEJ3psMCU"
        assertEquals(YouTubeEmbed(null, playlist), YouTubeEmbed.parse("https://www.youtube.com/playlist?list=$playlist"))
        assertEquals(YouTubeEmbed(id, playlist), YouTubeEmbed.parse("https://www.youtube.com/watch?v=$id&list=$playlist"))
    }

    @Test fun channelsMaliciousHostsAndInjectedIdsCannotBecomePlayers() {
        listOf("https://www.youtube.com/@Arabic101/courses", "https://youtube.com/results?search_query=tajwid",
            "https://youtube.com.evil.example/watch?v=BKdYbwxKndU", "https://youtube.com@evil.example/watch?v=BKdYbwxKndU",
            "http://youtube.com/watch?v=BKdYbwxKndU", "javascript:alert(1)",
            "https://youtube.com/watch?v=BKdYbwxKndU&v=uwuqUvJ0cAc", "https://youtube.com:444/watch?v=BKdYbwxKndU",
            "https://youtube.com/watch?v=%27%3Balert(1)", "https://youtu.be/BKdYbwxKndU/extra").forEach {
            assertNull("Unexpected embed for $it", YouTubeEmbed.parse(it))
        }
    }

    @Test fun officialPlayerRetainsControlsIdentityAndUserInitiatedPlayback() {
        val html = YouTubeEmbed("BKdYbwxKndU").html()
        assertTrue(html.contains("https://www.youtube.com/iframe_api"))
        assertTrue(html.contains("host:'https://www.youtube-nocookie.com'"))
        assertTrue(html.contains("autoplay:0,controls:1,playsinline:1,fs:1"))
        assertTrue(html.contains("origin:'https://com.nuraya.app'"))
        assertTrue(html.contains("strict-origin-when-cross-origin"))
        assertTrue(html.contains("onError:function(e){nurayaStatus.error=e.data;}"))
        assertFalse(html.contains("modestbranding"))
        assertFalse(html.contains("download"))
    }

    @Test fun playlistPlayerUsesTheOfficialListParametersWithoutGuessingAVideo() {
        val html = YouTubeEmbed(null, "PLSzUb0TgsIYsxT5mMj1KSFDXUEJ3psMCU").html()
        assertTrue(html.contains("listType:'playlist',list:'PLSzUb0TgsIYsxT5mMj1KSFDXUEJ3psMCU'"))
        assertFalse(html.contains("videoId:"))
    }
}
