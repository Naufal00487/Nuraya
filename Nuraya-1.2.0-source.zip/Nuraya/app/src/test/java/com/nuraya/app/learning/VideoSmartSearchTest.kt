package com.nuraya.app.learning

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class VideoSmartSearchTest {
    private val catalog get() = VideoCatalog(ApplicationProvider.getApplicationContext<Application>())

    @Test fun beginnerNeedsInNaturalIndonesianAndEnglishStartWithLetters() {
        listOf("saya belum bisa baca quran", "cara ngaji dari nol", "aku pengen belajar ngaji dari 0", "saya gak bisa baca Quran", "belajar Quran dari awal", "how do I learn Quran from scratch", "I can't read Quran").forEach { query ->
            val result = catalog.searchWithGuidance(query)
            assertEquals(query, "arabic101-courses", result.items.firstOrNull()?.id)
            assertTrue(query, result.items.all { it.level == "beginner" })
            assertNotNull(result.guidance)
        }
    }

    @Test fun everydayTermsFindTheCorrectLearningTopicRatherThanSubstringNoise() {
        assertEquals(listOf("tajweed-easy-fqe"), catalog.search("belajar panjang pendek").map { it.id })
        assertEquals(listOf("tajweed-easy-fqe"), catalog.search("cara baca dengung").map { it.id })
        assertEquals(listOf("tajweed-sajjad"), catalog.search("cara berhenti saat baca quran").map { it.id })
        assertEquals(listOf("arabic101-courses"), catalog.search("huruf harakat").map { it.id })
        assertTrue(catalog.search("asi").isEmpty()) // Must not match a substring inside unrelated words.
    }

    @Test fun specificRuleQueriesExplainWhenOnlyBroaderTajwidCoursesExist() {
        val result = catalog.searchWithGuidance("hukum nun mati ketemu ba")
        assertTrue(result.items.isNotEmpty())
        assertTrue(result.items.all { "tajwid" in it.topicTags })
        assertTrue(result.relatedOnly)
        assertTrue(result.guidance.orEmpty().contains("iqlab"))
        assertTrue(result.guidance.orEmpty().contains("Belum ada video khusus"))
        assertEquals(result.items.map { it.id }.toSet(), catalog.search("hukum nun mati ketemu huruf ba").map { it.id }.toSet())
    }

    @Test fun shortSurahMemorizationDoesNotInventMemorizationContentForShorts() {
        val result = catalog.searchWithGuidance("hafalan surat pendek")
        assertTrue(result.items.isNotEmpty())
        assertTrue(result.items.all { "memorization" in it.topicTags })
        assertTrue(result.items.none { it.id.startsWith("short-surah-") })
        assertTrue(result.relatedOnly)
        assertTrue(result.guidance.orEmpty().contains("hafalan surat pendek"))
    }

    @Test fun commonTyposAreCorrectedButUnknownSubjectsAreNotDiscarded() {
        val typo = catalog.searchWithGuidance("tajwdi pemula")
        assertTrue(typo.items.isNotEmpty())
        assertTrue(typo.items.all { "tajwid" in it.topicTags && it.level == "beginner" })
        assertTrue(typo.guidance.orEmpty().contains("Ejaan"))
        assertTrue(catalog.search("hafallan").all { "memorization" in it.topicTags })
        assertTrue(catalog.search("tajwid quantumcomputing").isEmpty())
    }

    @Test fun speakersAndNamedSurahsStillRankExactMatches() {
        assertEquals(listOf("tajweed-easy-yasir"), catalog.search("Yasir Qadhi").map { it.id })
        assertEquals(listOf("short-surah-112"), catalog.search("Shorts Al Ikhlas").map { it.id })
        assertEquals(listOf("short-surah-108"), catalog.search("al kautsar", format = "short").map { it.id })
    }

    @Test fun filtersStayInForceAndNoResultGuidanceIsActionable() {
        val result = catalog.searchWithGuidance("tajwid", format = "short")
        assertTrue(result.items.isEmpty())
        assertTrue(result.guidance.orEmpty().contains("filter"))
        assertTrue(result.suggestions.isNotEmpty())
        assertTrue(catalog.search("tajwid", level = "intermediate").all { it.level == "intermediate" })
        assertTrue(catalog.search("", level = "advanced").all { it.level == "advanced" })
    }

    @Test fun offTopicAndMixedOffTopicQueriesDoNotEnterTheLearningCatalogue() {
        listOf("football casino", "video tajwid judi slot", "resep masak", "gaming Quran", "software deployment").forEach { query ->
            assertTrue(query, catalog.search(query).isEmpty())
        }
        val english = catalog.searchWithGuidance("football", language = "en")
        assertTrue(english.guidance.orEmpty().contains("Qur’an learning"))
        assertEquals("Quran from scratch", english.suggestions.first())
    }
}
