# Nuraya

Aplikasi Android native untuk membaca, mendengarkan, dan mempelajari Al-Qur’an. Kotlin, Jetpack Compose, Material 3, Media3, Room, DataStore, dan WorkManager. Gratis, tanpa iklan, tanpa akun wajib. Penyusun tidak mengambil keuntungan finansial dari aplikasi ini.

## Memasang pembaruan

APK pengembangan berada di `artifacts/nuraya-1.1.0-debug.apk`. Pasang di **Android 8.0 atau lebih baru**. Versi 1.1.0 memakai application ID `com.nuraya.app`, versionCode 3, dan sertifikat debug yang sama dengan versi sebelumnya. Pasang sebagai pembaruan agar data lokal tetap tersimpan; menghapus aplikasi menghapus data pribadinya. Paket ini belum merupakan rilis Google Play.

APK dan source ZIP diserahkan lewat tautan HTTPS GitHub pada cabang unduhan terpisah, sesuai izin unggahan publik pengguna. Tautan file workspace tidak dipakai sebagai tautan unduhan pengguna.

## Pembaruan 1.1.0

- **Tulisan Utsmani dan tajwid berwarna:** warna aktif secara default, dapat dimatikan di **Pengaturan → Warna tajwid**. Anotasi sumber dipetakan hanya ke rentang teks yang cocok persis; teks Al-Qur’an asli tidak berubah. Panduan warna tersedia pada pembaca.
- **Arti per kata Indonesia–Inggris dan tafsir Indonesia:** buka chip **Arti per kata** atau **Tafsir** di setiap ayat. Semua 6.236 ayat mempunyai data belajar offline. Tafsir adalah edisi lengkap Kemenag yang disediakan EQuran.id, bukan gabungan semua kitab tafsir. Tafsir tambahan Ibn Kathir tersedia lewat tautan sumber berbahasa Inggris.
- **Katalog qari diperluas:** lebih dari seratus pilihan rekaman lengkap 114 surah, dengan 12 ID lama dipertahankan. Sebagian pilihan merupakan edisi berbeda dari qari yang sama. Angka katalog dan validasi aktual ada di [AUDIO_CATALOG.md](docs/AUDIO_CATALOG.md).
- **Ikuti bacaan:** pilih qari di pembaca, lalu tekan ▶ pada ayat. Alafasy memakai sorotan kata berdasarkan rekaman dan timestamp pasangan yang sama. Bagian dengan timestamp tidak aman memakai sorotan ayat. Qari lain dalam katalog sinkron menggunakan pemutaran per ayat. Tidak ada animasi waktu kata yang ditebak dari panjang teks.
- **Hafalan, tajwid, kuis, dan progres:** dari beranda pilih **Tajwid, hafalan & kuis**. Pilih rentang dan pengulangan, sembunyikan/buka teks, catat penilaian sendiri, pelajari contoh, jawab kuis, dan lihat jadwal pengulangan. Progres tersimpan lokal.
- **Video pembelajaran:** katalog tutorial dan pelajaran singkat memiliki tingkat, topik, bahasa, sumber asli, dan pencarian terbatas pada materi Al-Qur’an. Konten dibuka pada penerbitnya; video tidak diunduh ulang atau diberi klaim lisensi yang tidak dimiliki.
- **Latihan bacaan dengan mikrofon:** pengenal suara Android menandai perkiraan kecocokan kata selama hasil sementara tersedia. Mengutamakan pengenal di perangkat; penggunaan penyedia suara yang dapat memproses online memerlukan persetujuan pengguna. Nuraya tidak menyimpan rekaman atau transkrip.

Perbaikan basmalah 1.0.1 tetap dipertahankan: pembuka 112 surah ditampilkan tanpa nomor; Al-Fatihah 1:1 tetap basmalah; At-Taubah tidak mempunyai basmalah pembuka. Nomor, jumlah ayat, terjemahan, pencarian, dan berbagi ayat tetap sejajar dengan sumber. Font Amiri Quran dibundel offline.

## Cara menggunakan

1. **Al-Qur’an:** cari surah/juz/ayat; buka ayat, arti per kata, tafsir, penanda, atau bagikan teks. Ukuran tulisan dan terjemahan dapat diatur.
2. **Murottal:** pilih qari dan surah. Unduh rekaman surah agar dapat diputar offline setelah selesai. Kelola di **Koleksi → Unduhan**. Mode sinkron di pembaca membutuhkan internet dan memakai sumber audio tersendiri.
3. **Latihan:** dari beranda buka hafalan/kuis atau latihan bacaan. Penilaian hafalan adalah penilaian sendiri, sedangkan kuis menguji pengetahuan.
4. **Video:** gunakan pencarian, filter tingkat/format, dan simpan pelajaran. Tautan eksternal memerlukan internet dan mengikuti aturan platform penerbit.

## Batas kemampuan yang perlu diketahui

**Pengenalan suara belum dapat menilai tajwid, makhraj, harakat, atau panjang mad.** Hasil kecocokan kata bisa salah akibat pengenal suara atau perbedaan ejaan Utsmani. Tidak tersedia klaim koreksi AI real-time yang terjamin. Model Quran terbuka dan alasan pemilihan pengenal Android dicatat di [RECITATION_ASSISTANT.md](docs/RECITATION_ASSISTANT.md). Ketersediaan bahasa Arab dan hasil sementara bergantung pada perangkat/penyedia.

Asisten tanya-jawab terpisah tetap tidak aktif tanpa server yang dikonfigurasi. Tidak ada kunci API, layanan berbayar yang diaktifkan, akun, atau sinkronisasi cloud. Data pribadi berada pada perangkat. Ketersediaan audio/video pihak ketiga dapat berubah.

Pengujian host tidak menggantikan pengujian speaker, mikrofon, pemasangan pembaruan, dan layanan latar belakang di HP. Hasil pemeriksaan yang benar-benar dilakukan tercatat di [BUILD_VALIDATION.md](docs/BUILD_VALIDATION.md).

## Build dan verifikasi

```bash
cd /workspace/Nuraya
bash scripts/setup-android.sh
bash scripts/gradle.sh assembleDebug testDebugUnitTest lintDebug assembleDebugAndroidTest
python3 scripts/import_quran.py --verify
python3 scripts/import_study.py --verify
python3 scripts/import_audio_timing.py --verify
python3 -m unittest discover -s scripts/tests -v
python3 -m unittest discover -s scripts -p 'test_import_study.py' -v
python3 -m unittest discover -s backend/tests -v
python3 scripts/package-artifacts.py
```

Toolchain Linux x86_64 disimpan di `/workspace/.tools`: JDK 17, Gradle 8.11.1, Android SDK/build-tools 35. `scripts/gradle.sh` memuat lingkungan, proxy, dan CA tanpa menonaktifkan TLS. APK asli Gradle ada di `app/build/outputs/apk/debug/app-debug.apk`. Packer memeriksa kesesuaian seluruh asset APK dengan source terkini; berkas build lama tidak boleh diserahkan sebagai versi baru.

Di Android Studio, buka proyek dengan JDK 17/SDK 35 lalu jalankan `./gradlew assembleDebug`. Keystore pribadi dan konfigurasi SDK lokal tidak masuk source ZIP.

Test perangkat: `connectedDebugAndroidTest` memerlukan HP/emulator responsif. Mesin cloud ini tidak memiliki `/dev/kvm`; percobaan emulator software sebelumnya mengalami System UI ANR. Jangan menyatakan test perangkat lulus hanya karena APK berhasil dibangun/dipasang. Host Robolectric digunakan untuk pemeriksaan UI yang dapat dijalankan.

## Sumber dan struktur

- [DATA_SOURCES.md](docs/DATA_SOURCES.md): korpus asli dan terjemahan ayat.
- [STUDY_DATA.md](docs/STUDY_DATA.md): sumber, edisi, hak, checksum, serta pemetaan 77.429 kata dan 60.023 anotasi tajwid.
- [AUDIO_CATALOG.md](docs/AUDIO_CATALOG.md): qari, sumber, cakupan sinkronisasi, dan pemeriksaan audio.
- [VIDEO_SOURCES.md](docs/VIDEO_SOURCES.md): penerbit dan bukti metadata video.
- [PRACTICE.md](docs/PRACTICE.md): materi, kuis, jadwal, dan progres.
- [RECITATION_ASSISTANT.md](docs/RECITATION_ASSISTANT.md): pengenal suara, privasi, riset AI gratis, dan batas evaluasi.

Kode aplikasi berada di `app/src/main/java/com/nuraya/app`: `data/`, `storage/`, `media/`, `ui/`, `learning/`, `study/`, dan `recitation/`. Asset/lisensi ada di `app/src/main/assets`, test host di `app/src/test`, test perangkat di `app/src/androidTest`. `scripts/` menyediakan setup/verifikasi; `backend/` adalah asisten opsional yang tidak diperlukan untuk fitur utama.
