package com.nuraya.app.learning

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.json.JSONArray
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class VideoCatalogueTest {
    private val context: Context get() = ApplicationProvider.getApplicationContext()

    @Test fun packagedReferencesProvideCoursesAndShortsWithoutInventedStreamRights() {
        val catalog = VideoCatalog(context)
        assertFalse(catalog.error)
        assertTrue(catalog.items.isNotEmpty())
        assertEquals(setOf("beginner", "intermediate", "advanced"), catalog.items.map { it.level }.toSet())
        assertTrue(catalog.items.any { it.format == "short" })
        for (item in catalog.items) {
            assertEquals("link-only", item.license)
            assertNull(item.streamUrl)
            assertTrue(item.verificationUrl.startsWith("https://github.com/"))
            assertFalse(item.originalUrl.contains("/results?"))
            assertTrue(item.topicTags.all { it in VideoItem.learningTopics })
        }
    }

    @Test fun searchCombinesLearningWordsAndRespectsLevelAndFormat() {
        val catalog = VideoCatalog(context)
        assertTrue(catalog.search("huruf harakat").any { it.id == "arabic101-courses" })
        assertEquals(listOf("short-surah-112"), catalog.search("al ikhlas", format = "short").map { it.id })
        assertTrue(catalog.search("", level = "advanced").all { it.level == "advanced" })
        assertTrue(catalog.search("football casino").isEmpty())
        assertTrue(catalog.search("tajwid", format = "short").isEmpty())
    }

    @Test fun unrelatedCatalogueEntryIsRejectedInsteadOfEnteringLearningSearch() {
        val data = context.assets.open("videos.json").bufferedReader().use { JSONArray(it.readText()) }
        data.getJSONObject(0).put("topicTags", JSONArray(listOf("unrelated-entertainment")))
        try {
            VideoCatalog.parse(data.toString())
            fail("Unrelated content entered the learning catalogue")
        } catch (_: IllegalArgumentException) { }
    }
}
