package com.nuraya.app.learning

import android.content.Context
import org.json.JSONArray
import java.text.Normalizer
import java.util.Locale

/** Metadata and original publisher links; no claim that link-only recordings are freely licensed. */
data class VideoItem(
    val id: String,
    val titleId: String,
    val titleEn: String,
    val speaker: String,
    val categoryId: String,
    val categoryEn: String,
    val descriptionId: String,
    val descriptionEn: String,
    val originalUrl: String,
    val streamUrl: String?,
    val license: String,
    val sourceName: String,
    val permissionEvidence: String,
    val level: String = "beginner",
    val format: String = "lesson",
    val audioLanguage: String = "en",
    val topicTags: List<String> = emptyList(),
    val lessonOrder: Int = 0,
    val originalTitle: String = "",
    val verifiedAt: String = "",
    val verificationUrl: String = "",
) {
    fun title(language: String) = if (language == "en") titleEn else titleId
    fun category(language: String) = if (language == "en") categoryEn else categoryId
    fun description(language: String) = if (language == "en") descriptionEn else descriptionId
    fun levelLabel(language: String): String = when (level) {
        "beginner" -> if (language == "en") "Beginner" else "Pemula"
        "intermediate" -> if (language == "en") "Intermediate" else "Menengah"
        else -> if (language == "en") "Advanced" else "Lanjutan"
    }
    fun formatLabel(language: String): String = when (format) {
        "short" -> if (language == "en") "Short lesson" else "Video singkat"
        "course" -> if (language == "en") "Learning series" else "Seri belajar"
        else -> if (language == "en") "Tutorial" else "Tutorial"
    }
    fun audioLanguageLabel(language: String) = when (audioLanguage) {
        "id" -> "Bahasa Indonesia"
        "ar" -> if (language == "en") "Arabic" else "Bahasa Arab"
        "und" -> if (language == "en") "Check language at source" else "Bahasa: periksa di sumber"
        else -> if (language == "en") "English audio" else "Audio Bahasa Inggris"
    }

    fun isValid(): Boolean = id.isNotBlank() && titleId.isNotBlank() &&
        titleEn.isNotBlank() && speaker.isNotBlank() && sourceName.isNotBlank() &&
        HttpsUrlPolicy.accepts(originalUrl) && license.isNotBlank() &&
        level in levels && format in formats && audioLanguage in setOf("id", "en", "ar", "und") &&
        (streamUrl == null || (HttpsUrlPolicy.accepts(streamUrl) &&
            license in streamLicenses && permissionEvidence.isNotBlank()))

    fun matchesQuery(query: String): Boolean {
        val words = normalize(query).split(' ').filter(String::isNotBlank)
        if (words.isEmpty()) return true
        val searchable = normalize(listOf(titleId, titleEn, originalTitle, speaker, categoryId,
            categoryEn, descriptionId, descriptionEn, topicTags.joinToString(" "),
            levelLabel("id"), levelLabel("en")).joinToString(" "))
        return words.all(searchable::contains)
    }

    companion object {
        val levels = setOf("beginner", "intermediate", "advanced")
        val formats = setOf("lesson", "short", "course")
        val streamLicenses = setOf("CC-BY-4.0", "CC-BY-SA-4.0", "CC0-1.0", "publisher-permission")
        val learningTopics = setOf("letters", "harakat", "makhraj", "tajwid", "madd", "ghunnah",
            "waqf", "recitation", "memorization", "quran-reading")
        private fun normalize(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "").lowercase(Locale.ROOT)
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
    }
}

/** Search is deliberately bounded to the bundled Quran-learning catalogue. */
class VideoCatalog(context: Context) {
    val items: List<VideoItem>
    val error: Boolean

    init {
        val result = runCatching {
            context.assets.open("videos.json").bufferedReader().use { parse(it.readText()) }
        }
        items = result.getOrDefault(emptyList())
        error = result.isFailure
    }

    fun search(query: String, level: String? = null, format: String? = null): List<VideoItem> =
        items.filter { (level == null || it.level == level) && (format == null || it.format == format) && it.matchesQuery(query) }

    companion object {
        internal fun parse(json: String): List<VideoItem> {
            val array = JSONArray(json)
            return (0 until array.length()).map { index ->
                val row = array.getJSONObject(index)
                val tags = row.getJSONArray("topicTags")
                VideoItem(
                    id = row.getString("id"), titleId = row.getString("titleId"), titleEn = row.getString("titleEn"),
                    speaker = row.getString("speaker"), categoryId = row.getString("categoryId"), categoryEn = row.getString("categoryEn"),
                    descriptionId = row.getString("descriptionId"), descriptionEn = row.getString("descriptionEn"),
                    originalUrl = row.getString("originalUrl"),
                    streamUrl = row.optString("streamUrl").takeIf { it.isNotBlank() && it != "null" },
                    license = row.getString("license"), sourceName = row.getString("sourceName"),
                    permissionEvidence = row.optString("permissionEvidence"), level = row.getString("level"),
                    format = row.getString("format"), audioLanguage = row.getString("audioLanguage"),
                    topicTags = (0 until tags.length()).map(tags::getString), lessonOrder = row.optInt("lessonOrder"),
                    originalTitle = row.getString("originalTitle"), verifiedAt = row.getString("verifiedAt"),
                    verificationUrl = row.getString("verificationUrl"),
                ).also { item ->
                    require(item.isValid()) { "Invalid video source: ${item.id}" }
                    require(item.topicTags.isNotEmpty() && item.topicTags.all { it in VideoItem.learningTopics }) { "Video is outside the learning catalogue" }
                    require(item.originalTitle.isNotBlank() && item.verifiedAt.isNotBlank() && HttpsUrlPolicy.accepts(item.verificationUrl))
                }
            }.also { rows -> require(rows.map { it.id }.distinct().size == rows.size) }
                .sortedWith(compareBy<VideoItem> { it.lessonOrder }.thenBy { it.id })
        }
    }
}
