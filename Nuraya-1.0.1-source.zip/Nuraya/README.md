# Nuraya

Aplikasi Android native untuk membaca Al-Qur’an dan mendengarkan murottal. Kotlin, Jetpack Compose, Material 3, Media3, Room, DataStore, dan WorkManager. Gratis, tanpa iklan, dan dapat digunakan tanpa akun.

## Menggunakan APK

Hasil build pengembangan diserahkan di `artifacts/nuraya-1.0.1-debug.apk`. Buka file tersebut di HP **Android 8.0 atau lebih baru**, izinkan pemasangan dari aplikasi yang membuka file jika Android memintanya, lalu pilih **Instal**. File ini ditandatangani dengan kunci debug untuk pengujian; belum merupakan rilis Google Play. Kunci rilis pribadi tidak disertakan.

Teks Arab dan terjemahan Indonesia–Inggris sudah tersimpan dalam APK. Untuk murottal, pilih **Murottal → qari → surah**. Ketuk unduh untuk menyimpan audio. Audio dapat digunakan tanpa internet **setelah unduhan selesai**; status dan penghapusan tersedia di **Koleksi → Unduhan**. Menghapus aplikasi menghapus data pribadinya, termasuk unduhan.

## Perubahan 1.0.1

- Basmalah pembuka pada 112 surah ditampilkan terpisah tanpa nomor ayat. Al-Fatihah tetap memiliki basmalah sebagai 1:1; At-Taubah tidak memiliki basmalah pembuka. Nomor ayat, terjemahan, dan teks sumber dipertahankan. Hasil pencarian, berbagi ayat, serta rujukan belajar menggunakan teks ayat yang sebenarnya.
- Tulisan Arab menggunakan font Quran offline berlisensi Amiri Quran pada pembaca, pencarian, judul surah, dan rujukan belajar.
- Pilihan qari bertambah dari 3 menjadi 12, dengan sumber HTTPS dan fitur unduh untuk mendengarkan offline.
- Pernyataan penyusun tidak mengambil keuntungan finansial ditampilkan di beranda dan Pengaturan. Aplikasi gratis, tanpa iklan, langganan, atau pembelian dalam aplikasi.

## Fitur

- Pembaca 114 surah dan 30 juz: teks Arab Tanzil Utsmani dengan font Amiri Quran yang dibundel offline, terjemahan Indonesia Kementerian Agama RI melalui QuranEnc, dan Inggris Marmaduke Pickthall. Pencarian teks dan referensi seperti `2:255`, penanda, posisi bacaan, pengaturan ukuran huruf, pilihan terjemahan, berbagi ayat, serta tautan tafsir dengan sumber.
- Dua belas qari dengan katalog 114 surah masing-masing; termasuk Alafasy, Abdul Basit, Al-Shuraim, Al-Minshawi, Al-Ajmi, Al-Dossari, dan lainnya. Lihat [katalog audio](docs/AUDIO_CATALOG.md). Pilih surah, putar/jeda, cari posisi, kecepatan, ulangi surah, navigasi audio, pemutar mini, sesi media Android, riwayat, favorit, dan daftar putar pribadi.
- Unduhan di penyimpanan pribadi aplikasi, progres/status persisten, pembatalan, percobaan ulang, dan konfirmasi penghapusan. Data pribadi menggunakan Room; preferensi menggunakan DataStore.
- Antarmuka Indonesia–Inggris, tampilan terang/gelap, mode tamu, serta halaman sumber dan privasi.
- Fondasi perpustakaan video dan asisten AI yang menyatakan keadaan layanan secara terbuka.

## Batasan yang disengaja

- **AI belum aktif** tanpa server yang dikonfigurasi. Tidak ada jawaban AI palsu atau kunci API dalam APK. Lihat [integrasi AI dan video](docs/AI_AND_VIDEO.md).
- **Katalog video kosong** sampai konten dan hak penayangannya diverifikasi. Pemutar, pencarian, kategori, penyimpanan, dan integrasi katalog tersedia; tidak ada daftar konten agama yang dibuat-buat.
- **Tafsir dibuka di situs sumber**, bukan tersedia offline. Transliterasi dan pewarnaan tajwid belum disertakan karena tidak memakai data yang belum diverifikasi.
- **Akun dan sinkronisasi belum tersedia.** Fitur pribadi bekerja lokal. Audio tidak otomatis diunduh seluruhnya.
- Sumber murottal adalah layanan pihak ketiga; ketersediaan setiap file dapat berubah. Pengujian satu rekaman bukan verifikasi seluruh katalog audio.

## Build berikutnya

Pada mesin cloud Linux x86_64 ini:

```bash
cd /workspace/Nuraya
bash scripts/setup-android.sh
bash scripts/gradle.sh assembleDebug testDebugUnitTest lintDebug
python3 scripts/import_quran.py --verify
```

`setup-android.sh` memasang JDK 17, Gradle 8.11.1, Android SDK 35, dan build-tools 35.0.0 di `/workspace/.tools`; unduhan diverifikasi menggunakan checksum dari penerbit. `NURAYA_TOOLS` dapat diarahkan ke folder lain. Script menggunakan jalur proxy dan CA lingkungan jika disediakan, tanpa mematikan verifikasi TLS. File `local.properties` dibuat hanya bila belum ada. Instalasi perlu akses internet; build selanjutnya menggunakan cache yang tersedia.

Di Android Studio, buka folder proyek, gunakan JDK 17 dan SDK Android 35, lalu jalankan Gradle wrapper `./gradlew assembleDebug`. Konfigurasi Android Studio/SDK pribadi tidak dimasukkan ke source ZIP.

APK asli Gradle: `app/build/outputs/apk/debug/app-debug.apk`. Pengujian perangkat memakai `connectedDebugAndroidTest` saat emulator/perangkat tersedia. Lihat [hasil validasi](docs/BUILD_VALIDATION.md) untuk hasil yang benar-benar dijalankan dan batasannya.

Untuk membuat berkas penyerahan dari build terkini:

```bash
python3 scripts/package-artifacts.py
```

Emulator opsional: `bash scripts/start-emulator.sh` memakai API 28 dan serial `emulator-5556` secara default. Pilihan API 35 tersedia melalui `NURAYA_API=35 NURAYA_PORT=5554 bash scripts/start-emulator.sh`. Mesin cloud ini tidak memiliki akselerasi KVM dan kedua emulator mengalami gangguan System UI; pengujian perangkat dan audio Android belum dinyatakan lulus. Test presentasi pembaca di host Robolectric tersedia pada versi 1.0.1. Gunakan HP Android atau emulator dengan akselerasi untuk pemeriksaan perangkat berikutnya.

## Struktur

```text
app/src/main/java/com/nuraya/app/
  data/       korpus Al-Qur’an dan sumber qari
  storage/    Room, DataStore, repositori koleksi/unduhan
  media/      MediaSessionService, pemutar, pekerja unduhan
  ui/         beranda, pembaca, murottal, koleksi, pengaturan
  learning/   integrasi asisten dan katalog video
app/src/main/assets/   korpus, lisensi, konfigurasi layanan
app/src/test/          pengujian unit dan integrasi lokal
app/src/androidTest/   pengujian APK di Android
scripts/               setup toolchain dan verifikasi data
backend/               server opsional asisten pembelajaran
```

Sumber, versi, checksum, dan ketentuan penggunaan data tercatat dalam [DATA_SOURCES.md](docs/DATA_SOURCES.md). Teks agama tidak dihasilkan oleh model. Jangan mengubah teks sumber secara manual; gunakan proses impor dan pemeriksaan yang disediakan.

APK dan source ZIP dibagikan melalui cabang unduhan repository GitHub Nuraya setelah pengguna mengizinkan unggahan publik. Tidak ada penerbitan ke toko aplikasi atau pemasangan layanan berbayar.
