# AI learning and video integration

This build does not include an active AI service, account backend, or a verified video catalogue. These are explicit product states, not simulated services. Reading, searches, local bookmarks and audio are independent of them.

## AI client

`app/src/main/assets/ai_config.json` contains `{"baseUrl":""}`. The learning screen states that AI is not connected and sends no request in this state. The endpoint is deployment-owned configuration, not an API-key entry field for end users.

Once an operator has deployed an authorised HTTPS backend, put its public HTTPS base URL in that file and rebuild the APK. The Android client sends `POST /v1/learn` with a JSON object containing `question` (5–2000 characters) and `language` (`id` or `en`). It does not contain or send a model-provider secret.

Expected successful response:

```json
{"answer":"An explanation, clearly labelled as unreviewed AI output.","citations":[{"surah":1,"ayah":1}]}
```

This example illustrates the protocol only; it is not a model answer or a religious claim. Error statuses distinguish unconfigured service (503), access denial (401/403), throttling (429), malformed references and network failures. Redirects are not followed. Connections require HTTPS, normal TLS verification, finite timeouts and response-size limits.

Every citation is checked against the actual bundled corpus. AI-supplied quote and source-URL fields are ignored. The app renders Arabic and translation from the local, attributed data, separately from the explanation. A valid verse number does **not** verify that a model's interpretation is correct; the UI says so. Responses are not published into an official catalogue, and there is no fake offline AI response.

## Optional server

`backend/server.py` is a standard-library Python gateway with no install dependencies. It loads the same corpus, finds candidate passages locally, supplies them to the model, and accepts citations only from that supplied set. Source retrieval uses explicit verse references and lexical matching; it is not a comprehensive semantic Quran search or a scholarly review process.

Local checks require no key and do not contact a model:

```sh
cd /workspace/Nuraya
python3 -m unittest discover -s backend/tests -v
python3 backend/server.py
```

The server binds only to `127.0.0.1:8080`. Its `/health` endpoint reports the configuration state. `POST /v1/learn` returns 503 until **both** a server-side `OPENAI_API_KEY` and `NURAYA_AI_ENABLED=true` are supplied securely by the operator. `OPENAI_MODEL` can select an available model; its default is `gpt-4.1-mini`. `NURAYA_BACKEND_PORT` changes the local listening port. Do not commit secret values or put them in Android assets, `BuildConfig`, source files, screenshots or logs.

Enabling real model requests can incur provider charges. No paid request or deployment was performed during this work. Before offering the service, the operator must configure a public HTTPS reverse proxy, access controls, spending limits, rate limits across server instances, and an appropriate privacy notice. The provided per-IP limiter is a single-process safeguard, not an account or abuse-management service. The gateway intentionally does not trust forwarded-IP headers. Behind a reverse proxy, the gateway's limit applies to the proxy address; configure end-user limits at the proxy.

Server responses use no-store headers. Requests and provider bodies are not logged by this gateway. The provider request sets `store=false`; this does not replace the provider's own data-retention terms. The server does not persist question history. Provider credentials stay in the server process and are sent only to the fixed official HTTPS API endpoint. TLS verification is never disabled. Provider errors are returned with generic codes, not secret-bearing diagnostics.

The integration is implemented and testable with mocked provider responses. Live model quality, billing, production deployment, account authentication and cross-device synchronisation remain unverified/unconfigured.

## Video catalogue

`app/src/main/assets/videos.json` intentionally contains `[]`. The UI displays an informative empty state. There are no invented speakers, lessons, permissions or video previews.

A catalogue entry requires these keys: `id`, `titleId`, `titleEn`, `speaker`, `categoryId`, `categoryEn`, `descriptionId`, `descriptionEn`, `originalUrl`, `license`, `sourceName`; optional keys are `streamUrl` and `permissionEvidence`. Each ID must be unique. Text must identify the real source and creator. URLs must be HTTPS without embedded credentials.

For external links only, omit `streamUrl` and use `license: "link-only"` after checking the original site's terms. The detail page opens the original source in the user's browser; it does not scrape, copy or download the video. External viewing completion cannot be observed and is not falsely recorded as an in-app watch.

Direct playback is accepted only for declared `CC-BY-4.0`, `CC-BY-SA-4.0`, `CC0-1.0` or `publisher-permission` entries with a nonempty `permissionEvidence` record. These fields are **not an automatic legal verification**: an operator must review them and retain the actual rights evidence before shipping content. Do not enter a YouTube watch page as a direct Media3 stream URL. Do not use this path to bypass a provider's embedding or download restrictions.

The UI implements bilingual search and categories, details, original-source links, Room-backed watch-later favourites and playback history. Media3 direct playback has visible buffering, error and retry states. Starting a video stops murottal; starting murottal pauses an active video. The player pauses when the app stops and releases resources when its screen leaves composition. The app records an in-app watch only when playback actually starts.

No real video was available for end-to-end catalogue/playback validation. Source validation and the intentional empty state have automated checks; a future reviewed catalogue still requires playback testing for its actual streams.
