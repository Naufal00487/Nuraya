package com.nuraya.app.learning

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.nuraya.app.NurayaApplication
import kotlinx.coroutines.launch
import kotlinx.coroutines.CancellationException

private fun videoText(language: String, id: String, en: String) = if (language == "en") en else id

@Composable
fun VideoLibraryScreen(language: String) {
    val app = LocalContext.current.applicationContext as NurayaApplication
    val catalog = remember(app) { VideoCatalog(app) }
    val entries by app.library.entries.collectAsState(initial = emptyList())
    val savedIds = entries.filter { it.type == "video_saved" }.map { it.key }.toSet()
    val scope = rememberCoroutineScope()
    var query by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    var savedOnly by rememberSaveable { mutableStateOf(false) }
    var operationError by remember { mutableStateOf(false) }
    val persist: (suspend () -> Unit) -> Unit = { action -> scope.launch {
        try { action(); operationError = false }
        catch (exception: CancellationException) { throw exception }
        catch (_: Exception) { operationError = true }
    } }
    val selected = catalog.items.firstOrNull { it.id == selectedId }
    BackHandler(enabled = selected != null) { selectedId = null }

    if (selected != null) {
        VideoDetail(
            item = selected, language = language, saved = selected.id in savedIds,
            operationError = operationError,
            onBack = { selectedId = null },
            onToggleSaved = {
                persist { app.library.toggle("video_saved", selected.id, selected.title(language), selected.speaker, selected.originalUrl) }
            },
            onWatched = {
                persist { app.library.save("video_history", selected.id, selected.title(language), selected.speaker, selected.originalUrl) }
            },
        )
        return
    }

    val filtered = catalog.items.filter { item ->
        (category == null || item.categoryId == category) && (!savedOnly || item.id in savedIds) &&
            (query.isBlank() || listOf(item.titleId, item.titleEn, item.speaker, item.categoryId, item.categoryEn)
                .any { it.contains(query.trim(), ignoreCase = true) })
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(videoText(language, "TEMAN BELAJAR", "YOUR LEARNING COMPANION"),
                    style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Text(videoText(language, "Video pembelajaran", "Learning videos"),
                    style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
                Text(videoText(language, "Pilih ilmu yang ingin Anda dalami, sesuai waktu Anda.",
                    "Explore what you want to learn, at your own pace."),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it.take(200) }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
                leadingIcon = { Icon(Icons.Outlined.Search, null) },
                label = { Text(videoText(language, "Cari judul, topik, atau pembicara", "Search titles, topics, or speakers")) },
            )
        }
        if (catalog.items.isNotEmpty()) {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(selected = !savedOnly && category == null,
                            onClick = { savedOnly = false; category = null },
                            label = { Text(videoText(language, "Semua", "All")) })
                    }
                    item {
                        FilterChip(selected = savedOnly, onClick = { savedOnly = !savedOnly },
                            label = { Text(videoText(language, "Tonton nanti", "Watch later")) })
                    }
                    items(catalog.items.distinctBy { it.categoryId }) { item ->
                        FilterChip(selected = category == item.categoryId,
                            onClick = { category = if (category == item.categoryId) null else item.categoryId },
                            label = { Text(item.category(language)) })
                    }
                }
            }
        }
        if (catalog.error) {
            item {
                EmptyVideoCard(language, videoText(language, "Katalog belum dapat dibuka", "The catalog could not be opened"),
                    videoText(language, "Data katalog tidak memenuhi pemeriksaan sumber. Materi tidak ditampilkan agar rujukannya tetap dapat dipercaya.",
                        "The catalog did not pass source checks. Its entries are hidden until the references can be corrected."))
            }
        } else if (catalog.items.isEmpty()) {
            item {
                EmptyVideoCard(language,
                    videoText(language, "Ruang untuk ilmu yang bermakna", "A space for meaningful learning"),
                    videoText(language,
                        "Katalog video belum tersedia dalam versi ini. Materi akan ditambahkan setelah sumber, pembicara, dan izin penayangannya diperiksa. Tidak ada video contoh yang disamarkan sebagai materi asli.",
                        "The video catalog is not available in this version. Content can be added after its source, speaker, and viewing rights are checked. No sample videos are presented as real learning material."))
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Outlined.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(videoText(language, "Sumber jelas, belajar nyaman", "Clear sources, thoughtful learning"),
                            fontWeight = FontWeight.Medium)
                        Text(videoText(language, "Pembaca Al-Qur'an dan murottal tetap tersedia melalui menu utama.",
                            "The Quran reader and recitations remain available in the main navigation."),
                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        } else if (filtered.isEmpty()) {
            item {
                EmptyVideoCard(language, videoText(language, "Belum ada hasil", "No results yet"),
                    videoText(language, "Coba kata kunci atau kategori lain. Video yang disimpan akan muncul di Tonton nanti.",
                        "Try another keyword or category. Saved videos appear in Watch later."))
            }
        } else {
            items(filtered, key = { it.id }) { item ->
                Card(onClick = { selectedId = item.id }, shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Box(Modifier.size(64.dp).background(MaterialTheme.colorScheme.primaryContainer,
                            RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.PlayCircle, null, Modifier.size(32.dp), tint = MaterialTheme.colorScheme.primary)
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(item.category(language), style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary)
                            Text(item.title(language), style = MaterialTheme.typography.titleMedium)
                            Text(item.speaker, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (item.id in savedIds) Icon(Icons.Filled.Bookmark,
                            videoText(language, "Disimpan", "Saved"), tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(18.dp)) }
    }
}

@Composable
private fun EmptyVideoCard(language: String, title: String, detail: String) {
    Card(shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(26.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Icon(Icons.Outlined.VideoLibrary, null, Modifier.size(42.dp), tint = MaterialTheme.colorScheme.primary)
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text(detail, style = MaterialTheme.typography.bodyLarge)
            Text(videoText(language, "PERPUSTAKAAN · TANPA IKLAN", "LIBRARY · AD FREE"),
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
private fun VideoDetail(item: VideoItem, language: String, saved: Boolean, operationError: Boolean,
    onBack: () -> Unit, onToggleSaved: () -> Unit, onWatched: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as NurayaApplication
    var playing by rememberSaveable(item.id) { mutableStateOf(false) }
    var externalError by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, videoText(language, "Kembali", "Back")) }
            Text(item.category(language), Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
            IconButton(onClick = onToggleSaved) {
                Icon(if (saved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                    videoText(language, if (saved) "Hapus dari Tonton nanti" else "Simpan untuk Tonton nanti",
                        if (saved) "Remove from Watch later" else "Save to Watch later"))
            }
        }
        if (playing && item.streamUrl != null) {
            InlineVideoPlayer(item.streamUrl, language, onWatched)
        } else {
            Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(MaterialTheme.colorScheme.primaryContainer,
                RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.PlayCircle, null, Modifier.size(68.dp), tint = MaterialTheme.colorScheme.primary)
            }
        }
        Text(item.title(language), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        Text(item.speaker, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        Text(item.description(language), style = MaterialTheme.typography.bodyLarge)
        if (operationError) Text(videoText(language,
            "Perubahan belum dapat disimpan. Periksa ruang penyimpanan dan coba lagi.",
            "Your change could not be saved. Check device storage and try again."), color = MaterialTheme.colorScheme.error)
        if (item.streamUrl != null && !playing) {
            Button(onClick = { app.playback.stop(); playing = true }, Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.PlayArrow, null)
                Spacer(Modifier.width(8.dp))
                Text(videoText(language, "Putar video", "Play video"))
            }
        }
        OutlinedButton(onClick = {
            externalError = false
            try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.originalUrl))) }
            catch (_: ActivityNotFoundException) { externalError = true }
            catch (_: SecurityException) { externalError = true }
        }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Outlined.OpenInNew, null)
            Spacer(Modifier.width(8.dp))
            Text(videoText(language, "Buka sumber asli", "Open original source"))
        }
        if (externalError) Text(videoText(language, "Tidak ada aplikasi untuk membuka tautan ini.",
            "No application is available to open this link."), color = MaterialTheme.colorScheme.error)
        Text(videoText(language, "Sumber: ", "Source: ") + item.sourceName,
            style = MaterialTheme.typography.bodySmall)
        Text(videoText(language, "Izin: ", "License: ") + item.license,
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(item.originalUrl, style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (item.streamUrl == null) Text(videoText(language,
            "Video ini hanya tersedia melalui sumber aslinya. Nuraya tidak menyalin atau mengunduhnya.",
            "This video is available through its original source. Nuraya does not copy or download it."),
            style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
private fun InlineVideoPlayer(url: String, language: String, onWatched: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as NurayaApplication
    val audioState by app.playback.state.collectAsStateWithLifecycle()
    val lifecycleOwner = LocalLifecycleOwner.current
    var generation by remember { mutableIntStateOf(0) }
    var failed by remember(generation) { mutableStateOf(false) }
    var buffering by remember(generation) { mutableStateOf(true) }
    val player = remember(url, generation) {
        ExoPlayer.Builder(context).build().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
            setHandleAudioBecomingNoisy(true)
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }
    LaunchedEffect(audioState.isPlaying, player) {
        if (audioState.isPlaying) player.pause()
    }
    DisposableEffect(player, lifecycleOwner) {
        var recorded = false
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) { buffering = state == Player.STATE_BUFFERING }
            override fun onPlayerError(error: PlaybackException) { failed = true; buffering = false }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying && !recorded) { recorded = true; onWatched() }
            }
        }
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_STOP) player.pause() }
        player.addListener(listener)
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            player.removeListener(listener)
            player.release()
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f), contentAlignment = Alignment.Center) {
            AndroidView(
                factory = { PlayerView(it).apply { this.player = player; useController = true } },
                update = { it.player = player },
                modifier = Modifier.fillMaxSize(),
            )
            if (buffering) CircularProgressIndicator()
        }
        if (failed) {
            Text(videoText(language, "Video belum dapat diputar. Periksa koneksi atau buka sumber asli.",
                "The video could not be played. Check your connection or open the original source."),
                color = MaterialTheme.colorScheme.error)
            TextButton(onClick = { generation++ }) { Text(videoText(language, "Coba lagi", "Try again")) }
        }
    }
}
