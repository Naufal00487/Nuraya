package com.nuraya.app.storage

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.IOException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.nurayaPreferences by preferencesDataStore(name = "nuraya_preferences")

data class UserSettings(
    val language: String = "id",
    val translation: String = "id",
    val arabicSize: Float = 30f,
    val darkMode: Boolean = false,
)

class SettingsRepository(context: Context) {
    private val store = context.applicationContext.nurayaPreferences
    private val languageKey = stringPreferencesKey("language")
    private val translationKey = stringPreferencesKey("translation")
    private val arabicSizeKey = floatPreferencesKey("arabic_size")
    private val darkModeKey = booleanPreferencesKey("dark_mode")

    val settings: Flow<UserSettings> = store.data.catch {
        if (it is IOException) emit(emptyPreferences()) else throw it
    }.map { prefs ->
        UserSettings(
            language = prefs[languageKey]?.takeIf { it in languages } ?: "id",
            translation = prefs[translationKey]?.takeIf { it in translations } ?: "id",
            arabicSize = (prefs[arabicSizeKey] ?: 30f).takeIf { it.isFinite() }?.coerceIn(22f, 48f) ?: 30f,
            darkMode = prefs[darkModeKey] ?: false,
        )
    }

    suspend fun setLanguage(language: String) {
        require(language in languages)
        store.edit { it[languageKey] = language }
    }

    suspend fun setTranslation(translation: String) {
        require(translation in translations)
        store.edit { it[translationKey] = translation }
    }

    suspend fun setArabicSize(size: Float) {
        require(size.isFinite())
        store.edit { it[arabicSizeKey] = size.coerceIn(22f, 48f) }
    }

    suspend fun setDarkMode(enabled: Boolean) {
        store.edit { it[darkModeKey] = enabled }
    }

    companion object {
        private val languages = setOf("id", "en")
        private val translations = setOf("id", "en", "none")
    }
}
