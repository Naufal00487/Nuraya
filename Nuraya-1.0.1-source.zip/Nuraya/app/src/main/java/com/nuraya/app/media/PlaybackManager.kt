package com.nuraya.app.media

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.nuraya.app.data.Qari
import com.nuraya.app.data.QuranRepository
import com.nuraya.app.data.Surah
import com.nuraya.app.storage.DownloadRepository
import com.nuraya.app.storage.LibraryRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class PlaybackState(
    val title: String = "",
    val qari: String = "",
    val qariId: String = "",
    val surahId: Int = 0,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val speed: Float = 1f,
    val repeat: Boolean = false,
    val error: String? = null,
    val loading: Boolean = false,
)

@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
class PlaybackManager(
    context: Context,
    private val quran: QuranRepository,
    private val library: LibraryRepository,
    private val downloads: DownloadRepository,
) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mutableState = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = mutableState.asStateFlow()
    private var controller: MediaController? = null
    private data class QueueRequest(val tracks: List<Pair<Surah, Qari>>, val index: Int)
    private var pending: QueueRequest? = null
    private var generation = 0
    private var preparingQueue = false
    private var connecting = false

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            updateState()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            mutableState.update { it.copy(error = null) }
            if (controller?.isPlaying == true) recordHistory(mediaItem)
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) recordHistory(controller?.currentMediaItem)
        }

        override fun onPlayerError(error: PlaybackException) {
            mutableState.update {
                it.copy(
                    isPlaying = false,
                    loading = false,
                    error = when (error.errorCode) {
                        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                            "Koneksi audio gagal. Periksa internet atau pilih unduhan. / Audio connection failed. Check your connection or use a download."
                        PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND,
                        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
                            "Rekaman tidak tersedia. Coba lagi atau pilih qari lain. / Recording unavailable. Retry or choose another reciter."
                        else -> "Audio tidak dapat diputar (${error.errorCodeName}). / Audio playback failed (${error.errorCodeName})."
                    },
                )
            }
        }
    }

    init {
        connect()
        scope.launch {
            while (isActive) {
                updateState()
                delay(500)
            }
        }
    }

    private fun connect() {
        if (connecting || controller != null) return
        connecting = true
        val future = MediaController.Builder(
            appContext,
            SessionToken(appContext, ComponentName(appContext, PlaybackService::class.java)),
        ).setListener(object : MediaController.Listener {
            override fun onDisconnected(controller: MediaController) {
                this@PlaybackManager.controller = null
                preparingQueue = false
                mutableState.update { it.copy(isPlaying = false, loading = false,
                    error = "Pemutar terputus. Pilih rekaman untuk mencoba lagi. / Player disconnected. Select a recording to retry.") }
            }
        }).buildAsync()
        future.addListener({
            connecting = false
            try {
                controller = future.get().also { it.addListener(listener) }
                updateState()
                pending?.also { pending = null; startQueue(it) }
            } catch (exception: Exception) {
                pending = null
                preparingQueue = false
                mutableState.update {
                    it.copy(loading = false, error = "Pemutar belum tersedia. Pilih rekaman untuk mencoba lagi. / Player unavailable. Select a recording to retry.")
                }
            }
        }, ContextCompat.getMainExecutor(appContext))
    }

    fun play(surah: Surah, qari: Qari) {
        val player = controller
        val mediaId = "${qari.id}:${surah.id}"
        if (player != null && !preparingQueue && player.currentMediaItem?.mediaId == mediaId && player.playerError == null) {
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0L)
            if (player.playbackState == Player.STATE_IDLE) player.prepare()
            player.play()
            return
        }
        val catalogQari = quran.qaris.firstOrNull { it.id == qari.id } ?: return
        val tracks = quran.surahs.map { it to catalogQari }
        val index = tracks.indexOfFirst { it.first.id == surah.id }
        if (index >= 0) startQueue(QueueRequest(tracks, index))
    }

    /** Plays the personal collection in the caller's visible order, including mixed reciters. */
    fun playCollection(tracks: List<Pair<Surah, Qari>>) {
        val catalogSurahs = quran.surahs.associateBy { it.id }
        val catalogQaris = quran.qaris.associateBy { it.id }
        val verified = tracks.take(500).mapNotNull { (surah, qari) ->
            val knownSurah = catalogSurahs[surah.id]
            val knownQari = catalogQaris[qari.id]
            if (knownSurah != null && knownQari != null) knownSurah to knownQari else null
        }
        if (verified.isNotEmpty()) startQueue(QueueRequest(verified, 0))
    }

    private fun startQueue(queue: QueueRequest) {
        val (surah, qari) = queue.tracks[queue.index]
        val request = ++generation
        preparingQueue = true
        mutableState.update {
            it.copy(title = surah.name, qari = qari.name, qariId = qari.id, surahId = surah.id,
                loading = true, isPlaying = false, positionMs = 0, durationMs = 0, error = null)
        }
        val player = controller
        if (player == null) { pending = queue; connect(); return }
        player.pause()
        scope.launch {
            try {
                val items = withContext(Dispatchers.IO) {
                    queue.tracks.map { (item, reciter) ->
                        val local = downloads.localFile(reciter.id, item.id)
                        val extras = Bundle().apply {
                            putString("qariId", reciter.id)
                            putInt("surahId", item.id)
                        }
                        MediaItem.Builder()
                            .setMediaId("${reciter.id}:${item.id}")
                            .setUri(local?.let { Uri.fromFile(it) } ?: Uri.parse(reciter.audioUrl(item.id)))
                            .setMediaMetadata(
                                MediaMetadata.Builder()
                                    .setTitle(item.name)
                                    .setArtist(reciter.name)
                                    .setAlbumTitle("Nuraya · Al-Qur'an")
                                    .setIsPlayable(true)
                                    .setExtras(extras)
                                    .build(),
                            )
                            .build()
                    }
                }
                if (request != generation) return@launch
                preparingQueue = false
                player.setMediaItems(items, queue.index, 0L)
                player.prepare()
                player.play()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (exception: Exception) {
                if (request == generation) {
                    preparingQueue = false
                    mutableState.update {
                        it.copy(loading = false, isPlaying = false, error = "Audio belum tersedia. Coba lagi. / Audio unavailable. Please retry.")
                    }
                }
            }
        }
    }

    fun toggle() {
        if (preparingQueue) {
            ++generation
            preparingQueue = false
            pending = null
            controller?.pause()
            mutableState.update { it.copy(loading = false, isPlaying = false) }
            return
        }
        controller?.run {
            if (isPlaying || playWhenReady) pause() else {
                if (playbackState == Player.STATE_ENDED) seekTo(0L)
                if (playerError != null || playbackState == Player.STATE_IDLE) {
                    mutableState.update { it.copy(error = null) }
                    prepare()
                }
                play()
            }
        }
    }

    fun seekTo(positionMs: Long) {
        controller?.let { player ->
            val duration = player.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: return
            player.seekTo(positionMs.coerceIn(0L, duration))
            updateState()
        }
    }

    fun setSpeed(speed: Float) {
        if (speed.isFinite()) controller?.setPlaybackSpeed(speed.coerceIn(0.5f, 2f))
    }

    fun setRepeat(enabled: Boolean) {
        controller?.repeatMode = if (enabled) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
    }

    fun next() {
        controller?.run { if (hasNextMediaItem()) seekToNextMediaItem() }
    }

    fun previous() {
        controller?.run {
            if (currentPosition > 3_000L) seekTo(0L)
            else if (hasPreviousMediaItem()) seekToPreviousMediaItem()
            else seekTo(0L)
        }
    }

    fun stop() {
        ++generation
        preparingQueue = false
        pending = null
        controller?.stop()
        controller?.clearMediaItems()
        mutableState.value = PlaybackState()
    }

    private fun recordHistory(item: MediaItem?) {
        if (item == null) return
        val surahId = item.mediaMetadata.extras?.getInt("surahId") ?: return
        val qariId = item.mediaMetadata.extras?.getString("qariId") ?: return
        scope.launch(Dispatchers.IO) {
            try {
                library.save(
                    type = "audio_history",
                    key = "$qariId:$surahId",
                    title = item.mediaMetadata.title?.toString().orEmpty(),
                    subtitle = item.mediaMetadata.artist?.toString().orEmpty(),
                    extra = qariId,
                )
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                Log.w("Nuraya", "Playback history could not be saved", error)
            }
        }
    }

    private fun updateState() {
        if (preparingQueue) return
        val player = controller ?: return
        val item = player.currentMediaItem
        mutableState.update { old ->
            old.copy(
                title = item?.mediaMetadata?.title?.toString() ?: old.title,
                qari = item?.mediaMetadata?.artist?.toString() ?: old.qari,
                qariId = item?.mediaMetadata?.extras?.getString("qariId") ?: old.qariId,
                surahId = item?.mediaMetadata?.extras?.getInt("surahId") ?: old.surahId,
                isPlaying = player.isPlaying,
                positionMs = player.currentPosition.coerceAtLeast(0L),
                durationMs = player.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L,
                speed = player.playbackParameters.speed,
                repeat = player.repeatMode == Player.REPEAT_MODE_ONE,
                loading = player.playbackState == Player.STATE_BUFFERING,
            )
        }
    }
}
