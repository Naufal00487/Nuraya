package com.nuraya.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nuraya.app.NurayaApplication
import com.nuraya.app.storage.UserEntry

@Composable
fun HomeScreen(app: NurayaApplication, language: String, entries: List<UserEntry>, onRead: (Int, Int) -> Unit, onNavigate: (String) -> Unit) {
    val lastRead = entries.filter { it.type == "read_history" }.maxByOrNull { it.updatedAt }
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(24.dp)) {
        item {
            Column {
                Text(label(language, "ASSALAMUALAIKUM", "ASSALAMUALAIKUM"), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary, letterSpacing = 2.sp)
                Spacer(Modifier.height(8.dp))
                Text(label(language, "Ruang tenang\nuntuk bertumbuh.", "A quiet space\nto grow."), style = MaterialTheme.typography.headlineLarge)
                Spacer(Modifier.height(8.dp))
                Text(label(language, "Baca, dengarkan, dan pelajari Al-Qur’an.", "Read, listen, and learn from the Qur’an."), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Emerald, Color(0xFF26705A))))) {
                Box(Modifier.size(170.dp).align(Alignment.TopEnd).offset(x = 50.dp, y = (-55).dp).background(Color.White.copy(alpha = .05f), CircleShape))
                Column(Modifier.padding(24.dp)) {
                    Icon(Icons.Outlined.Headphones, null, tint = Color(0xFFE4D2A4), modifier = Modifier.size(30.dp))
                    Spacer(Modifier.height(18.dp))
                    Text(label(language, "Hadirkan ketenangan\nmelalui lantunan ayat.", "Find stillness\nin every recitation."), style = MaterialTheme.typography.headlineMedium, color = Color.White)
                    Spacer(Modifier.height(10.dp))
                    Text(label(language, "Pilih qari dan surah yang ingin didengar.", "Choose a reciter and a surah to listen to."), color = Color(0xFFD5E5DB))
                    Spacer(Modifier.height(18.dp))
                    Button(onClick = { onNavigate("murottal") }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF0E5CA), contentColor = Emerald)) {
                        Icon(Icons.Outlined.PlayArrow, null)
                        Spacer(Modifier.width(8.dp))
                        Text(label(language, "Dengarkan murottal", "Listen to murottal"))
                    }
                }
            }
        }
        item {
            SectionTitle(label(language, "Lanjutkan perjalanan", "Continue your journey"))
            Spacer(Modifier.height(12.dp))
            Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceContainerLow) {
                Row(Modifier.fillMaxWidth().clickable {
                    val parts = lastRead?.key?.split(":")
                    onRead(parts?.getOrNull(0)?.toIntOrNull() ?: 1, parts?.getOrNull(1)?.toIntOrNull() ?: 1)
                }.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconTile(Icons.Outlined.MenuBook)
                    Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                        Text(lastRead?.title ?: "Al-Fatihah", style = MaterialTheme.typography.titleMedium)
                        Text(lastRead?.subtitle ?: label(language, "Mulai membaca · 7 ayat", "Start reading · 7 verses"), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Icon(Icons.AutoMirrored.Outlined.ArrowForward, label(language, "Lanjut membaca", "Continue reading"))
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickCard(Modifier.weight(1f), Icons.Outlined.MenuBook, "Al-Qur’an", label(language,"114 surah · offline","114 surahs · offline")) { onNavigate("quran") }
                QuickCard(Modifier.weight(1f), Icons.Outlined.Bookmarks, label(language,"Koleksi saya","My collection"), label(language,"Tersimpan untuk Anda","Saved for you")) { onNavigate("library") }
            }
        }
        item {
            SectionTitle(label(language, "Belajar dengan sumber", "Learn with sources"))
            Spacer(Modifier.height(12.dp))
            Surface(onClick = { onNavigate("learn") }, shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = .55f)) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.AutoStories, null, tint = MaterialTheme.colorScheme.secondary)
                    Column(Modifier.padding(start = 16.dp).weight(1f)) {
                        Text(label(language,"Teman belajar","Learning companion"), style = MaterialTheme.typography.titleMedium)
                        Text(label(language,"Rujukan Al-Qur’an dan status layanan AI","Qur’an references and AI service status"), style = MaterialTheme.typography.bodyMedium)
                    }
                    Icon(Icons.Outlined.ChevronRight, null)
                }
            }
        }
        item {
            Text(label(language,"Gratis dan tanpa iklan.\nPenyusun tidak mengambil keuntungan finansial dari aplikasi ini.","Free and ad-free.\nThe creators do not earn financial profit from this application."), Modifier.fillMaxWidth(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable fun SectionTitle(title: String) { Text(title, style = MaterialTheme.typography.titleLarge) }
@Composable fun IconTile(icon: ImageVector) {
    Box(Modifier.size(48.dp).background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
    }
}
@Composable private fun QuickCard(modifier: Modifier, icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    OutlinedCard(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(16.dp))
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
