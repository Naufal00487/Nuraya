package com.nuraya.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.nuraya.app.BuildConfig
import com.nuraya.app.NurayaApplication
import com.nuraya.app.storage.UserSettings

@Composable
fun SettingsScreen(app:NurayaApplication,settings:UserSettings,perform:(suspend ()->Unit)->Unit,onLearn:()->Unit){
    val language=settings.language
    val context=LocalContext.current
    var textSize by remember(settings.arabicSize){mutableFloatStateOf(settings.arabicSize)}
    var sourcesVisible by remember{mutableStateOf(false)}
    LazyColumn(contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(24.dp)) {
        item {
            Text(label(language,"Nyaman, sesuai Anda.","Make yourself at home."),style=MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text(label(language,"Mode tamu · tersimpan di perangkat ini","Guest mode · saved on this device"),color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            SectionTitle(label(language,"Bahasa antarmuka","Interface language"))
            Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                FilterChip(selected=language=="id",onClick={perform{app.settings.setLanguage("id")}},label={Text("Indonesia")},modifier=Modifier.testTag("language_id"))
                FilterChip(selected=language=="en",onClick={perform{app.settings.setLanguage("en")}},label={Text("English")},modifier=Modifier.testTag("language_en"))
            }
        }
        item {
            SectionTitle(label(language,"Terjemahan Al-Qur’an","Qur’an translation"))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                listOf("id" to "Indonesia","en" to "English","none" to label(language,"Tanpa","None")).forEach{(key,title)->FilterChip(selected=settings.translation==key,onClick={perform{app.settings.setTranslation(key)}},label={Text(title)})}
            }
            Text(if(settings.translation=="en")"Marmaduke Pickthall (1930)" else if(settings.translation=="id")"Kementerian Agama RI · QuranEnc v1.0.1" else label(language,"Hanya teks Arab","Arabic text only"),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            SectionTitle(label(language,"Ukuran tulisan Arab","Arabic text size"))
            Text(label(language,"Rasm Utsmani · font Amiri Quran · tersedia offline","Uthmani script · Amiri Quran font · available offline"),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            Slider(value=textSize,onValueChange={textSize=it},onValueChangeFinished={perform{app.settings.setArabicSize(textSize)}},valueRange=22f..48f,steps=12)
            Text("${textSize.toInt()} sp",style=MaterialTheme.typography.bodySmall)
        }
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)){Text(label(language,"Tampilan gelap","Dark appearance"),style=MaterialTheme.typography.titleMedium);Text(label(language,"Nyaman untuk membaca malam hari","Comfortable for evening reading"),style=MaterialTheme.typography.bodySmall)}
                Switch(checked=settings.darkMode,onCheckedChange={perform{app.settings.setDarkMode(it)}})
            }
        }
        item { HorizontalDivider() }
        item {
            SectionTitle(label(language,"Pernyataan nonkomersial","Noncommercial disclaimer"))
            Spacer(Modifier.height(12.dp))
            Text(label(language,
                "Kami, penyusun aplikasi Nuraya, tidak mengambil keuntungan finansial dari aplikasi ini. Nuraya disediakan gratis, tanpa iklan, langganan, atau pembelian dalam aplikasi. Hak cipta teks, terjemahan, dan rekaman tetap milik sumber serta pemegang hak masing-masing.",
                "We, the creators of Nuraya, do not earn financial profit from this application. Nuraya is provided free of charge, without ads, subscriptions, or in-app purchases. Copyright in the texts, translations, and recordings remains with their respective sources and rightsholders."),
                style=MaterialTheme.typography.bodyMedium,modifier=Modifier.testTag("noncommercial_disclaimer"))
        }
        item {
            SectionTitle(label(language,"Tentang ruang belajar ini","About this learning space"))
            Spacer(Modifier.height(12.dp))
            Text(label(language,"Nuraya gratis dan tanpa iklan. Penanda, riwayat, pengaturan, dan unduhan disimpan di perangkat. Tidak ada akun atau sinkronisasi cloud yang aktif.","Nuraya is free and ad-free. Bookmarks, history, settings, and downloads stay on this device. No account or cloud sync is active."),style=MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(10.dp))
            Text(label(language,"Streaming dan membuka tautan akan menghubungkan perangkat ke penyedia konten. Pertanyaan AI hanya dikirim jika server telah dikonfigurasi dan Anda menekan Kirim.","Streaming and opening links connect your device to content providers. AI questions are sent only when a server is configured and you press Send."),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            OutlinedButton(onClick={sourcesVisible=!sourcesVisible},modifier=Modifier.fillMaxWidth()) {Icon(Icons.Outlined.Verified,null);Spacer(Modifier.width(8.dp));Text(label(language,"Sumber & atribusi","Sources & attribution"))}
            if(sourcesVisible) {
                Spacer(Modifier.height(12.dp))
                Surface(shape=RoundedCornerShape(16.dp),color=MaterialTheme.colorScheme.surfaceContainerLow){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                    Text(app.quran.attribution,style=MaterialTheme.typography.bodySmall)
                    Text(app.quran.sourceNotice,style=MaterialTheme.typography.bodySmall)
                    Text(label(language,"Teks Arab: Tanzil, tanpa perubahan. Transliterasi dan penanda tajwid belum disertakan. Tafsir tersedia melalui tautan sumber; bukan bagian dari data offline.","Arabic: Tanzil, unmodified. Transliteration and tajweed markings are not included. Tafsir opens through a source link and is not part of the offline data."),style=MaterialTheme.typography.bodySmall)
                    TextButton(onClick={runCatching{context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://tanzil.net/docs/text_license")))}}){Text("Tanzil · ${label(language,"ketentuan sumber","source terms")}")}
                    TextButton(onClick={runCatching{context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://alquran.cloud/about")))}}){Text("Islamic Network · ${label(language,"sumber audio","audio source")}")}
                }}
            }
            TextButton(onClick=onLearn,modifier=Modifier.fillMaxWidth()){Text(label(language,"Tentang asisten pembelajaran","About the learning companion"))}
        }
        item {Text("Nuraya ${BuildConfig.VERSION_NAME} · ${label(language,"Edisi pengembangan","Development edition")}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Spacer(Modifier.height(12.dp))}
    }
}
