package com.nuraya.app.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Emerald = Color(0xFF164F43)
val Gold = Color(0xFFAC8748)
private val LightColors = lightColorScheme(
    primary = Emerald, onPrimary = Color.White,
    primaryContainer = Color(0xFFDDEDE5), onPrimaryContainer = Color(0xFF163F35),
    secondary = Gold, secondaryContainer = Color(0xFFF2E8D4), onSecondaryContainer = Color(0xFF59421D),
    background = Color(0xFFFAF9F5), surface = Color(0xFFFAF9F5),
    surfaceContainer = Color(0xFFF0F1E9), surfaceContainerLow = Color(0xFFF4F4EE),
    surfaceContainerHigh = Color(0xFFE9EEE6), surfaceVariant = Color(0xFFE9EEE6),
    onSurface = Color(0xFF203B32), onSurfaceVariant = Color(0xFF68776E),
    outline = Color(0xFF94A397), outlineVariant = Color(0xFFDFE5DC)
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFFA2D6BC), onPrimary = Color(0xFF103A2E),
    primaryContainer = Color(0xFF234F40), onPrimaryContainer = Color(0xFFD0ECD9),
    secondary = Color(0xFFDFC28E), secondaryContainer = Color(0xFF51432B),
    background = Color(0xFF101D18), surface = Color(0xFF101D18),
    surfaceContainer = Color(0xFF1A2B23), surfaceContainerLow = Color(0xFF17271F),
    surfaceContainerHigh = Color(0xFF27382E), surfaceVariant = Color(0xFF27382E),
    onSurface = Color(0xFFE0E8DE), onSurfaceVariant = Color(0xFFB2BFB3),
    outlineVariant = Color(0xFF34473B)
)

@Composable
fun NurayaTheme(dark: Boolean = false, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors,
        typography = Typography(
            displaySmall = TextStyle(fontFamily = FontFamily.Serif, fontSize = 35.sp, lineHeight = 42.sp),
            headlineLarge = TextStyle(fontFamily = FontFamily.Serif, fontSize = 32.sp, lineHeight = 40.sp),
            headlineMedium = TextStyle(fontFamily = FontFamily.Serif, fontSize = 27.sp, lineHeight = 35.sp),
            titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 21.sp, lineHeight = 29.sp),
            titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 24.sp),
            bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 26.sp),
            bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 22.sp),
            labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 10.sp, lineHeight = 14.sp)
        ), content = content)
}

fun label(language: String, id: String, en: String) = if (language == "en") en else id
