package com.nuraya.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nuraya.app.NurayaApplication
import com.nuraya.app.data.QuranRepository
import com.nuraya.app.data.Surah
import com.nuraya.app.data.Verse
import com.nuraya.app.storage.UserEntry
import com.nuraya.app.storage.UserSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun QuranScreen(repo: QuranRepository, language: String, onRead: (Int, Int) -> Unit, onJuz: (Int) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val normalized = remember(query) { QuranRepository.normalizeSearch(query.trim()) }
    val surahs = remember(normalized) {
        repo.surahs.filter {
            normalized.isEmpty() || it.id.toString() == normalized ||
                QuranRepository.normalizeSearch("${it.name} ${it.arabicName} ${it.englishName}").contains(normalized)
        }
    }
    var results by remember { mutableStateOf<List<Verse>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    LaunchedEffect(query) {
        searching = query.isNotBlank()
        results = emptyList()
        if (query.isNotBlank()) {
            delay(200)
            results = withContext(Dispatchers.Default) { repo.search(query) }
        }
        searching = false
    }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 20.dp)) {
            Text(label(language, "Dekat dengan setiap ayat.", "Closer to every verse."), style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(6.dp))
            Text(label(language, "114 surah · 30 juz · tersedia offline", "114 surahs · 30 juz · available offline"),
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(value = query, onValueChange = { query = it.take(200) }, singleLine = true,
                leadingIcon = { Icon(Icons.Outlined.Search, null) },
                trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Outlined.Close, label(language,"Hapus pencarian","Clear search")) } },
                placeholder = { Text(label(language, "Cari surah, ayat, atau 2:255", "Search surah, verse, or 2:255")) },
                modifier = Modifier.fillMaxWidth().testTag("quran_search"), shape = RoundedCornerShape(18.dp))
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(selectedTab == 0, onClick = { selectedTab = 0 }, label = { Text("Surah") })
                FilterChip(selectedTab == 1, onClick = { selectedTab = 1 }, label = { Text("Juz") })
            }
        }
        if (query.isNotBlank()) {
            LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (surahs.isNotEmpty()) {
                    item { Text(label(language,"Surah","Surahs"), style = MaterialTheme.typography.titleMedium) }
                    items(surahs, key = { "surah_${it.id}" }) { surah -> SurahRow(surah, language) { onRead(surah.id, 1) } }
                }
                item {
                    Text(if (searching) label(language,"Mencari ayat…","Searching verses…") else label(language,"${results.size} ayat ditemukan","${results.size} verses found"),
                        style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                }
                if (searching) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
                if (!searching && results.isEmpty() && surahs.isEmpty()) item {
                    Text(label(language,"Belum ada hasil. Coba kata lain atau nomor seperti 2:255.","No results yet. Try another word or a reference such as 2:255."), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                items(results.take(100), key = { "verse_${it.number}" }) { verse ->
                    OutlinedCard(onClick = { onRead(verse.surah, verse.ayah) }, shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("${repo.surahs[verse.surah - 1].name} · ${verse.surah}:${verse.ayah}", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(8.dp))
                            Text(verse.arabic, Modifier.fillMaxWidth(), fontFamily = QuranArabicFont, fontSize = 24.sp,
                                textAlign = TextAlign.Right, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Rtl, lineHeight = 42.sp))
                            Spacer(Modifier.height(6.dp))
                            Text(if (language == "en") verse.english else verse.indonesian, maxLines = 3, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                if (results.size > 100) item { Text(label(language,"Menampilkan 100 hasil pertama. Perjelas pencarian untuk hasil lainnya.","Showing the first 100 results. Refine your search to find more."), style = MaterialTheme.typography.bodySmall) }
            }
        } else if (selectedTab == 0) {
            LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(repo.surahs, key = Surah::id) { surah -> SurahRow(surah, language) { onRead(surah.id, 1) } }
                item { Text(label(language,"Teks Arab: Tanzil · Terjemahan: Kemenag RI / Pickthall", "Arabic: Tanzil · Translations: Kemenag RI / Pickthall"),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 12.dp)) }
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items((1..30).toList(), key = { it }) { number ->
                    val verses = remember(number) { repo.juz(number) }
                    val first = verses.firstOrNull()
                    val last = verses.lastOrNull()
                    OutlinedCard(onClick = { onJuz(number) }, modifier = Modifier.fillMaxWidth().testTag("juz_$number"), shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                            NumberTile(number)
                            Column(Modifier.padding(start = 16.dp).weight(1f)) {
                                Text("Juz $number", style = MaterialTheme.typography.titleMedium)
                                if (first != null && last != null) Text("${repo.surahs[first.surah - 1].name} ${first.ayah} – ${repo.surahs[last.surah - 1].name} ${last.ayah}",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Icon(Icons.Outlined.ChevronRight, null)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SurahRow(surah: Surah, language: String, onClick: () -> Unit) {
    OutlinedCard(onClick = onClick, modifier = Modifier.fillMaxWidth().testTag("surah_${surah.id}"), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            NumberTile(surah.id)
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(surah.name, style = MaterialTheme.typography.titleMedium)
                val revelation = if (surah.revelation == "meccan") label(language,"Makkiyah","Meccan") else label(language,"Madaniyah","Medinan")
                Text("${surah.ayahCount} ${label(language,"ayat","verses")} · $revelation", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(surah.arabicName, fontFamily = QuranArabicFont, fontSize = 23.sp,
                style = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Rtl), color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun NumberTile(number: Int) {
    Box(Modifier.size(42.dp).background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
        Text(number.toString(), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun ReaderScreen(
    app: NurayaApplication, settings: UserSettings, surahId: Int, ayahId: Int, juzId: Int,
    entries: List<UserEntry>, perform: (suspend () -> Unit) -> Unit, onRead: (Int, Int) -> Unit,
) {
    val language = settings.language
    val context = LocalContext.current
    val verses = remember(surahId, juzId) { if (juzId > 0) app.quran.juz(juzId) else app.quran.verses(surahId) }
    val initialIndex = remember(surahId, ayahId, juzId) {
        if (juzId > 0) 0 else verses.indexOfFirst { it.ayah == ayahId }.coerceAtLeast(0)
    }
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = initialIndex)
    val bookmarkKeys = remember(entries) { entries.filter { it.type == "bookmark" }.map { it.key }.toSet() }
    var preferencesVisible by rememberSaveable { mutableStateOf(false) }
    var jumpVisible by rememberSaveable { mutableStateOf(false) }
    var jumpInput by rememberSaveable(surahId, juzId) { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(surahId, ayahId, juzId) { listState.scrollToItem(initialIndex) }
    LaunchedEffect(surahId, juzId, language) {
        snapshotFlow { listState.firstVisibleItemIndex }.distinctUntilChanged().collectLatest { index ->
            delay(600)
            verses.getOrNull(index)?.let { verse -> perform {
                app.library.save("read_history", "${verse.surah}:${verse.ayah}", app.quran.surahs[verse.surah - 1].name,
                    "${label(language,"Ayat","Verse")} ${verse.ayah}")
            } }
        }
    }
    Column(Modifier.fillMaxSize().testTag("reader_screen")) {
        Surface(color = MaterialTheme.colorScheme.surfaceContainerLow) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (juzId > 0) "Juz $juzId" else app.quran.surahs.getOrNull(surahId - 1)?.arabicName.orEmpty(),
                        style = MaterialTheme.typography.titleLarge, fontFamily = if (juzId > 0) null else QuranArabicFont)
                    Text("${verses.size} ${label(language,"ayat · bacaan offline","verses · offline reading")}",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (juzId == 0) IconButton(onClick = { jumpVisible = true }) { Icon(Icons.Outlined.FormatListNumbered, label(language,"Lompat ke ayat","Jump to verse")) }
                IconButton(onClick = { preferencesVisible = true }) { Icon(Icons.Outlined.TextFields, label(language,"Pengaturan bacaan","Reading preferences")) }
            }
        }
        LazyColumn(state = listState, contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(verses, key = { _, verse -> verse.number }) { _, verse ->
                val key = "${verse.surah}:${verse.ayah}"
                val surah = app.quran.surahs[verse.surah - 1]
                // Keep the opening and verse in one lazy-list item so jump/history indices remain verse-based.
                verse.openingBasmalah?.let { opening ->
                    Surface(Modifier.fillMaxWidth().padding(vertical = 8.dp).testTag("surah_basmalah_${verse.surah}"),
                        shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceContainerLow) {
                        Column(Modifier.padding(horizontal = 16.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(opening, Modifier.fillMaxWidth().testTag("basmalah_text_${verse.surah}"),
                                fontFamily = QuranArabicFont, fontSize = settings.arabicSize.sp, textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Rtl,
                                    lineHeight = (settings.arabicSize * 2f).sp, letterSpacing = 0.sp,
                                    platformStyle = PlatformTextStyle(includeFontPadding = true)))
                            Spacer(Modifier.height(6.dp))
                            Text(label(language, "Basmalah pembuka · tanpa nomor ayat", "Opening basmalah · unnumbered"),
                                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Column(Modifier.fillMaxWidth().padding(vertical = 12.dp).testTag("verse_${verse.surah}_${verse.ayah}")) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                            Text(key, Modifier.padding(horizontal = 12.dp, vertical = 6.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        }
                        if (juzId > 0) Text(surah.name, Modifier.weight(1f).padding(start = 10.dp), style = MaterialTheme.typography.labelLarge)
                        else Spacer(Modifier.weight(1f))
                        IconButton(onClick = { perform { app.library.toggle("bookmark", key, surah.name, "${label(language,"Ayat","Verse")} ${verse.ayah}") } },
                            modifier = Modifier.testTag("bookmark_${verse.surah}_${verse.ayah}")) {
                            Icon(if (key in bookmarkKeys) Icons.Outlined.BookmarkAdded else Icons.Outlined.BookmarkBorder,
                                label(language, if (key in bookmarkKeys) "Hapus penanda" else "Tandai ayat", if (key in bookmarkKeys) "Remove bookmark" else "Bookmark verse"),
                                tint = if (key in bookmarkKeys) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = {
                            val translation = when(settings.translation) { "en" -> verse.english; "none" -> ""; else -> verse.indonesian }
                            val source = when(settings.translation) { "en" -> "Marmaduke Pickthall (1930)"; "none" -> ""; else -> "Kementerian Agama RI · QuranEnc v1.0.1" }
                            val share = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, "${surah.name} ($key)\n\n${verse.arabic}\n\n$translation\n\nArabic: Tanzil Project, Uthmani · CC BY 3.0\n$source\nhttps://quran.com/$key")
                            }
                            try { context.startActivity(Intent.createChooser(share, label(language,"Bagikan ayat","Share verse"))) }
                            catch (_: ActivityNotFoundException) { Toast.makeText(context,label(language,"Tidak ada aplikasi untuk berbagi.","No sharing app is available."),Toast.LENGTH_SHORT).show() }
                        }) { Icon(Icons.Outlined.Share, label(language,"Bagikan ayat","Share verse"), tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text(verse.arabic, Modifier.fillMaxWidth().testTag("verse_text_${verse.surah}_${verse.ayah}"), fontFamily = QuranArabicFont, fontSize = settings.arabicSize.sp,
                        textAlign = TextAlign.Right, style = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Rtl,
                            lineHeight = (settings.arabicSize * 2f).sp, letterSpacing = 0.sp,
                            platformStyle = PlatformTextStyle(includeFontPadding = true)))
                    if (settings.translation != "none") {
                        Spacer(Modifier.height(20.dp))
                        Text(if (settings.translation == "en") verse.english else verse.indonesian, style = MaterialTheme.typography.bodyLarge)
                        Spacer(Modifier.height(10.dp))
                        Text(if (settings.translation == "en") "Marmaduke Pickthall (1930)" else "Kementerian Agama RI · QuranEnc v1.0.1",
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (settings.translation == "id" && !verse.indonesianFootnotes.isNullOrBlank()) {
                        var notesOpen by rememberSaveable(verse.number) { mutableStateOf(false) }
                        TextButton(onClick = { notesOpen = !notesOpen }) {
                            Text(label(language,if (notesOpen) "Tutup catatan terjemahan" else "Catatan terjemahan", if (notesOpen) "Hide translation notes" else "Translation notes"))
                        }
                        if (notesOpen) Text(verse.indonesianFootnotes, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = {
                        try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(app.quran.tafsirUrl(verse.surah,verse.ayah)))) }
                        catch (_: ActivityNotFoundException) { Toast.makeText(context,label(language,"Peramban belum tersedia.","No browser is available."),Toast.LENGTH_SHORT).show() }
                    }, contentPadding = PaddingValues(horizontal = 0.dp)) {
                        Icon(Icons.Outlined.OpenInNew, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(label(language,"Tafsir Ibn Kathir · Quran.com (EN)","Ibn Kathir commentary · Quran.com (EN)"), style = MaterialTheme.typography.labelMedium)
                    }
                    HorizontalDivider(Modifier.padding(top = 12.dp), color = MaterialTheme.colorScheme.outlineVariant)
                }
            }
            item(key = "reader_footer") {
                Column(Modifier.fillMaxWidth().padding(vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(label(language,"Rasm Utsmani · Tanzil · font Amiri Quran.\nBasmalah pembuka dipisahkan tanpa nomor, kecuali Al-Fatihah (1:1). At-Taubah tidak memiliki basmalah pembuka.\nTafsir dibuka di situs sumber dan memerlukan internet.","Uthmani script · Tanzil · Amiri Quran font.\nOpening basmalahs are unnumbered, except Al-Fatihah (1:1). At-Tawbah has no opening basmalah.\nCommentary opens at its source and requires internet."),
                        textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (juzId == 0) Row(Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        OutlinedButton(onClick = { onRead(surahId - 1,1) }, enabled = surahId > 1) {
                            Icon(Icons.AutoMirrored.Outlined.ArrowBack,null,Modifier.size(18.dp)); Spacer(Modifier.width(5.dp))
                            Text(label(language,"Sebelumnya","Previous"))
                        }
                        OutlinedButton(onClick = { onRead(surahId + 1,1) }, enabled = surahId < 114) {
                            Text(label(language,"Berikutnya","Next")); Spacer(Modifier.width(5.dp))
                            Icon(Icons.AutoMirrored.Outlined.ArrowForward,null,Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
    if (preferencesVisible) AlertDialog(onDismissRequest = { preferencesVisible = false },
        title = { Text(label(language,"Nyamankan bacaan","Make reading comfortable")) },
        text = {
            Column {
                Text(label(language,"Ukuran tulisan Arab","Arabic text size"),style = MaterialTheme.typography.titleMedium)
                var size by remember(settings.arabicSize) { mutableFloatStateOf(settings.arabicSize) }
                Slider(value = size, onValueChange = { size = it }, valueRange = 22f..48f, steps = 12,
                    onValueChangeFinished = { perform { app.settings.setArabicSize(size) } })
                Text("${size.toInt()} sp", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(14.dp))
                Text(label(language,"Terjemahan","Translation"),style = MaterialTheme.typography.titleMedium)
                listOf("id" to "Bahasa Indonesia", "en" to "English", "none" to label(language,"Tanpa terjemahan","Arabic only")).forEach { (value,title) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = settings.translation == value, onClick = { perform { app.settings.setTranslation(value) } })
                        TextButton(onClick = { perform { app.settings.setTranslation(value) } }) { Text(title) }
                    }
                }
            }
        }, confirmButton = { TextButton(onClick = { preferencesVisible = false }) { Text(label(language,"Selesai","Done")) } })
    if (jumpVisible) {
        val number = jumpInput.toIntOrNull()
        AlertDialog(onDismissRequest = { jumpVisible = false }, title = { Text(label(language,"Lompat ke ayat","Jump to verse")) },
            text = { OutlinedTextField(value = jumpInput, onValueChange = { jumpInput = it.filter(Char::isDigit).take(3) },
                label = { Text("1–${verses.size}") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) },
            confirmButton = { TextButton(enabled = number != null && number in 1..verses.size, onClick = {
                number?.let { scope.launch { listState.scrollToItem(it - 1) } }; jumpVisible = false
            }) { Text(label(language,"Buka","Open")) } },
            dismissButton = { TextButton(onClick = { jumpVisible = false }) { Text(label(language,"Batal","Cancel")) } })
    }
}
